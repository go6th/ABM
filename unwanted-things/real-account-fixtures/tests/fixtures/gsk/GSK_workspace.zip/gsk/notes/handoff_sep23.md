GSK ABM handoff note (Sep 23, 2026), as received Sep 24

Goal: ABM account research run on GlaxoSmithKline Inc. / GSK per the abm-account-research skill, five deliverables, gate checks passed. Run complete; delivered.
Client: WilcoSource (via CitiusTech family). Scope global, Canada flagged. Paid pulls approved at Alcon depth.

Decisions made:
- Framing rule enforced: Vault CRM status recorded as Confirmed context only; positioning is AFLS/agentic AI plus Health Cloud patient services, never win-CRM-back or churn.
- People pull closed at 265 kept (35 A / 168 B / 62 C) from two BitScale passes, grid 8821071f-2524-425c-9787-212e9459f29f; manager pass, profile histories, posts, and Q3'25/Q1'26 call reads left as owner-funded options.
- Evidence Part E points to the jobs workbook rather than repeating 3,775 rows.

Key confirmed facts: prior relationship (2021 mutual CDA, 2020 pitch, 2021 Q&A, 2025 CitiusTech Project Elevate PODs incl. Experience Cloud HCP portal, S28 to S31); Vault CRM live across Europe, Kieron Scrutton fronting it (S37/S38); US patient services on Salesforce Health Cloud; agentic AI director role stating vendors build; ERP Evolution S/4HANA waves; ServiceNow senior owner hired Jul 2026 (J1 to J17, S33); Q2 2026 GBP 8.409B turnover, Accelerate Growth GBP 1.9B savings (S1 to S3); Tina Graves President and GM GSK Canada Sep 1 (S6); Mississauga Veeva director roles (J12, J16).

Open items: Suresh's CitiusTech GSK contact; clear Project Elevate for reference use; decide funded extensions.
