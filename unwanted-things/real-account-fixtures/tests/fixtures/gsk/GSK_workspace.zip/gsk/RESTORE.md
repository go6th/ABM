# GSK ABM workspace, RESTORE.md
Last updated: September 24, 2026. Client: WilcoSource (CitiusTech family). Skill: abm-account-research.

## How to restore
unzip GSK_workspace.zip to /home/claude, read this file, then read the skill's checklist.md, lessons.md and output-spec.md before touching anything.

## State
Run complete and delivered Sep 23. Sep 24 added two Sumble data pulls and, later that day, reduced S31 wording in both Word files to seller level; also (S40 confirmed used tech stack, S41 platform teams) and edited the Summary and Evidence files in place. No grade moved. Executive Brief deck is NOT wanted; kept in deliverables only as a record.

## What is in here
- deliverables/: current four files plus GSK_Tech_Stack_and_Teams.xlsx (confirmed used stack and platform teams; vendor links removed, they live in data/sumble/). prior_sep23/ holds the Sep 23 versions of the two Word files for diffing.
- build/patch_docs_sumble.py: the in-place XML edit that produced the Sep 24 Word files (unzip docx, run, rezip, validate, rowcheck).
- data/sumble/: raw Sumble results. Org id 131, slug gsk.
- notes/handoff_sep23.md: the handoff note this phase started from.
- NOT in this zip: the Sep 22 to 23 build scripts (summary.js, evidence.js, workbook builders) and the raw BitScale, PredictLeads and fetch data. They live in the chat that built the deliverables. If that chat produced a workspace zip, merge it into this folder; if not, the deliverables are the only record and edits must be made in place, never regenerated.

## Source IDs
S1 to S41, J1 to J17. S33 jobs (3,775), S34 news (158), S35 tech detections (1,344), S36 people (BitScale grid 8821071f-2524-425c-9787-212e9459f29f, 265 kept), S40 Sumble stack (182), S41 Sumble teams (40). Client files say "6th agents" for all paid pulls.

## Credits
Sep 24 Sumble: 430 used (6 lookup, 144 stack incl. a 72 credit repeat caused by file_name, 280 teams). 7,327 remaining after. Never set file_name on any Sumble call.

## Open items (owner decisions)
1. Suresh: CitiusTech GSK account contact flagged on the Sep 22 call; route family channel before outreach.
2. Clear Project Elevate (S31) for reference use.
3. Funded extensions on the 265 grid: manager pass, profile histories, post reads, Q3'25 and Q1'26 call reads.
4. S35 link repointed from an aggregator page to the jobs board (evidence base) on Sep 24. S32 Grain link removed; recording held by 6th, no public link.
5. Sumble signals are empty because GSK is not on a tracked list; add it to a Sumble account list if a feed is wanted.

## Drive boundary (added Sep 24)
S31 is a CitiusTech statement of work found by a whole Drive search; it sits in a WilcoSource owned folder (parent 1GK0msT8IMMNCGoC4DOXFBfli1erCCoF4, owner peterf@wilcosource.com). Do not open that folder or re-read S31. S28 to S30 came from the same search; ownership not checked. The files cite S31 at seller level only (no counterparties beyond CitiusTech, no budget, no signatories, no document number). A note to Pete asking whether that folder is in bounds was drafted Sep 24; outcome pending.

## Rules in force
No dashes as punctuation. No tool names in client files. No churn or win-CRM-back framing. Edit uploaded files in place. Never send anything; drafts only.

## Third party domains in the files (gate 9a, Sep 24)
Account and press: gsk.com, jobs.gsk.com, veeva.com, newswire.ca, cewit.org, ajbell.co.uk, finance.yahoo.com, cevalogistics.com, accessmarketintell.com, bioworld.com, freemalaysiatoday.com, biotecnika.com, fortune.com, cnbc.com, theguardian.com, reuters.com, sharedserviceslink.com, linkedin.com, drive.google.com (client files). Data tools: none. Aggregators, Lead grade and labeled: rfp.wiki (S19), casestudies.com (S20, S21), iotone.com (S22). Jobs workbook: openpaymentsdata.cms.gov appears inside posting text only.
