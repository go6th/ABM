"""Name the workspace import policy as an owner-private policy.

Revision ID: 0099
Revises: 0098
"""

from pathlib import Path

from alembic import op

revision = "0099"
down_revision = "0098"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Align the import policy name with the owner-isolation catalog."""
    sql = Path(__file__).resolve().parents[1] / "0099_workspace_import_owner_policy.sql"
    op.execute(sql.read_text())


def downgrade() -> None:
    """Restore the original policy name without changing its expression."""
    op.execute(
        "ALTER POLICY tenant_owner_isolation ON account_workspace_imports "
        "RENAME TO tenant_isolation"
    )
