"""Tenant-scoped, versioned imports of raw workspace ZIPs.

Revision ID: 0098
Revises: 0097
"""

import re
from pathlib import Path

from alembic import op

revision = "0098"
down_revision = "0097"
branch_labels = None
depends_on = None


def _function(sql: str, name: str) -> str:
    """Extract one complete CREATE OR REPLACE function statement from a migration."""
    found = re.search(rf"CREATE OR REPLACE FUNCTION {re.escape(name)}\(.*?END \$\$;", sql, re.S)
    if found is None:
        raise RuntimeError(f"migration source is missing function {name}")
    return found.group(0)


def upgrade() -> None:
    """Create the tenant import table and extend both approved erasure paths."""
    sql = Path(__file__).resolve().parents[1] / "0098_workspace_imports.sql"
    op.execute(sql.read_text())


def downgrade() -> None:
    """Restore the prior allow-lists and remove the import table."""
    root = Path(__file__).resolve().parents[1]
    tenant = _function((root / "0093_leakage_fix_wave_d2.sql").read_text(), "erase_rows")
    account_source = (root / "0096_purge_deleted_account.sql").read_text()
    account = _function(account_source, "purge_deleted_account")
    op.execute(tenant)
    marker = (
        "ALTER FUNCTION purge_deleted_account(uuid, uuid, boolean, text, boolean) "
        "OWNER TO account_purger;"
    )
    start = account_source.index(marker)
    end = account_source.index("TO account_purge_runner;", start) + len("TO account_purge_runner;")
    op.execute(account + "\n" + account_source[start:end])
    op.execute("DROP TABLE account_workspace_imports")
