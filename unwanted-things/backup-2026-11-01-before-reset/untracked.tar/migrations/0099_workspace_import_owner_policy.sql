-- Migration 0099: name raw workspace imports as owner-private rows in the isolation contract.
ALTER POLICY tenant_isolation ON account_workspace_imports RENAME TO tenant_owner_isolation;
