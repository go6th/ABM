"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { WorkspaceImportListReply, WorkspaceImportReply } from "@/lib/gen/api.gen";
import { StateCard } from "@/ui/design";

const MAX_BYTES = 100 * 1024 * 1024;
const VIEWS = [
  ["summary", "Summary"], ["news", "News"], ["evidence", "Sources & evidence"], ["jobs", "Jobs"],
  ["ranking", "Platform ranking"], ["stack", "Confirmed stack"], ["teams", "Teams"],
  ["people", "People"],
] as const;
type ViewKey = (typeof VIEWS)[number][0];
type ImportView = {
  available: boolean; reason: string | null; source_file: string | null;
  kind: "document" | "workbook" | null;
  blocks: Array<{ kind: string; style?: string; text?: string; rows?: string[][] }>;
  sheet_names: string[]; selected_sheet: string | null; header_candidates: string[];
  total_rows: number; offset: number; limit: number;
  rows: Array<Array<string | number | boolean | null>>;
};

function messageOf(error: unknown): string {
  if (error && typeof error === "object" && "message" in error) return String(error.message);
  return "The workspace could not be inspected. Try again.";
}

/** Inspect and browse client deliverables from a tenant-scoped reference import. */
export function WorkspaceImportPanel({ domain }: { domain: string }) {
  const path = `/v1/accounts/${encodeURIComponent(domain)}/workspace-imports`;
  const [imports, setImports] = useState<WorkspaceImportReply[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [active, setActive] = useState<WorkspaceImportReply | null>(null);
  const [view, setView] = useState<ViewKey>("summary");
  const [viewData, setViewData] = useState<ImportView | null>(null);
  const [viewBusy, setViewBusy] = useState(false);
  const [offset, setOffset] = useState(0);

  useEffect(() => {
    let mounted = true;
    void api<WorkspaceImportListReply>("GET", path)
      .then((result) => { if (mounted) setImports(result.imports); })
      .catch((reason: unknown) => { if (mounted) setError(messageOf(reason)); })
      .finally(() => { if (mounted) setLoaded(true); });
    return () => { mounted = false; };
  }, [path]);

  async function loadView(item: WorkspaceImportReply, viewName: ViewKey, start: number, sheet?: string) {
    setViewBusy(true);
    setError(null);
    const query = new URLSearchParams({ offset: String(start), limit: "100" });
    if (sheet) query.set("sheet", sheet);
    try {
      const result = await api<ImportView>(
        "GET", `${path}/${encodeURIComponent(item.id)}/views/${viewName}?${query.toString()}`,
      );
      setViewData(result);
    } catch (reason) {
      setViewData(null);
      setError(messageOf(reason));
    } finally { setViewBusy(false); }
  }

  function openView(item: WorkspaceImportReply, next: ViewKey) {
    setActive(item); setView(next); setOffset(0); void loadView(item, next, 0);
  }

  async function upload() {
    if (!file) return;
    if (file.size < 1 || file.size > MAX_BYTES || !file.name.toLowerCase().endsWith(".zip")) {
      setError("Choose a ZIP file between 1 byte and 100 MB."); return;
    }
    setBusy(true); setError(null);
    try {
      const query = new URLSearchParams({ filename: file.name });
      const created = await api<WorkspaceImportReply>("POST", `${path}?${query}`, file, { "Content-Type": "application/zip" });
      setImports((current) => [created, ...current]); setFile(null);
      const input = document.getElementById(`workspace-zip-${domain}`) as HTMLInputElement | null;
      if (input) input.value = "";
      setActive(created); setView("summary"); setOffset(0); await loadView(created, "summary", 0);
    } catch (reason) { setError(messageOf(reason)); }
    finally { setBusy(false); }
  }

  return (
    <section className="card pad stack-10" aria-labelledby="workspace-import-title">
      <div className="summary-head"><div>
        <h2 id="workspace-import-title">Import a reference workspace</h2>
        <p className="mut small">Inspect a ZIP and browse its client deliverables. Imported workspaces stay separate from live research; normalized parity is pending.</p>
      </div></div>
      <div className="row wrap gap-10 align-center">
        <label className="sr-only" htmlFor={`workspace-zip-${domain}`}>Workspace ZIP file</label>
        <input id={`workspace-zip-${domain}`} type="file" accept=".zip,application/zip" disabled={busy}
          onChange={(event) => setFile(event.target.files?.[0] ?? null)} aria-describedby={`workspace-zip-help-${domain}`} />
        <button className="btn primary" type="button" disabled={!file || busy} onClick={() => void upload()}>
          {busy ? "Inspecting…" : "Inspect workspace"}
        </button>
        <span id={`workspace-zip-help-${domain}`} className="mut small">ZIP only, up to 100 MB</span>
      </div>
      {error ? <StateCard title="Workspace request failed" body={error} /> : null}
      {loaded && !error && imports.length === 0 ? <p className="mut small">No reference workspaces have been imported for this account.</p> : null}
      {imports.length ? <div className="table-scroll"><table className="xl">
        <caption className="sr-only">Reference workspace imports</caption>
        <thead><tr><th scope="col">Version</th><th scope="col">File</th><th scope="col">Checked</th><th scope="col">Status</th><th scope="col">Deliverables</th><th scope="col">Views</th></tr></thead>
        <tbody>{imports.map((item) => <tr key={item.id}>
          <th scope="row">{item.version}</th><td>{item.filename}</td>
          <td>{new Date(item.created_at).toLocaleDateString()}</td>
          <td>Source available · parity pending</td><td>{item.validation.deliverables_found} of 5</td>
          <td><button className="btn" type="button" onClick={() => openView(item, "summary")}>Open views</button></td>
        </tr>)}</tbody>
      </table></div> : null}
      {active ? <section className="stack-10" aria-label={`Workspace version ${active.version} views`}>
        <div className="row wrap gap-10 align-center">
          <strong>Version {active.version} deliverables</strong>
          <a className="btn" href={`${path}/${encodeURIComponent(active.id)}/downloads`}>Download client deliverables</a>
        </div>
        <div className="row wrap gap-10" role="tablist" aria-label="Workspace deliverable views">
          {VIEWS.map(([key, label]) => <button key={key} type="button" role="tab" aria-selected={view === key}
            className={view === key ? "btn primary" : "btn"} onClick={() => openView(active, key)}>{label}</button>)}
        </div>
        {viewBusy ? <p className="mut small" role="status">Loading deliverable…</p> : null}
        {viewData && !viewBusy && !viewData.available ? <StateCard title="View unavailable" body={viewData.reason ?? "This source view is unavailable."} /> : null}
        {viewData?.available && viewData.kind === "document" ? <article className="card pad stack-10" aria-label={viewData.source_file ?? "Workspace document"}>
          {viewData.blocks.map((block, index) => block.kind === "table" ? <div className="table-scroll" key={index}>
            <table className="xl"><tbody>{(block.rows ?? []).map((row, rowIndex) => <tr key={rowIndex}>{row.map((cell, cellIndex) => <td key={cellIndex}>{cell}</td>)}</tr>)}</tbody></table>
          </div> : <p key={index} className={block.style?.toLowerCase().includes("heading") ? "strong" : undefined}>{block.text}</p>)}
        </article> : null}
        {viewData?.available && viewData.kind === "workbook" ? <div className="stack-10">
          <div className="row wrap gap-10 align-center"><span className="mut small">{viewData.source_file} · {viewData.selected_sheet} · {viewData.total_rows} rows</span>
            {viewData.sheet_names.length > 1 ? <label>Sheet <select value={viewData.selected_sheet ?? ""} onChange={(event) => { setOffset(0); void loadView(active, view, 0, event.target.value); }}>
              {viewData.sheet_names.map((name) => <option key={name}>{name}</option>)}
            </select></label> : null}
          </div>
          <div className="table-scroll"><table className="xl"><caption className="sr-only">{viewData.source_file}, {viewData.selected_sheet}</caption>
            <thead><tr>{viewData.header_candidates.map((header, index) => <th key={index} scope="col">{header || `Column ${index + 1}`}</th>)}</tr></thead>
            <tbody>{(offset === 0 ? viewData.rows.slice(1) : viewData.rows).map((row, rowIndex) => <tr key={offset + rowIndex}>{row.map((cell, cellIndex) => <td key={cellIndex}>{cell === null ? "" : String(cell)}</td>)}</tr>)}</tbody>
          </table></div>
          <div className="row gap-10 align-center">
            <button className="btn" type="button" disabled={offset <= 0 || viewBusy} onClick={() => { const next = Math.max(0, offset - 100); setOffset(next); void loadView(active, view, next); }}>Previous</button>
            <span className="mut small">Rows {Math.min(offset + 1, viewData.total_rows)}–{Math.min(offset + viewData.rows.length, viewData.total_rows)} of {viewData.total_rows}</span>
            <button className="btn" type="button" disabled={offset + 100 >= viewData.total_rows || viewBusy} onClick={() => { const next = offset + 100; setOffset(next); void loadView(active, view, next); }}>Next</button>
          </div>
        </div> : null}
      </section> : null}
    </section>
  );
}
