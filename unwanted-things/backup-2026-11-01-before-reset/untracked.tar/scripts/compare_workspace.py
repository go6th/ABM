"""Compare two sets of client deliverables without printing document or cell content."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from parity.compare_workspace import compare_workspace


def main() -> int:
    """Print the content-free comparison report and return nonzero on mismatch."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("golden", type=Path)
    parser.add_argument("rebuilt", type=Path)
    args = parser.parse_args()
    report = compare_workspace(args.golden, args.rebuilt)
    print(json.dumps(report, sort_keys=True))
    return 0 if report["equal"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
