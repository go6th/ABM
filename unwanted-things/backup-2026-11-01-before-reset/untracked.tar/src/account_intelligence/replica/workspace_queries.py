"""Run a workspace's explicitly compiled RESTORE queries over its owner-private tables.

This path is deliberately conservative: a question must identify exactly one compiled query,
the imported query must be marked derivable, and all matching rows must fit the table store's
complete-set bound. No expected answer counts from RESTORE.md are used as computed results.
"""

from __future__ import annotations

import re
from collections import Counter
from collections.abc import Mapping, Sequence
from typing import Any
from uuid import UUID

from sqlalchemy import text

from documents import tables as T

_WORD = re.compile(r"[a-z0-9]+", re.I)
_GENERIC = frozenset(
    [
        "a",
        "an",
        "and",
        "are",
        "at",
        "by",
        "count",
        "counts",
        "for",
        "from",
        "how",
        "in",
        "is",
        "list",
        "me",
        "of",
        "on",
        "or",
        "postings",
        "posting",
        "show",
        "the",
        "these",
        "this",
        "to",
        "total",
        "what",
        "which",
        "with",
        "jobs",
        "job",
        "people",
        "person",
        "roles",
        "role",
        "rows",
    ]
)


def _tokens(value: Any) -> set[str]:
    return {word.casefold() for word in _WORD.findall(str(value or "")) if len(word) > 1}


def _query_score(question: str, query: Mapping[str, Any]) -> int:
    words = _tokens(question)
    label = _tokens(query.get("query")) - _GENERIC
    values = set()
    columns = set()
    for predicate in query.get("where", []):
        values |= _tokens(predicate.get("value")) - _GENERIC
        columns |= _tokens(predicate.get("column")) - _GENERIC
    return 3 * len(words & label) + 2 * len(words & values) + len(words & columns)


def match_canonical_query(
    question: str, queries: Sequence[Mapping[str, Any]]
) -> Mapping[str, Any] | None:
    """Return one unambiguous query candidate, or leave the question on normal Ask routing."""
    ranked = sorted(
        ((_query_score(question, query), query) for query in queries if query.get("derivable")),
        key=lambda item: item[0],
        reverse=True,
    )
    if not ranked or ranked[0][0] < 2:
        return None
    if len(ranked) > 1 and ranked[0][0] == ranked[1][0]:
        return None
    return ranked[0][1]


def _table_for_query(
    tables: Sequence[T.TableInfo], version: int, query: Mapping[str, Any]
) -> T.TableInfo | None:
    role = str(query.get("role") or "").casefold()
    sheet = str(query.get("sheet") or "").casefold()
    prefix = f"workspace v{version} {role}"
    matches = [
        table
        for table in tables
        if table.document.casefold().startswith(prefix)
        and table.table.casefold().endswith(f": {sheet}")
    ]
    return matches[0] if len(matches) == 1 else None


def _where(query: Mapping[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Translate the safe RESTORE subset to table-store ops plus exact prefix checks."""
    sql_where: list[dict[str, Any]] = []
    prefix_where: list[dict[str, Any]] = []
    for predicate in query.get("where", []):
        operator = predicate.get("op")
        mapped = {
            "equals": "eq",
            "not_equals": "neq",
            "contains": "icontains",
            "in": "in",
        }.get(operator)
        value = predicate.get("value")
        if operator == "starts_with":
            prefix_where.append({"column": predicate["column"], "value": str(value)})
        elif mapped:
            sql_where.append({"column": predicate["column"], "op": mapped, "value": value})
        else:
            raise ValueError("unsupported canonical operator")
    return sql_where, prefix_where


async def _run(
    session: Any,
    table: T.TableInfo,
    predicates: Sequence[Mapping[str, Any]],
) -> tuple[int, list[dict[str, Any]]] | None:
    """Run a complete result set, returning None when the store cannot prove completeness."""
    sql_where, prefix_where = _where({"where": predicates})
    parsed = T.parse(table, {"where": sql_where, "limit": T.MAX_LIMIT})
    result = await T.run(session, parsed)
    if result["truncated"]:
        return None
    rows = result["rows"]
    for predicate in prefix_where:
        column = T._column(table, predicate["column"]).name
        prefix = predicate["value"].casefold()
        rows = [
            row for row in rows if str(row["cells"].get(column) or "").casefold().startswith(prefix)
        ]
    return len(rows), rows


def _cell(table: T.TableInfo, row: Mapping[str, Any], label: str) -> Any:
    """Find a non-payload cell by its raw or normalized heading."""
    wanted = re.sub(r"[^a-z0-9]", "", label.casefold())
    for column in table.columns:
        if (
            re.sub(r"[^a-z0-9]", "", column.raw.casefold()) == wanted
            or re.sub(r"[^a-z0-9]", "", column.name.casefold()) == wanted
        ):
            return row.get("cells", {}).get(column.name)
    return None


def _has_column(table: T.TableInfo, label: str) -> bool:
    wanted = re.sub(r"[^a-z0-9]", "", label.casefold())
    return any(
        re.sub(r"[^a-z0-9]", "", column.raw.casefold()) == wanted
        or re.sub(r"[^a-z0-9]", "", column.name.casefold()) == wanted
        for column in table.columns
    )


def _reply(
    query: Mapping[str, Any],
    table: T.TableInfo,
    strict: tuple[int, list[dict[str, Any]]],
    relaxed: tuple[int, list[dict[str, Any]]] | None,
) -> str:
    """Write only figures computed from the stored rows, with the configured base attached."""
    count, rows = strict
    label = str(query.get("query") or "Workspace query")
    base = str(query.get("base") or "").strip()
    if count == 0 and relaxed is not None:
        predicates = query.get("where", [])
        removed = predicates[-1] if predicates else None
        removed_text = (
            f" after relaxing {removed['column']} {removed['op']} {removed['value']}"
            if removed
            else ""
        )
        return (
            f"The strict {label} query returned **0** rows. The nearest relaxed set"
            f"{removed_text} returned **{relaxed[0]}** rows." + (f" Base: {base}." if base else "")
        )

    role = str(query.get("role") or "").casefold()
    where = query.get("where", [])
    if role == "tech" and _has_column(table, "Platform") and _has_column(table, "Rank"):
        by_rank: dict[str, list[str]] = {}
        for row in rows:
            platform = str(_cell(table, row, "Platform") or "").strip()
            rank = str(_cell(table, row, "Rank") or "").strip().upper()
            if platform and rank:
                by_rank.setdefault(rank, []).append(platform)
        ranking = "; ".join(
            f"{rank}: {', '.join(platforms)}" for rank, platforms in sorted(by_rank.items())
        )
        result = f"Platform ranking from the imported sheet: {ranking or 'no ranked platforms'}."
    elif (
        role == "jobs"
        and _has_column(table, "Status")
        and "open" in str(query.get("answer", "")).casefold()
    ):
        open_count = sum(
            "open" in str(_cell(table, row, "Status") or "").casefold() for row in rows
        )
        open_verb = "is" if open_count == 1 else "are"
        result = f"{count} matching job postings; {open_count} {open_verb} open."
    elif (
        role == "people"
        and _has_column(table, "Priority")
        and any(str(item.get("column", "")).casefold() == "meets seniority rule" for item in where)
    ):
        priority_a = sum(
            str(_cell(table, row, "Priority") or "").strip().casefold() == "a" for row in rows
        )
        result = (
            f"{count} of {table.row_count} people meet the seniority rule; {priority_a}"
            " of those are Priority A."
        )
    elif role == "jobs" and any(
        str(item.get("column", "")).casefold() == "class"
        and str(item.get("value", "")).casefold() == "build role"
        for item in where
    ):
        platform_counts: Counter[str] = Counter()
        for row in rows:
            value = _cell(table, row, "Platforms named")
            for platform in re.split(r"[,;|]", str(value or "")):
                platform = platform.strip()
                if platform:
                    platform_counts[platform] += 1
        counts = ", ".join(
            f"{name}: {number}"
            for name, number in sorted(platform_counts.items(), key=lambda x: x[0].casefold())
        )
        result = f"{count} build-role postings by platform: {counts or 'no platform values'}."
    else:
        result = f"{count} matching rows in {table.table}."
    return result + (f" Base: {base}." if base else "")


async def evaluate_canonical_query(
    session: Any,
    *,
    account_id: UUID,
    tables: Sequence[T.TableInfo],
    question: str,
) -> dict[str, Any] | None:
    """Resolve latest import metadata to its typed table and calculate a canonical answer."""
    import_row = (
        await session.execute(
            text("""SELECT version, config_json FROM account_workspace_imports
                     WHERE account_id = :account_id ORDER BY version DESC LIMIT 1"""),
            {"account_id": account_id},
        )
    ).first()
    if import_row is None:
        return None
    config = import_row.config_json
    if not isinstance(config, Mapping):
        return None
    queries = config.get("canonical_queries")
    if not isinstance(queries, list):
        return None
    query = match_canonical_query(question, queries)
    if query is None:
        return None
    table = _table_for_query(tables, int(import_row.version), query)
    if table is None:
        return None
    try:
        strict = await _run(session, table, query.get("where", []))
        if strict is None:
            return None
        relaxed = None
        if strict[0] == 0 and query.get("where"):
            relaxed = await _run(session, table, query["where"][:-1])
        return {
            "query": query,
            "table": table,
            "text": _reply(query, table, strict, relaxed),
            "count": strict[0],
            "relaxed_count": relaxed[0] if relaxed is not None else None,
        }
    except (T.QueryError, KeyError, TypeError, ValueError):
        return None
