"""Database statements for raw workspace imports.

The API owns validation and HTTP responses; this repository owns every query on the import table.
Callers use it inside ``tenant_txn`` so RLS supplies tenant and owner scope.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, cast
from uuid import UUID

from sqlalchemy import text


async def next_version(session: Any, account_id: UUID) -> int:
    """Lock one account and allocate its next owner-visible import version."""
    await session.execute(
        text("SELECT id FROM accounts WHERE id = :id FOR UPDATE"), {"id": account_id}
    )
    return int(
        await session.scalar(
            text(
                "SELECT COALESCE(MAX(version), 0) + 1"
                " FROM account_workspace_imports WHERE account_id = :account_id"
            ),
            {"account_id": account_id},
        )
    )


async def create(
    session: Any,
    *,
    import_id: UUID,
    owner_user_id: str,
    account_id: UUID,
    version: int,
    filename: str,
    sha256: str,
    object_key: str,
    config: str,
    validation: str,
    status: str,
) -> datetime:
    """Insert a new import record and return its database timestamp."""
    result = await session.execute(
        text(
            "INSERT INTO account_workspace_imports"
            " (id, tenant_id, owner_user_id, account_id, version, filename, sha256,"
            " object_key, config_json, validation_json, status)"
            " VALUES (:id, (SELECT app_tenant()), :owner, :account_id, :version, :filename,"
            " :sha256, :object_key, CAST(:config AS jsonb), CAST(:validation AS jsonb), :status)"
            " RETURNING created_at"
        ),
        {
            "id": import_id,
            "owner": owner_user_id,
            "account_id": account_id,
            "version": version,
            "filename": filename,
            "sha256": sha256,
            "object_key": object_key,
            "config": config,
            "validation": validation,
            "status": status,
        },
    )
    return cast(datetime, result.scalar_one())


async def list_for_account(session: Any, account_id: UUID) -> list[dict[str, Any]]:
    """List the latest imports visible to this account owner."""
    result = await session.execute(
        text(
            "SELECT id, version, filename, sha256, status, created_at, config_json, validation_json"
            " FROM account_workspace_imports WHERE account_id = :account_id"
            " ORDER BY version DESC LIMIT 100"
        ),
        {"account_id": account_id},
    )
    return [dict(row) for row in result.mappings().all()]


async def get_version(session: Any, account_id: UUID, import_id: UUID) -> int | None:
    """Return one import version, or None when owner/account scope cannot see it."""
    value = await session.scalar(
        text(
            "SELECT version FROM account_workspace_imports"
            " WHERE id = :id AND account_id = :account_id"
        ),
        {"id": import_id, "account_id": account_id},
    )
    return int(value) if value is not None else None


async def exists(session: Any, account_id: UUID, import_id: UUID) -> bool:
    """Check one import under tenant and owner RLS."""
    value = await session.scalar(
        text(
            "SELECT id FROM account_workspace_imports WHERE id = :id AND account_id = :account_id"
        ),
        {"id": import_id, "account_id": account_id},
    )
    return value is not None
