"""Compare rebuilt legacy deliverables with their shipped golden files, without printing content.

The comparison report contains role names and difference counts only. Workbook cell values and
document text remain in the caller's local workspace and are never included in diagnostics.
"""

from __future__ import annotations

import math
import re
from datetime import date, datetime
from pathlib import Path
from typing import Any

from docx import Document
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P
from docx.table import Table
from docx.text.paragraph import Paragraph
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

_ROLES = {
    "summary": ("accountsummary", ".docx"),
    "evidence": ("sourcesandevidence", ".docx"),
    "people": ("peoplelist", ".xlsx"),
    "jobs": ("jobpostings", ".xlsx"),
    "tech": ("techstackandteams", ".xlsx"),
}
_INTERNAL = re.compile(r"(^|[/_. -])(internal|operator)[_ -]?only([/_. -]|$)", re.IGNORECASE)
_DATE_FORMATS = ("%d %B %Y", "%d %b %Y", "%Y/%m/%d", "%m/%d/%Y")


def _normalize(value: Any) -> Any:
    """Normalize whitespace and common date representations without changing other values."""
    if isinstance(value, datetime):
        if value.time().isoformat() == "00:00:00":
            return ("date", value.date().isoformat())
        return ("date", value.isoformat())
    if isinstance(value, date):
        return ("date", value.isoformat())
    if isinstance(value, str):
        text = re.sub(r"\s+", " ", value).strip()
        if not text:
            return ""
        try:
            return ("date", date.fromisoformat(text).isoformat())
        except ValueError:
            pass
        for fmt in _DATE_FORMATS:
            try:
                return ("date", datetime.strptime(text, fmt).date().isoformat())
            except ValueError:
                continue
        return text
    if isinstance(value, float) and math.isnan(value):
        return ("float", "nan")
    return value


def _role(path: Path) -> str | None:
    if _INTERNAL.search(path.as_posix()):
        return None
    normalized = re.sub(r"[^a-z0-9]", "", path.stem.casefold())
    for role, (marker, suffix) in _ROLES.items():
        if path.suffix.casefold() == suffix and marker in normalized:
            return role
    return None


def _discover(directory: Path) -> dict[str, list[Path]]:
    found: dict[str, list[Path]] = {role: [] for role in _ROLES}
    for path in directory.rglob("*"):
        if path.is_file():
            role = _role(path)
            if role is not None:
                found[role].append(path)
    return found


def _workbook_values(path: Path) -> dict[str, tuple[int, int, tuple[tuple[Any, ...], ...]]]:
    workbook = load_workbook(path, read_only=True, data_only=False)
    try:
        return {
            sheet.title: (
                sheet.max_row or 0,
                sheet.max_column or 0,
                tuple(
                    tuple(_normalize(cell.value) for cell in row)
                    for row in sheet.iter_rows(values_only=False)
                ),
            )
            for sheet in workbook.worksheets
        }
    finally:
        workbook.close()


def _document_values(path: Path) -> tuple[tuple[Any, ...], ...]:
    document = Document(str(path))
    records: list[tuple[Any, ...]] = []
    for child in document.element.body.iterchildren():
        if isinstance(child, CT_P):
            paragraph = Paragraph(child, document)
            style_name = paragraph.style.name if paragraph.style is not None else ""
            records.append(("paragraph", style_name or "", _normalize(paragraph.text)))
        elif isinstance(child, CT_Tbl):
            table = Table(child, document)
            rows = tuple(tuple(_normalize(cell.text) for cell in row.cells) for row in table.rows)
            records.append(("table", rows))
    return tuple(records)


def _compare_role(role: str, golden: list[Path], rebuilt: list[Path]) -> dict[str, Any]:
    if len(golden) != 1 or len(rebuilt) != 1:
        return {
            "equal": False,
            "golden_files": len(golden),
            "rebuilt_files": len(rebuilt),
            "differences": 1,
            "reason": "missing_or_ambiguous",
        }
    extension = _ROLES[role][1]
    if extension == ".xlsx":
        left, right = _workbook_values(golden[0]), _workbook_values(rebuilt[0])
        sheet_names_equal = tuple(left) == tuple(right)
        dimension_differences = sum(
            1
            for name in set(left) | set(right)
            if (left[name][:2] if name in left else None)
            != (right[name][:2] if name in right else None)
        )
        content_differences = 0
        cell_locations: list[str] = []
        for name in set(left) | set(right):
            left_rows = left[name][2] if name in left else ()
            right_rows = right[name][2] if name in right else ()
            width = max(
                left[name][1] if name in left else 0,
                right[name][1] if name in right else 0,
            )
            row_count = max(len(left_rows), len(right_rows))
            for row_index in range(row_count):
                lrow = left_rows[row_index] if row_index < len(left_rows) else ()
                rrow = right_rows[row_index] if row_index < len(right_rows) else ()
                for column_index in range(width):
                    lv = lrow[column_index] if column_index < len(lrow) else None
                    rv = rrow[column_index] if column_index < len(rrow) else None
                    if lv != rv:
                        content_differences += 1
                        if len(cell_locations) < 100:
                            cell_locations.append(
                                f"{name}!{get_column_letter(column_index + 1)}{row_index + 1}"
                            )
        shape_differences = dimension_differences + int(not sheet_names_equal)
        return {
            "equal": shape_differences == 0 and content_differences == 0,
            "golden_files": 1,
            "rebuilt_files": 1,
            "sheet_names_equal": sheet_names_equal,
            "sheet_dimension_differences": dimension_differences,
            "cell_differences": content_differences,
            "cell_locations": sorted(cell_locations),
            "differences": shape_differences + content_differences,
        }
    left_doc, right_doc = _document_values(golden[0]), _document_values(rebuilt[0])
    differences = sum(
        1
        for index in range(max(len(left_doc), len(right_doc)))
        if (left_doc[index] if index < len(left_doc) else None)
        != (right_doc[index] if index < len(right_doc) else None)
    )
    return {
        "equal": differences == 0,
        "golden_files": 1,
        "rebuilt_files": 1,
        "structure_differences": differences,
        "differences": differences,
    }


def compare_workspace(golden_dir: Path, rebuilt_dir: Path) -> dict[str, Any]:
    """Compare the five client deliverables and return a content-free report."""
    golden = _discover(golden_dir)
    rebuilt = _discover(rebuilt_dir)
    roles = {name: _compare_role(name, golden[name], rebuilt[name]) for name in _ROLES}
    return {"equal": all(item["equal"] for item in roles.values()), "roles": roles}
