"""Persist imported client workbook sheets in the account's existing structured table store.

The source workbooks are already deduplicated deliverables. This adapter preserves every data
row and its order; it does not run the live repair pipeline or infer classifications.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime
from statistics import median
from typing import Any
from uuid import UUID, uuid5

from documents import repo
from documents.chunking import Column, normalise_column
from tenancy.storage import account_path, require_owned

_PAYLOAD_HEADER = re.compile(r"description|sentence|summary|note|extract|quote|text", re.I)
_ISO_DAY = re.compile(r"^\d{4}-\d{2}-\d{2}(?:T.*)?$")


def _kind(value: Any) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int | float):
        return "number"
    if isinstance(value, str) and _ISO_DAY.fullmatch(value):
        return "date"
    return "text"


def _schema(
    sheet: dict[str, Any], header_candidates: list[str] | None = None
) -> tuple[dict[str, Any], list[tuple[int, int, dict[str, Any]]]]:
    """Make the existing typed column metadata and row cells from a parsed worksheet."""
    rows = sheet.get("rows", [])
    if not rows:
        return {"columns": [], "payload_columns": [], "business_key": None}, []
    header_row = 0
    wanted = {value.casefold() for value in (header_candidates or ()) if value}
    if wanted:
        candidate_rows = rows[:100]
        header_row = max(
            range(len(candidate_rows)),
            key=lambda index: (
                len(
                    {
                        str(value).strip().casefold()
                        for value in candidate_rows[index]
                        if value is not None
                    }
                    & wanted
                ),
                sum(
                    value is not None and str(value).strip() != ""
                    for value in candidate_rows[index]
                ),
                -index,
            ),
        )
    header = [str(value or "").strip() for value in rows[header_row]]
    taken: set[str] = set()
    columns = [
        Column(normalise_column(value, taken, index), value or f"column {index + 1}")
        for index, value in enumerate(header)
    ]
    body = rows[header_row + 1 :]
    for index, column in enumerate(columns):
        values = [row[index] for row in body if index < len(row) and row[index] is not None]
        nonempty = [value for value in values if str(value).strip()]
        column.payload = bool(
            _PAYLOAD_HEADER.search(column.raw)
            or (nonempty and median(len(str(value)) for value in nonempty) > 500)
        )
        for value in nonempty:
            kind = _kind(value)
            column.tally(kind)
            if kind == "text":
                parts = [part.strip() for part in re.split(r"[,;|]", str(value)) if part.strip()]
                if len(parts) > 1 and all(len(part) <= 80 for part in parts):
                    column.lists += 1
                    for part in parts:
                        column.note_value(part)
                else:
                    column.note_value(str(value))
    schema_columns = []
    for column in columns:
        record = {
            "name": column.name,
            "raw": column.raw,
            "type": column.type,
            "payload": column.payload,
            "multi_valued": column.multi_valued,
            "dates": column.dates,
            "numbers": column.numbers,
            "texts": column.texts,
            "booleans": column.booleans,
            "lists": column.lists,
            "aliases": [],
            "values": [],
        }
        from documents.chunking import column_aliases

        record["aliases"] = column_aliases(column.raw, column.name, column.type)
        if column.values is not None and column.type == "text" and not column.payload:
            record["values"] = sorted(column.values, key=str.casefold)
        schema_columns.append(record)

    stored_rows: list[tuple[int, int, dict[str, Any]]] = []
    for row_no, row in enumerate(body, start=header_row + 2):
        cells = {
            column.name: row[index] if index < len(row) else None
            for index, column in enumerate(columns)
        }
        if any(value is not None and str(value).strip() for value in cells.values()):
            stored_rows.append((row_no, row_no, cells))
    return {
        "columns": schema_columns,
        "payload_columns": [column.name for column in columns if column.payload],
        "business_key": None,
    }, stored_rows


async def store_workspace_workbooks(
    session: Any,
    *,
    tenant_id: UUID,
    account_id: UUID,
    import_id: UUID,
    owner_user_id: str,
    version: int,
    imported_at: datetime,
    workbooks: dict[str, tuple[str, bytes]],
    parsed_views: dict[str, bytes],
    header_candidates: dict[str, dict[str, list[str]]],
    payloads: Any,
) -> None:
    """Store original workbook bytes and all parsed rows for Ask's typed table tools."""
    for role in ("people", "jobs", "tech"):
        source = workbooks.get(role)
        encoded = parsed_views.get(role)
        if source is None or encoded is None:
            continue
        filename, body = source
        object_key = account_path(
            tenant_id, account_id, "workspaces", str(import_id), "source-files", f"{role}.xlsx"
        )
        require_owned(tenant_id, object_key)
        await payloads.put(object_key, body)
        document_id = uuid5(import_id, f"workspace-table:{role}")
        digest = hashlib.sha256(body).hexdigest()
        await repo.create_imported_workbook(
            session,
            document_id=document_id,
            account_id=account_id,
            name=f"Workspace v{version} {role.title()} · {filename}",
            size_bytes=len(body),
            sha256=digest,
            object_key=object_key,
            uploaded_by=owner_user_id,
            imported_at=imported_at,
        )
        workbook = json.loads(encoded)
        for sheet in workbook.get("sheets", []):
            candidates = header_candidates.get(role, {}).get(str(sheet.get("name", "")), [])
            schema, stored_rows = _schema(sheet, candidates)
            table_name = f"Workspace v{version}: {sheet.get('name') or role}"
            table_id = await repo.ensure_table(
                session, document_id, account_id, table_name, filename
            )
            await repo.write_table_rows(session, table_id, document_id, account_id, 0, stored_rows)
            await repo.set_table_schema(session, table_id, schema)
