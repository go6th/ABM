"""Read the five client deliverables from a checked workspace ZIP, without running its builders.

The returned view payloads are private, structured copies for paging APIs. The download archive
contains only those deliverables; internal-only files and all build/data inputs are excluded.
"""

from __future__ import annotations

import io
import json
import math
import zipfile
from dataclasses import dataclass
from datetime import date, datetime, time
from pathlib import PurePosixPath
from typing import Any
from xml.etree import ElementTree as ET

from openpyxl import load_workbook

from exports.repair.ingest import _WORD_NS, WorkspaceInspection

MAX_WORKSHEET_ROWS = 10_000
MAX_WORKSHEET_COLUMNS = 128
MAX_CELL_CHARS = 65_536
MAX_TOTAL_VIEW_BYTES = 32 * 1024 * 1024
_ROLE_EXTENSIONS = {
    "summary": ".docx",
    "evidence": ".docx",
    "people": ".xlsx",
    "jobs": ".xlsx",
    "tech": ".xlsx",
}


@dataclass(frozen=True)
class WorkspaceViewPayloads:
    """Owner-private view objects plus the public-deliverables-only download archive."""

    views: dict[str, bytes]
    source_files: dict[str, tuple[str, bytes]]
    download: bytes | None
    issues: tuple[str, ...]


def _cell_value(value: Any) -> str | int | float | bool | None:
    if value is None or isinstance(value, (str, int, float, bool)):
        if isinstance(value, float) and not math.isfinite(value):
            return str(value)
        if isinstance(value, str) and len(value) > MAX_CELL_CHARS:
            raise ValueError("cell text exceeds view limit")
        return value
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, time):
        return value.isoformat()
    return str(value)[:MAX_CELL_CHARS]


def _workbook_view(path: str, raw: bytes) -> dict[str, Any]:
    workbook = load_workbook(io.BytesIO(raw), read_only=True, data_only=True, keep_links=False)
    try:
        sheets: list[dict[str, Any]] = []
        for sheet in workbook.worksheets:
            row_count = sheet.max_row or 0
            column_count = sheet.max_column or 0
            if row_count > MAX_WORKSHEET_ROWS or column_count > MAX_WORKSHEET_COLUMNS:
                raise ValueError("worksheet exceeds view row or column limit")
            rows: list[list[str | int | float | bool | None]] = []
            for row in sheet.iter_rows(values_only=True):
                if len(rows) >= MAX_WORKSHEET_ROWS:
                    raise ValueError("worksheet exceeds view row limit")
                if len(row) > MAX_WORKSHEET_COLUMNS:
                    raise ValueError("worksheet exceeds view column limit")
                rows.append([_cell_value(value) for value in row])
            sheets.append(
                {
                    "name": sheet.title,
                    "row_count": row_count,
                    "column_count": column_count,
                    "rows": rows,
                }
            )
        return {"source_file": PurePosixPath(path).name, "kind": "workbook", "sheets": sheets}
    finally:
        workbook.close()


def _text(element: ET.Element) -> str:
    pieces: list[str] = []
    for node in element.iter():
        if node.tag == f"{{{_WORD_NS}}}t":
            pieces.append(node.text or "")
        elif node.tag == f"{{{_WORD_NS}}}tab":
            pieces.append("\t")
        elif node.tag in {f"{{{_WORD_NS}}}br", f"{{{_WORD_NS}}}cr"}:
            pieces.append("\n")
    text = "".join(pieces)
    if len(text) > MAX_CELL_CHARS:
        raise ValueError("document text exceeds view limit")
    return text


def _docx_view(path: str, raw: bytes) -> dict[str, Any]:
    with zipfile.ZipFile(io.BytesIO(raw)) as package:
        if "word/document.xml" not in package.namelist():
            raise ValueError("document body is missing")
        document = ET.fromstring(package.read("word/document.xml"))
        style_names: dict[str, str] = {}
        try:
            styles = ET.fromstring(package.read("word/styles.xml"))
            for style in styles.findall(f"{{{_WORD_NS}}}style"):
                name = style.find(f"{{{_WORD_NS}}}name")
                if name is not None:
                    style_names[style.attrib.get(f"{{{_WORD_NS}}}styleId", "")] = name.attrib.get(
                        f"{{{_WORD_NS}}}val", ""
                    )
        except KeyError:
            pass
        body = document.find(f"{{{_WORD_NS}}}body")
        blocks: list[dict[str, Any]] = []
        if body is not None:
            for child in body:
                if child.tag == f"{{{_WORD_NS}}}p":
                    style_node = child.find(f"{{{_WORD_NS}}}pPr/{{{_WORD_NS}}}pStyle")
                    style_id = (
                        style_node.attrib.get(f"{{{_WORD_NS}}}val", "")
                        if style_node is not None
                        else ""
                    )
                    blocks.append(
                        {
                            "kind": "paragraph",
                            "style": style_names.get(style_id, style_id),
                            "text": _text(child),
                        }
                    )
                elif child.tag == f"{{{_WORD_NS}}}tbl":
                    rows = []
                    for row in child.findall(f"{{{_WORD_NS}}}tr"):
                        rows.append(
                            [
                                "\n".join(_text(p) for p in cell.findall(f"{{{_WORD_NS}}}p"))
                                for cell in row.findall(f"{{{_WORD_NS}}}tc")
                            ]
                        )
                    blocks.append({"kind": "table", "rows": rows})
        return {"source_file": PurePosixPath(path).name, "kind": "document", "blocks": blocks}


def _json_bytes(value: dict[str, Any]) -> bytes:
    payload = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(payload) > MAX_TOTAL_VIEW_BYTES:
        raise ValueError("parsed view exceeds storage limit")
    return payload


def build_workspace_view_payloads(
    raw_archive: bytes, inspection: WorkspaceInspection
) -> WorkspaceViewPayloads:
    """Build bounded JSON views and a clean download ZIP from deliverables only."""
    views: dict[str, bytes] = {}
    source_files: dict[str, tuple[str, bytes]] = {}
    issues: list[str] = []
    deliverables = dict(inspection.deliverables)
    try:
        archive = zipfile.ZipFile(io.BytesIO(raw_archive))
    except (zipfile.BadZipFile, OSError) as error:
        raise ValueError("workspace ZIP could not be reopened") from error

    download_out = io.BytesIO()
    total_view_bytes = 0
    with archive, zipfile.ZipFile(download_out, "w", compression=zipfile.ZIP_DEFLATED) as download:
        members = {item.filename: item for item in archive.infolist()}
        for role, path in deliverables.items():
            item = members.get(path)
            if item is None or item.is_dir():
                issues.append(f"{role}:deliverable_unreadable")
                continue
            try:
                body = archive.read(item)
                view = (
                    _docx_view(path, body)
                    if _ROLE_EXTENSIONS[role] == ".docx"
                    else _workbook_view(path, body)
                )
                encoded = _json_bytes(view)
            except (KeyError, ValueError, OSError, ET.ParseError, zipfile.BadZipFile, RuntimeError):
                issues.append(f"{role}:view_unavailable")
                continue
            if total_view_bytes + len(encoded) > MAX_TOTAL_VIEW_BYTES:
                issues.append(f"{role}:view_total_limit")
                continue
            views[role] = encoded
            source_files[role] = (PurePosixPath(path).name, body)
            total_view_bytes += len(encoded)
            download.writestr(f"deliverables/{PurePosixPath(path).name}", body)

    download_body = download_out.getvalue() if deliverables else None
    if download_body is not None and len(download_body) > 100 * 1024 * 1024:
        download_body = None
        issues.append("downloads:archive_limit")
    return WorkspaceViewPayloads(views, source_files, download_body, tuple(issues))
