"""Inspect an uploaded legacy workspace archive without extracting or executing it.

This is a pure boundary: it reads a bounded ZIP from memory and returns paths, structural
metadata and validation issues. Contents are not sent to a model, object store or logger here.
"""

from __future__ import annotations

import ast
import io
import json
import re
import stat
import zipfile
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import PurePosixPath
from typing import Any
from xml.etree import ElementTree as ET

MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
MAX_MEMBERS = 1_000
MAX_MEMBER_BYTES = 64 * 1024 * 1024
MAX_TOTAL_BYTES = 512 * 1024 * 1024
MAX_COMPRESSION_RATIO = 100
MAX_JSON_NESTING = 100
MAX_ARRAY_COUNTS = 100

DELIVERABLES = {
    "summary": ("accountsummary", ".docx"),
    "evidence": ("sourcesandevidence", ".docx"),
    "people": ("peoplelist", ".xlsx"),
    "jobs": ("jobpostings", ".xlsx"),
    "tech": ("techstackandteams", ".xlsx"),
}
_MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
_WORD_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


class WorkspaceArchiveError(ValueError):
    """The upload is malformed or violates a hard ZIP safety bound."""


@dataclass(frozen=True)
class SheetInfo:
    """Bounded row and header metadata for one XLSX sheet."""

    name: str
    row_count: int
    header_candidates: tuple[str, ...] = ()


@dataclass(frozen=True)
class FileInfo:
    """Content-free structural metadata for one archive member."""

    path: str
    size_bytes: int
    kind: str
    sheet_info: tuple[SheetInfo, ...] = ()
    headings: tuple[str, ...] = ()
    table_count: int | None = None
    json_arrays: tuple[tuple[str, int], ...] = ()
    parse_issue: str | None = None


@dataclass(frozen=True)
class RestoreFacts:
    """Deterministic facts parsed from a workspace's RESTORE contract."""

    account_name: str | None
    account_short: str | None
    pursuing_client_display: str | None
    run_date: date | None
    canonical_queries: tuple[tuple[str, str], ...]
    entity_rules: tuple[str, ...]
    out_of_scope_platforms: tuple[str, ...]
    zero_result_rule: str | None


@dataclass(frozen=True)
class BuildConfigFacts:
    """Recognized static build inputs; no source code is interpreted or executed."""

    checked_platforms: tuple[str, ...] = ()
    stack_names: tuple[str, ...] = ()
    false_positive_drops: tuple[tuple[str, str], ...] = ()
    platform_dictionary: tuple[tuple[str, str, str, str], ...] = ()
    stack_lane_map: tuple[tuple[str, str], ...] = ()
    people_lane_names: tuple[str, ...] = ()
    sources: tuple[str, ...] = ()


@dataclass(frozen=True)
class WorkspaceInspection:
    """Validated archive inventory and all recognized contract facts."""

    root: str
    files: tuple[FileInfo, ...]
    deliverables: tuple[tuple[str, str], ...]
    restore_paths: tuple[str, ...]
    internal_paths: tuple[str, ...]
    issues: tuple[str, ...]
    uncompressed_bytes: int
    restore_facts: RestoreFacts | None = None
    build_config: BuildConfigFacts = BuildConfigFacts()
    company_name: str | None = None
    company_domain: str | None = None

    @property
    def deliverables_found(self) -> int:
        """Number of recognized client deliverable roles present in the archive."""
        return len(self.deliverables)


def _safe_name(name: str) -> str:
    """Return the canonical archive path or refuse ambiguous/unsafe names."""
    if not name or "\\" in name or any(ord(char) < 32 for char in name):
        raise WorkspaceArchiveError("archive contains an invalid member name")
    if name.startswith("/"):
        raise WorkspaceArchiveError("archive contains an absolute member path")
    raw = name[:-1] if name.endswith("/") else name
    if any(part in ("", ".", "..") for part in raw.split("/")):
        raise WorkspaceArchiveError("archive contains a traversal member path")
    parts = PurePosixPath(raw).parts
    if not parts or any(part in ("", ".", "..") for part in parts):
        raise WorkspaceArchiveError("archive contains a traversal member path")
    if ":" in parts[0]:
        raise WorkspaceArchiveError("archive contains a drive-qualified member path")
    return "/".join(parts)


def _check_members(archive: zipfile.ZipFile) -> tuple[list[zipfile.ZipInfo], int]:
    infos = archive.infolist()
    if len(infos) > MAX_MEMBERS:
        raise WorkspaceArchiveError("archive contains too many members")
    total = 0
    seen: set[str] = set()
    for item in infos:
        name = _safe_name(item.filename)
        folded = name.casefold()
        if folded in seen:
            raise WorkspaceArchiveError("archive contains duplicate member paths")
        seen.add(folded)
        mode = (item.external_attr >> 16) & 0xFFFF
        kind = stat.S_IFMT(mode)
        if kind not in (0, stat.S_IFREG, stat.S_IFDIR):
            raise WorkspaceArchiveError("archive contains a non-regular member")
        if item.flag_bits & 0x1:
            raise WorkspaceArchiveError("encrypted ZIP members are not supported")
        if item.is_dir():
            continue
        if item.file_size > MAX_MEMBER_BYTES:
            raise WorkspaceArchiveError("archive contains an oversized member")
        total += item.file_size
        if total > MAX_TOTAL_BYTES:
            raise WorkspaceArchiveError("archive expands beyond the size limit")
        ratio = item.file_size / max(item.compress_size, 1)
        if ratio > MAX_COMPRESSION_RATIO:
            raise WorkspaceArchiveError("archive contains an excessive compression ratio")
    return infos, total


def _json_arrays(value: Any, prefix: str = "") -> list[tuple[str, int]]:
    found: list[tuple[str, int]] = []
    if isinstance(value, dict):
        for key, child in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(child, list):
                found.append((path, len(child)))
            elif isinstance(child, dict):
                found.extend(_json_arrays(child, path))
            if len(found) >= MAX_ARRAY_COUNTS:
                return found[:MAX_ARRAY_COUNTS]
    return found


def _strict_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    """Reject duplicate JSON keys instead of silently accepting the final value."""
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON object key")
        result[key] = value
    return result


def _strict_json_value(body: bytes) -> Any:
    """Decode bounded strict JSON with duplicate-key, nesting and constant checks."""
    text = body.decode("utf-8-sig")
    depth = 0
    in_string = False
    escaped = False
    for char in text:
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
        elif char == '"':
            in_string = True
        elif char in "[{":
            depth += 1
            if depth > MAX_JSON_NESTING:
                raise ValueError("JSON nesting exceeds limit")
        elif char in "]}":
            depth -= 1
            if depth < 0:
                raise ValueError("unbalanced JSON")
    if depth != 0 or in_string:
        raise ValueError("incomplete JSON")

    def reject_constant(_value: str) -> None:
        raise ValueError("non-standard JSON constant")

    return json.loads(text, parse_constant=reject_constant, object_pairs_hook=_strict_object)


def _parse_json(path: str, body: bytes) -> FileInfo:
    try:
        parsed = _strict_json_value(body)
        arrays = tuple(_json_arrays(parsed)) if isinstance(parsed, dict) else ()
        if isinstance(parsed, list):
            arrays = (("$", len(parsed)),)
        return FileInfo(path, len(body), "json", json_arrays=arrays)
    except (UnicodeDecodeError, ValueError, RecursionError) as error:
        return FileInfo(
            path, len(body), "json", parse_issue=f"invalid JSON: {type(error).__name__}"
        )


def _nested_zip(body: bytes) -> zipfile.ZipFile:
    try:
        nested = zipfile.ZipFile(io.BytesIO(body))
        infos = nested.infolist()
        if len(infos) > MAX_MEMBERS:
            raise ValueError("package has too many parts")
        entries = [item for item in infos if not item.is_dir()]
        if sum(item.file_size for item in entries) > MAX_MEMBER_BYTES:
            raise ValueError("package expands beyond the member limit")
        seen: set[str] = set()
        for item in infos:
            name = _safe_name(item.filename)
            if name.casefold() in seen:
                raise ValueError("package has duplicate members")
            seen.add(name.casefold())
            mode = (item.external_attr >> 16) & 0xFFFF
            if stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise ValueError("package has non-regular members")
            if item.flag_bits & 0x1:
                raise ValueError("package has encrypted members")
            if not item.is_dir() and (
                item.file_size > MAX_MEMBER_BYTES
                or item.file_size / max(item.compress_size, 1) > MAX_COMPRESSION_RATIO
            ):
                raise ValueError("package has an unsafe compressed part")
        if nested.testzip() is not None:
            raise ValueError("package contains a corrupt part")
        return nested
    except (RuntimeError, zipfile.BadZipFile, OSError, ValueError) as error:
        raise ValueError("invalid Office package") from error


def _xlsx_info(path: str, body: bytes) -> FileInfo:
    try:
        with _nested_zip(body) as package:
            workbook = ET.fromstring(package.read("xl/workbook.xml"))
            relationships = ET.fromstring(package.read("xl/_rels/workbook.xml.rels"))
            shared_strings: list[str] = []
            try:
                strings = ET.fromstring(package.read("xl/sharedStrings.xml"))
                shared_strings = [
                    "".join(node.text or "" for node in item.iter(f"{{{_MAIN_NS}}}t"))
                    for item in strings.findall(f"{{{_MAIN_NS}}}si")
                ]
            except KeyError:
                pass
            targets = {
                relation.attrib["Id"]: relation.attrib["Target"]
                for relation in relationships.findall(f"{{{_PKG_REL_NS}}}Relationship")
            }
            sheets: list[SheetInfo] = []
            for sheet in workbook.findall(f"{{{_MAIN_NS}}}sheets/{{{_MAIN_NS}}}sheet"):
                target = targets[sheet.attrib[f"{{{_REL_NS}}}id"]].lstrip("/")
                if ".." in PurePosixPath(target).parts:
                    raise ValueError("worksheet relationship escapes package root")
                if not target.startswith("xl/"):
                    target = f"xl/{target}"
                xml = ET.fromstring(package.read(target))
                data = xml.find(f"{{{_MAIN_NS}}}sheetData")
                header_candidates: tuple[str, ...] = ()
                if data is not None:
                    for row in data.findall(f"{{{_MAIN_NS}}}row"):
                        values: list[str] = []
                        for cell in row.findall(f"{{{_MAIN_NS}}}c"):
                            cell_type = cell.attrib.get("t")
                            if cell_type == "inlineStr":
                                value = "".join(
                                    node.text or "" for node in cell.iter(f"{{{_MAIN_NS}}}t")
                                )
                            else:
                                value_node = cell.find(f"{{{_MAIN_NS}}}v")
                                value = value_node.text or "" if value_node is not None else ""
                                if cell_type == "s" and value:
                                    value = shared_strings[int(value)]
                            if value.strip():
                                values.append(value.strip())
                        text_cells = all(
                            not value.replace(".", "", 1).isdigit() for value in values
                        )
                        if len(values) >= 2 and text_cells:
                            header_candidates = tuple(values)
                            break
                sheets.append(
                    SheetInfo(
                        sheet.attrib["name"],
                        len(data) if data is not None else 0,
                        header_candidates,
                    )
                )
        return FileInfo(path, len(body), "xlsx", sheet_info=tuple(sheets))
    except (KeyError, ET.ParseError, ValueError, OSError, zipfile.BadZipFile):
        return FileInfo(path, len(body), "xlsx", parse_issue="invalid workbook structure")


def _docx_info(path: str, body: bytes) -> FileInfo:
    try:
        with _nested_zip(body) as package:
            document = ET.fromstring(package.read("word/document.xml"))
            headings: list[str] = []
            styles: dict[str, str] = {}
            try:
                style_root = ET.fromstring(package.read("word/styles.xml"))
                for style in style_root.findall(f"{{{_WORD_NS}}}style"):
                    name = style.find(f"{{{_WORD_NS}}}name")
                    if name is not None:
                        styles[style.attrib.get(f"{{{_WORD_NS}}}styleId", "")] = name.attrib.get(
                            f"{{{_WORD_NS}}}val", ""
                        )
            except KeyError:
                pass
            body_node = document.find(f"{{{_WORD_NS}}}body")
            if body_node is not None:
                for para in body_node.findall(f"{{{_WORD_NS}}}p"):
                    style_node = para.find(f"{{{_WORD_NS}}}pPr/{{{_WORD_NS}}}pStyle")
                    style_id = (
                        style_node.attrib.get(f"{{{_WORD_NS}}}val", "")
                        if style_node is not None
                        else ""
                    )
                    style_name = styles.get(style_id, style_id)
                    if style_name.lower().startswith("heading"):
                        text = "".join(node.text or "" for node in para.iter(f"{{{_WORD_NS}}}t"))
                        headings.append(f"{style_name}: {text}")
            tables = len(document.findall(f".//{{{_WORD_NS}}}tbl"))
        return FileInfo(path, len(body), "docx", headings=tuple(headings), table_count=tables)
    except (KeyError, ET.ParseError, ValueError, OSError, zipfile.BadZipFile):
        return FileInfo(path, len(body), "docx", parse_issue="invalid document structure")


def _kind(path: str) -> str:
    suffix = PurePosixPath(path).suffix.lower()
    return {
        ".json": "json",
        ".docx": "docx",
        ".xlsx": "xlsx",
    }.get(suffix, "other")


def _account_role(path: str) -> str | None:
    normalized = re.sub(r"[^a-z0-9]", "", PurePosixPath(path).stem.casefold())
    for role, (marker, suffix) in DELIVERABLES.items():
        if path.casefold().endswith(suffix) and marker in normalized:
            return role
    return None


def _section(lines: list[str], title_fragment: str) -> list[str]:
    start = next(
        (
            i
            for i, line in enumerate(lines)
            if line.startswith("#") and title_fragment in line.casefold()
        ),
        None,
    )
    if start is None:
        return []
    end = next((i for i in range(start + 1, len(lines)) if lines[i].startswith("#")), len(lines))
    return lines[start + 1 : end]


def _date_after(text: str, pattern: str) -> date | None:
    match = re.search(pattern, text, re.IGNORECASE)
    if match is None:
        return None
    value = match.group(1).strip().rstrip(".")
    for fmt in ("%d %B %Y", "%Y-%m-%d", "%d %b %Y"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    return None


def _restore_facts(body: bytes) -> RestoreFacts:
    text = body.decode("utf-8-sig", "replace")
    lines = text.splitlines()
    title = next((line.lstrip("# ").strip() for line in lines if line.startswith("# ")), "")
    title = re.sub(r"\s+workspace\s*$", "", title, flags=re.IGNORECASE).strip()
    short: str | None = None
    legal: str | None = None
    parenthesized = re.fullmatch(r"(.+?)\s*\(([^()]+)\)", title)
    if parenthesized:
        short, legal = parenthesized.group(1).strip(), parenthesized.group(2).strip()
    elif title:
        short = legal = title
    client = re.search(r"Pursuing client\s*:\s*([^\n.]+)", text, re.IGNORECASE)
    run_date = _date_after(
        text,
        r"(?:phase\s+2\s+analysis\s+and\s+deliverables|run date)\s*[, :]\s*([^,\n.]+)",
    )
    # Some workspaces put the date in a prose sentence rather than a key/value field.
    if run_date is None:
        run_date = _date_after(text, r"phase\s+2\s+analysis\s+and\s+deliverables\s+([^,\n.]+)")
    canonical_lines = _section(lines, "canonical query")
    queries: list[tuple[str, str]] = []
    zero_rule: str | None = None
    for line in canonical_lines:
        query = re.match(r'\s*[-*]\s*"([^"]+)"\s*:\s*(.+)', line)
        if query:
            queries.append((query.group(1).strip(), query.group(2).strip()))
        elif "strict query" in line.casefold() and "zero" in line.casefold():
            zero_rule = re.sub(r"^\s*[-*]\s*", "", line).strip()
    entity_lines = _section(lines, "entity rules")
    entity_rules = tuple(
        re.sub(r"^\s*[-*]\s*", "", line).strip()
        for line in entity_lines
        if line.strip().startswith(("-", "*"))
    )
    out_of_scope: list[str] = []
    for line in entity_rules:
        if "out of scope" in line.casefold():
            match = re.search(r"(.+?)\s+(?:are|is)\s+out of scope", line, re.IGNORECASE)
            if match:
                names = re.sub(r"\bplatforms?\s+", "", match.group(1), flags=re.IGNORECASE)
                out_of_scope.extend(
                    name.strip(" .") for name in re.split(r",|\band\b", names) if name.strip(" .")
                )
    return RestoreFacts(
        account_name=legal,
        account_short=short,
        pursuing_client_display=client.group(1).strip() if client else None,
        run_date=run_date,
        canonical_queries=tuple(queries),
        entity_rules=entity_rules,
        out_of_scope_platforms=tuple(out_of_scope),
        zero_result_rule=zero_rule,
    )


def _company_identity(
    archive: zipfile.ZipFile, infos: list[zipfile.ZipInfo]
) -> tuple[str | None, str | None]:
    """Read explicit identity fields from a conventional company record, if present."""
    for item in infos:
        if item.is_dir() or PurePosixPath(item.filename).name.casefold() != "company_record.json":
            continue
        try:
            body = archive.read(item)
            text = body.decode("utf-8-sig")
            depth = 0
            in_string = False
            escaped = False
            for char in text:
                if in_string:
                    if escaped:
                        escaped = False
                    elif char == "\\":
                        escaped = True
                    elif char == '"':
                        in_string = False
                elif char == '"':
                    in_string = True
                elif char in "[{":
                    depth += 1
                    if depth > MAX_JSON_NESTING:
                        raise ValueError("JSON nesting exceeds limit")
                elif char in "]}":
                    depth -= 1
                    if depth < 0:
                        raise ValueError("unbalanced JSON")
            if depth != 0 or in_string:
                raise ValueError("incomplete JSON")

            def reject_constant(_value: str) -> None:
                raise ValueError("non-standard JSON constant")

            value = json.loads(
                text, parse_constant=reject_constant, object_pairs_hook=_strict_object
            )
        except (UnicodeDecodeError, ValueError, RecursionError):
            return None, None
        if not isinstance(value, dict):
            return None, None
        name = value.get("company_name") or value.get("name") or value.get("friendly_name")
        domain = value.get("domain")
        name = str(name).strip() if isinstance(name, str) and name.strip() else None
        domain = str(domain).strip().lower().rstrip(".") if isinstance(domain, str) else None
        if domain and not re.fullmatch(
            r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+",
            domain,
        ):
            domain = None
        return name, domain
    return None, None


def _literal_module_values(body: bytes, names: set[str]) -> dict[str, Any]:
    """Read selected top-level Python literals from source without evaluating the module."""
    if len(body) > 1_000_000:
        raise ValueError("static configuration source exceeds limit")
    tree = ast.parse(body.decode("utf-8-sig"))
    if sum(1 for _ in ast.walk(tree)) > 100_000:
        raise ValueError("static configuration source has too many syntax nodes")
    found: dict[str, list[ast.expr]] = {name: [] for name in names}
    for node in tree.body:
        targets = (
            node.targets
            if isinstance(node, ast.Assign)
            else [node.target]
            if isinstance(node, ast.AnnAssign)
            else []
        )
        value = getattr(node, "value", None)
        for target in targets:
            if isinstance(target, ast.Name) and target.id in found and value is not None:
                found[target.id].append(value)
    result: dict[str, Any] = {}
    for name, candidates in found.items():
        if len(candidates) != 1:
            continue
        try:
            result[name] = ast.literal_eval(candidates[0])
        except (ValueError, TypeError, SyntaxError, MemoryError, OverflowError, RecursionError):
            continue
    return result


def _build_config_facts(
    archive: zipfile.ZipFile,
    infos: list[zipfile.ZipInfo],
    issues: list[str],
) -> BuildConfigFacts:
    """Read bounded JSON controls and allowlisted Python literals from the build directory."""
    checked: tuple[str, ...] = ()
    stack_names: tuple[str, ...] = ()
    platform_dictionary: tuple[tuple[str, str, str, str], ...] = ()
    stack_lane_map: tuple[tuple[str, str], ...] = ()
    people_lane_names: tuple[str, ...] = ()
    drop_values: dict[str, tuple[tuple[str, str], ...]] = {}
    sources: list[str] = []
    seen_singletons: set[str] = set()
    seen_drop_files: set[str] = set()
    ambiguous_drop_files: set[str] = set()
    seen_scripts: set[str] = set()
    for item in infos:
        if item.is_dir():
            continue
        path = _safe_name(item.filename)
        parts = PurePosixPath(path).parts
        if len(parts) < 2 or parts[-2].casefold() != "build":
            continue
        filename = parts[-1].casefold()
        is_json_control = filename in {"checked.json", "stack_names.json"} or (
            filename.startswith("drop_") and filename.endswith(".json")
        )
        is_platform_script = filename.startswith("platform_ranking") and filename.endswith(".py")
        is_stack_script = filename == "build_stack.py"
        is_people_script = filename == "build_people.py"
        is_static_script = is_platform_script or is_stack_script or is_people_script
        if not is_json_control and not is_static_script:
            continue
        sources.append(path)
        if is_static_script:
            if filename in seen_scripts:
                issues.append(f"{path}: ambiguous duplicate static build script")
                if is_platform_script:
                    platform_dictionary = ()
                elif is_stack_script:
                    stack_lane_map = ()
                else:
                    people_lane_names = ()
                continue
            seen_scripts.add(filename)
            try:
                names = (
                    {"PLATFORMS"}
                    if is_platform_script
                    else {"LANE"}
                    if is_stack_script
                    else {"lanes"}
                )
                values = _literal_module_values(archive.read(item), names)
            except (UnicodeDecodeError, SyntaxError, ValueError, RecursionError):
                issues.append(f"{path}: static build script could not be parsed safely")
                continue
            if is_platform_script:
                entries = values.get("PLATFORMS")
                if isinstance(entries, (list, tuple)):
                    valid = 1 <= len(entries) <= 256 and all(
                        isinstance(entry, (list, tuple))
                        and len(entry) == 4
                        and all(isinstance(part, str) for part in entry)
                        and entry[0].strip()
                        and entry[1].strip()
                        and entry[3].strip()
                        and len(entry[0]) <= 200
                        and len(entry[1]) <= 200
                        and len(entry[2]) <= 200
                        and len(entry[3]) <= 2_000
                        for entry in entries
                    )
                else:
                    valid = False
                if isinstance(entries, (list, tuple)) and valid:
                    platform_dictionary = tuple(tuple(entry) for entry in entries)
                    try:
                        for _, _, _, pattern in platform_dictionary:
                            re.compile(pattern)
                    except re.error:
                        platform_dictionary = ()
                        issues.append(f"{path}: platform dictionary contains an invalid pattern")
                else:
                    issues.append(f"{path}: platform dictionary is not a bounded literal list")
            elif is_stack_script:
                lane_map = values.get("LANE")
                if (
                    isinstance(lane_map, dict)
                    and len(lane_map) <= 100
                    and all(
                        isinstance(key, str)
                        and isinstance(value, str)
                        and key.strip()
                        and value.strip()
                        and len(key) <= 200
                        and len(value) <= 200
                        for key, value in lane_map.items()
                    )
                ):
                    stack_lane_map = tuple((key, value) for key, value in lane_map.items())
                else:
                    issues.append(f"{path}: stack lane map is not a bounded literal object")
            else:
                lanes = values.get("lanes")
                if (
                    isinstance(lanes, (list, tuple))
                    and 1 <= len(lanes) <= 100
                    and all(
                        isinstance(value, str) and value.strip() and len(value) <= 200
                        for value in lanes
                    )
                ):
                    people_lane_names = tuple(lanes)
                else:
                    issues.append(f"{path}: people lane list is not a bounded literal array")
            continue
        singleton = filename in {"checked.json", "stack_names.json"}
        if singleton and filename in seen_singletons:
            issues.append(f"{path}: ambiguous duplicate static build input")
            if filename == "checked.json":
                checked = ()
            else:
                stack_names = ()
            continue
        if singleton:
            seen_singletons.add(filename)
        elif filename in seen_drop_files:
            issues.append(f"{path}: ambiguous duplicate drop input")
            ambiguous_drop_files.add(filename)
            continue
        else:
            seen_drop_files.add(filename)
        try:
            value = _strict_json_value(archive.read(item))
        except (UnicodeDecodeError, ValueError, RecursionError):
            issues.append(f"{path}: invalid static build JSON")
            continue
        if filename in {"checked.json", "stack_names.json"}:
            if (
                not isinstance(value, list)
                or len(value) > 2_000
                or any(
                    not isinstance(entry, str)
                    or not entry.strip()
                    or len(entry) > (200 if filename == "checked.json" else 500)
                    for entry in value
                )
            ):
                issues.append(f"{path}: expected a bounded array of short non-empty strings")
                continue
            normalized = tuple(entry.strip() for entry in value)
            if filename == "checked.json":
                checked = normalized
            else:
                stack_names = normalized
            continue
        valid_drops = isinstance(value, list) and len(value) <= 10_000
        if valid_drops:
            valid_drops = all(
                isinstance(entry, list)
                and len(entry) == 2
                and all(isinstance(part, str) and part.strip() for part in entry)
                and len(entry[0]) <= 100
                and len(entry[1]) <= 2_048
                for entry in value
            )
        if not valid_drops:
            issues.append(f"{path}: expected bounded [platform, posting URL] pairs")
            continue
        drop_values[filename] = tuple((entry[0].strip(), entry[1].strip()) for entry in value)
    drops = tuple(
        pair
        for filename, entries in sorted(drop_values.items())
        if filename not in ambiguous_drop_files
        for pair in entries
    )
    return BuildConfigFacts(
        checked_platforms=checked,
        stack_names=stack_names,
        false_positive_drops=drops,
        platform_dictionary=platform_dictionary,
        stack_lane_map=stack_lane_map,
        people_lane_names=people_lane_names,
        sources=tuple(sources),
    )


def inspect_workspace_archive(data: bytes) -> WorkspaceInspection:
    """Return a bounded inventory and contract report for a workspace ZIP.

    ZIP member bytes are read for JSON files, candidate deliverables and allowlisted static build
    configuration. Builder scripts are parsed only for selected top-level literals and never
    executed; other raw files are inventory-only. Hard archive safety violations raise
    ``WorkspaceArchiveError``. Missing contract members and malformed data produce report issues.
    """
    if not data or len(data) > MAX_ARCHIVE_BYTES:
        raise WorkspaceArchiveError("workspace archive must be between 1 byte and 100 MB")
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError) as error:
        raise WorkspaceArchiveError("upload is not a readable ZIP archive") from error

    with archive:
        infos, total = _check_members(archive)
        try:
            corrupt = archive.testzip()
        except (RuntimeError, zipfile.BadZipFile, OSError) as error:
            raise WorkspaceArchiveError("archive contents failed integrity checks") from error
        if corrupt is not None:
            raise WorkspaceArchiveError("archive contents failed integrity checks")
        paths: list[str] = []
        for item in infos:
            if not item.is_dir():
                paths.append(_safe_name(item.filename))

        restores = tuple(
            path for path in paths if PurePosixPath(path).name.casefold() == "restore.md"
        )
        internal = tuple(
            path
            for path in paths
            if re.search(r"(^|[/_. -])(internal|operator)[_ -]?only([/_. -]|$)", path, re.I)
        )
        role_paths: dict[str, list[str]] = {role: [] for role in DELIVERABLES}
        for path in paths:
            role = _account_role(path)
            if role is not None and path not in internal:
                role_paths[role].append(path)

        restore_root = str(PurePosixPath(restores[0]).parent) if len(restores) == 1 else ""
        if restore_root == ".":
            restore_root = ""
        canonical_dir = f"{restore_root}/deliverables" if restore_root else "deliverables"
        preferred = {
            role: [path for path in candidates if str(PurePosixPath(path).parent) == canonical_dir]
            for role, candidates in role_paths.items()
        }
        # A number of workspaces keep historical deliverables beside the current set. RESTORE.md
        # is the contract for the active run, so prefer its conventional deliverables directory
        # when it contains exactly one candidate for every required role. Otherwise preserve the
        # ambiguity and fail closed instead of guessing between generations.
        if all(len(preferred[role]) == 1 for role in DELIVERABLES):
            role_paths = preferred

        files: list[FileInfo] = []
        issues: list[str] = []
        for path, item in zip(paths, (i for i in infos if not i.is_dir()), strict=True):
            kind = _kind(path)
            if kind == "json":
                info = _parse_json(path, archive.read(item))
            elif kind == "xlsx":
                info = _xlsx_info(path, archive.read(item))
            elif kind == "docx":
                info = _docx_info(path, archive.read(item))
            else:
                info = FileInfo(path, item.file_size, kind)
            files.append(info)
            if info.parse_issue:
                issues.append(f"{path}: {info.parse_issue}")

        if len(restores) != 1:
            issues.append("restore:expected_exactly_one")
        deliverables: list[tuple[str, str]] = []
        for role in DELIVERABLES:
            matches = role_paths[role]
            if len(matches) == 1:
                deliverables.append((role, matches[0]))
            elif not matches:
                issues.append(f"{role}:missing")
            else:
                issues.append(f"{role}:ambiguous")
        root = restore_root
        restore_facts = _restore_facts(archive.read(restores[0])) if len(restores) == 1 else None
        company_name, company_domain = _company_identity(archive, infos)
        build_config = _build_config_facts(archive, infos, issues)
        return WorkspaceInspection(
            root=root,
            files=tuple(files),
            deliverables=tuple(deliverables),
            restore_paths=restores,
            internal_paths=internal,
            issues=tuple(issues),
            uncompressed_bytes=total,
            restore_facts=restore_facts,
            build_config=build_config,
            company_name=company_name,
            company_domain=company_domain,
        )
