"""Conservative parser for RESTORE.md's explicitly stated canonical table queries.

Only simple column predicates are compiled. The source text is always retained; an expression
that cannot be mapped to a known deliverable and sheet is marked non-derivable.
"""

from __future__ import annotations

import re
from typing import Any

from exports.repair.ingest import _account_role

_OPS = re.compile(r"\b(starts with|not equals|contains|equals)\b", re.I)
_SHEET = re.compile(r"\bsheet\s+([^,.;]+)", re.I)
_FILE = re.compile(r"\b([^,;\s]+\.xlsx)\b", re.I)
_STOP = re.compile(r"\b(?:Base|Answer)\s*:", re.I)
_ROLE_COLUMN = {
    "class": "jobs",
    "platforms named": "jobs",
    "entity": "jobs",
    "meets seniority rule": "people",
    "priority": "people",
    "rank": "tech",
    "postings naming it": "tech",
}
_OP_NAMES = {
    "starts with": "starts_with",
    "not equals": "not_equals",
    "contains": "contains",
    "equals": "equals",
}


def _clause_value_end(text: str, start: int) -> int:
    """Stop a value before the next explicit predicate or a prose section boundary."""
    tail = text[start:]
    candidates = [
        match.start()
        for pattern in (_STOP, re.compile(r"[.;]"), re.compile(r":\s*\d"))
        if (match := pattern.search(tail))
    ]
    next_predicate = re.search(
        r"\s+and\s+[A-Z][\w /&()'-]*?\s+(?:starts with|not equals|contains|equals)\b", tail
    )
    if next_predicate:
        candidates.append(next_predicate.start())
    return start + min(candidates) if candidates else len(text)


def _predicates(text: str) -> list[dict[str, Any]]:
    matches = list(_OPS.finditer(text))
    predicates: list[dict[str, Any]] = []
    previous_end = 0
    for index, match in enumerate(matches):
        prefix = text[previous_end : match.start()]
        for marker in ("where ", "same sheet,", " and ", ","):
            found = prefix.casefold().rfind(marker)
            if found >= 0:
                prefix = prefix[found + len(marker) :]
        column = prefix.strip(" ,\t\n")
        value_start = match.end()
        value_end = _clause_value_end(text, value_start)
        value = text[value_start:value_end].strip(' \t\n,;:."')
        if match.group(1).casefold() == "contains":
            value = value.split(" (", 1)[0].strip()
        # A workbook reference can precede the predicate; reject anything that still contains
        # prose after removing the known leading restore grammar.
        column = re.sub(r"^(?:same sheet,?\s*|where\s*)", "", column, flags=re.I).strip()
        if column and value:
            predicates.append(
                {"column": column, "op": _OP_NAMES[match.group(1).casefold()], "value": value}
            )
        previous_end = value_end
        if index + 1 < len(matches):
            next_match = matches[index + 1]
            previous_end = min(previous_end, next_match.start())
    return predicates


def compile_restore_queries(
    queries: tuple[tuple[str, str], ...],
) -> list[dict[str, Any]]:
    """Compile RESTORE query prose into a safe, inspectable subset of the full schema."""
    out: list[dict[str, Any]] = []
    prior_role: str | None = None
    prior_sheet: str | None = None
    prior_base: str | None = None
    prior_entity: dict[str, Any] | None = None
    for name, answer in queries:
        role: str | None = None
        sheet: str | None = None
        file_match = _FILE.search(answer)
        if file_match:
            role = _account_role(file_match.group(1))
        sheet_match = _SHEET.search(answer)
        if sheet_match:
            sheet = sheet_match.group(1).strip()
        same_sheet = bool(re.search(r"\bsame sheet\b", answer, re.I))
        if same_sheet:
            role = role or prior_role
            sheet = sheet or prior_sheet

        predicates = _predicates(answer)
        if role is None:
            for predicate in predicates:
                inferred = _ROLE_COLUMN.get(predicate["column"].casefold())
                if inferred:
                    role = inferred
                    break
        if sheet is None and role in {"jobs", "people"}:
            sheet = "Jobs" if role == "jobs" else "People"
        if sheet and role is None:
            role = _account_role(sheet + ".xlsx")
        if (
            role == prior_role
            and sheet == prior_sheet
            and prior_entity is not None
            and not any(p["column"].casefold() == "entity" for p in predicates)
        ):
            predicates.append(prior_entity.copy())
        base_match = re.search(r"\bBase\s*:\s*(.*?)(?=\bAnswer\s*:|$)", answer, re.I)
        base = base_match.group(1).strip().rstrip(".") if base_match else None
        if base is None and role == prior_role and sheet == prior_sheet:
            base = prior_base
        entity_rule = next(
            (p["value"] for p in predicates if p["column"].casefold() == "entity"), None
        )
        secondary_metrics = []
        if re.search(r"\bpre[- ]close\b", answer, re.I):
            secondary_metrics.append("pre_close_count")
        supported_role = role in {"jobs", "people"}
        is_platform_ranking = (
            role == "tech" and (sheet or "").casefold() == "platform ranking" and not predicates
        )
        can_derive = (
            supported_role and bool(predicates) or is_platform_ranking
        ) and not secondary_metrics
        if role == "jobs" and any(
            predicate["column"].casefold() == "class"
            and predicate["value"].casefold() == "build role"
            for predicate in predicates
        ):
            can_derive = True
        out.append(
            {
                "query": name,
                "answer": answer,
                "role": role,
                "sheet": sheet,
                "where": predicates,
                "base": base,
                "entity_rule": entity_rule,
                "derivable": can_derive,
                "not_derived": secondary_metrics
                or ([] if can_derive else ["query_scope_or_predicate_or_answer_shape"]),
            }
        )
        if role and sheet:
            prior_role, prior_sheet = role, sheet
            prior_entity = next(
                (p.copy() for p in predicates if p["column"].casefold() == "entity"),
                None,
            )
        if base:
            prior_base = base
    return out
