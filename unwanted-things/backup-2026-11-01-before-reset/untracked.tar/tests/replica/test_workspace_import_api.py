"""Raw workspace imports use account scoping and tenant-visible version history."""

from __future__ import annotations

import io
import json
import zipfile
from typing import Any
from uuid import uuid4

import pytest
from docx import Document
from openpyxl import Workbook
from sqlalchemy import text

pytestmark = [pytest.mark.requires_postgres, pytest.mark.asyncio]

from tests.replica.conftest import _call, _plane  # noqa: E402


def _scanning_plane(tenant: Any, user: str, payloads: Any) -> Any:
    """Give this synthetic upload test the repository's local signature scanner."""
    from documents.scan import SignatureScanner

    plane = _plane(tenant, user, payloads)
    plane.app.state.container.documents.scanner = SignatureScanner()
    return plane


def _workspace(domain: str | None = None) -> bytes:
    """A tiny synthetic archive; no builder code is present or executed."""
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(
            "sample/RESTORE.md", "# Sample workspace\n## Entity rules\n- Generic rule.\n"
        )
        if domain:
            archive.writestr(
                "sample/data/company_record.json",
                f'{{"company_name":"Sample","domain":"{domain}"}}',
            )
    return out.getvalue()


def _deliverable_workspace() -> bytes:
    """Build a small realistic package with one internal-only file for API boundary checks."""
    archive_bytes = io.BytesIO()
    with zipfile.ZipFile(archive_bytes, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("sample/RESTORE.md", "# Sample workspace\n")
        for name, heading in (
            ("Sample_Account_Summary.docx", "Summary"),
            ("Sample_Sources_and_Evidence.docx", "Evidence"),
            ("Sample_Internal_Only.docx", "Internal"),
        ):
            document = Document()
            document.add_heading(heading, level=1)
            document.add_paragraph(f"{heading} body")
            body = io.BytesIO()
            document.save(body)
            archive.writestr(f"sample/{name}", body.getvalue())
        for filename, sheet in (
            ("Sample_People_List.xlsx", "People"),
            ("Sample_Job_Postings.xlsx", "Jobs"),
            ("Sample_Tech_Stack_and_Teams.xlsx", "Platform Ranking"),
        ):
            workbook = Workbook()
            page = workbook.active
            page.title = sheet
            page.append(["Name", "Value"])
            page.append(["Sample", "Present"])
            body = io.BytesIO()
            workbook.save(body)
            archive.writestr(f"sample/{filename}", body.getvalue())
    return archive_bytes.getvalue()


def _canonical_workspace() -> bytes:
    """A small RESTORE contract whose count must come from imported rows, not its answer text."""
    archive_bytes = io.BytesIO()
    with zipfile.ZipFile(archive_bytes, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(
            "sample/RESTORE.md",
            "# Sample workspace\n## Canonical query definitions\n"
            '- "Salesforce postings": rows in Sample_Job_Postings.xlsx, sheet Jobs, '
            "where Platforms named contains Salesforce and Entity starts with Waters. "
            "Base: current rows. Answer: 999 (999 open).\n"
            '- "Platform rank": rows in Sample_Tech_Stack_and_Teams.xlsx, '
            "sheet Platform Ranking. Answer: 999.\n",
        )
        workbook = Workbook()
        sheet = workbook.active
        assert sheet is not None
        sheet.title = "Jobs"
        sheet.append(["Title", "Platforms named", "Class", "Status", "Entity"])
        sheet.append(["Salesforce builder", "Salesforce", "Build role", "Open", "Sample"])
        sheet.append(["Salesforce analyst", "Salesforce", "User role", "Closed", "Sample"])
        sheet.append(["SAP developer", "SAP", "Build role", "Open", "Sample"])
        body = io.BytesIO()
        workbook.save(body)
        archive.writestr("sample/deliverables/Sample_Job_Postings.xlsx", body.getvalue())
        tech = Workbook()
        ranking = tech.active
        assert ranking is not None
        ranking.title = "Platform Ranking"
        ranking.append(["Platform", "Rank"])
        ranking.append(["Sample Cloud", "A"])
        ranking.append(["Example Suite", "B"])
        body = io.BytesIO()
        tech.save(body)
        archive.writestr("sample/deliverables/Sample_Tech_Stack_and_Teams.xlsx", body.getvalue())
    return archive_bytes.getvalue()


def _frames(body: str) -> dict[str, dict[str, Any]]:
    frames: dict[str, dict[str, Any]] = {}
    for event in body.strip().split("\n\n"):
        lines = event.splitlines()
        if len(lines) >= 2 and lines[0].startswith("event: ") and lines[1].startswith("data: "):
            frames[lines[0][7:]] = json.loads(lines[1][6:])
    return frames


async def test_upload_versions_are_shared_inside_tenant_and_isolated_between_tenants(
    world: dict[str, Any],
) -> None:
    owner = _scanning_plane(world["a"], "priya-test", world["payloads"])
    colleague = _scanning_plane(world["a"], "someone-else", world["payloads"])
    other_tenant = _scanning_plane(world["b"], "other-test", world["payloads"])

    first = await _call(
        owner,
        "POST",
        "/v1/accounts/highmark.example/workspace-imports?filename=sample.zip",
        content=_workspace("highmark.example"),
        headers={"content-type": "application/zip"},
    )
    assert first.status_code == 201, first.text
    assert first.json()["status"] == "incomplete"
    assert first.json()["version"] == 1
    assert first.json()["validation"]["pipeline_ready"] is False

    second = await _call(
        owner,
        "POST",
        "/v1/accounts/highmark.example/workspace-imports?filename=sample.zip",
        content=_workspace("highmark.example"),
        headers={"content-type": "application/zip"},
    )
    assert second.status_code == 201, second.text
    assert second.json()["version"] == 2

    private = await _call(colleague, "GET", "/v1/accounts/highmark.example/workspace-imports")
    assert private.status_code == 404

    own = await _call(owner, "GET", "/v1/accounts/highmark.example/workspace-imports")
    assert own.status_code == 200, own.text
    assert [item["version"] for item in own.json()["imports"]] == [2, 1]

    isolated = await _call(other_tenant, "GET", "/v1/accounts/cigna.example/workspace-imports")
    assert isolated.status_code == 200, isolated.text
    assert isolated.json()["imports"] == []


async def test_import_rejects_company_domain_mismatch_before_persisting(
    world: dict[str, Any],
) -> None:
    plane = _scanning_plane(world["a"], "priya-test", world["payloads"])
    before = await _call(plane, "GET", "/v1/accounts/highmark.example/workspace-imports")
    before_ids = [item["id"] for item in before.json()["imports"]]
    refused = await _call(
        plane,
        "POST",
        "/v1/accounts/highmark.example/workspace-imports?filename=sample.zip",
        content=_workspace("cigna.example"),
        headers={"content-type": "application/zip"},
    )
    assert refused.status_code == 422
    listing = await _call(plane, "GET", "/v1/accounts/highmark.example/workspace-imports")
    assert [item["id"] for item in listing.json()["imports"]] == before_ids


async def test_import_refuses_zip_slip_members(world: dict[str, Any]) -> None:
    plane = _scanning_plane(world["a"], "priya-test", world["payloads"])
    unsafe = io.BytesIO()
    with zipfile.ZipFile(unsafe, "w") as archive:
        archive.writestr("../escape.txt", "synthetic")
    refused = await _call(
        plane,
        "POST",
        "/v1/accounts/highmark.example/workspace-imports?filename=unsafe.zip",
        content=unsafe.getvalue(),
        headers={"content-type": "application/zip"},
    )
    assert refused.status_code == 422


async def test_workspace_scan_fails_closed_before_archive_parsing(world: dict[str, Any]) -> None:
    from documents.scan import ScanVerdict

    plane = _scanning_plane(world["a"], "priya-test", world["payloads"])

    class Unavailable:
        async def scan(self, _stream: Any) -> ScanVerdict:
            return ScanVerdict("unavailable", engine="synthetic")

    plane.app.state.container.documents.scanner = Unavailable()
    refused = await _call(
        plane,
        "POST",
        "/v1/accounts/highmark.example/workspace-imports?filename=sample.zip",
        content=_workspace("highmark.example"),
        headers={"content-type": "application/zip"},
    )
    assert refused.status_code == 503


async def test_import_views_are_paged_and_download_omits_internal_file(
    world: dict[str, Any],
) -> None:
    plane = _scanning_plane(world["a"], "priya-test", world["payloads"])
    uploaded = await _call(
        plane,
        "POST",
        "/v1/accounts/highmark.example/workspace-imports?filename=sample.zip",
        content=_deliverable_workspace(),
        headers={"content-type": "application/zip"},
    )
    assert uploaded.status_code == 201, uploaded.text
    import_id = uploaded.json()["id"]

    view = await _call(
        plane,
        "GET",
        f"/v1/accounts/highmark.example/workspace-imports/{import_id}/views/jobs?limit=1",
    )
    assert view.status_code == 200, view.text
    assert view.json()["available"] is True
    assert view.json()["selected_sheet"] == "Jobs"
    assert view.json()["total_rows"] == 2
    assert len(view.json()["rows"]) == 1

    from account_intelligence.db.session import tenant_txn
    from documents import tables as stored_tables

    async with tenant_txn(world["a"], user="priya-test") as session:
        account_id = await session.scalar(
            text("SELECT id FROM accounts WHERE domain = :domain"),
            {"domain": "highmark.example"},
        )
        tables = await stored_tables.list_tables(session, [account_id])
        jobs = next(table for table in tables if table.table.endswith(": Jobs"))
        query = stored_tables.parse(
            jobs,
            {"where": [{"column": "Value", "op": "icontains", "value": "Present"}]},
        )
        result = await stored_tables.run(session, query)
    assert result["row_count"] == 1
    assert result["rows"][0]["cells"]["value"] == "Present"

    downloaded = await _call(
        plane,
        "GET",
        f"/v1/accounts/highmark.example/workspace-imports/{import_id}/downloads",
    )
    assert downloaded.status_code == 200, downloaded.text
    with zipfile.ZipFile(io.BytesIO(downloaded.content)) as archive:
        names = archive.namelist()
        assert len(names) == 5
        assert all("Internal" not in name for name in names)


async def test_ask_uses_computed_canonical_counts_from_imported_workspace_rows(
    world: dict[str, Any], monkeypatch: pytest.MonkeyPatch
) -> None:
    plane = _scanning_plane(world["a"], "priya-test", world["payloads"])
    uploaded = await _call(
        plane,
        "POST",
        "/v1/accounts/highmark.example/workspace-imports?filename=sample.zip",
        content=_canonical_workspace(),
        headers={"content-type": "application/zip"},
    )
    assert uploaded.status_code == 201, uploaded.text
    from account_intelligence.db.session import tenant_txn

    async with tenant_txn(world["a"], user="priya-test") as session:
        account_id = await session.scalar(
            text("SELECT id FROM accounts WHERE domain = :domain"),
            {"domain": "highmark.example"},
        )

    async def refuse_provider(*_args: Any, **_kwargs: Any) -> Any:
        raise AssertionError("canonical workspace answers must not resolve a model provider")

    monkeypatch.setattr("account_intelligence.api.routes.ask._provider_for_ask", refuse_provider)
    reply = await _call(
        plane,
        "POST",
        "/v1/chat/ask",
        json={
            "request_id": str(uuid4()),
            "account_id": str(account_id),
            "question": "How many Salesforce Waters postings?",
        },
    )
    frames = _frames(reply.text)
    assert "error" not in frames, reply.text
    answer = frames["answer"]
    paragraph_text = "".join(
        part.get("v", "") for paragraph in answer["paragraphs"] for part in paragraph
    )
    assert "strict Salesforce postings query returned 0 rows" in paragraph_text
    assert (
        "nearest relaxed set after relaxing Entity starts_with Waters returned 2 rows"
        in paragraph_text
    )
    assert "999" not in paragraph_text
    assert answer["sources"] and answer["sources"][0]["kind"] == "file"

    ranking_reply = await _call(
        plane,
        "POST",
        "/v1/chat/ask",
        json={
            "request_id": str(uuid4()),
            "account_id": str(account_id),
            "question": "What is the platform rank?",
        },
    )
    ranking_frames = _frames(ranking_reply.text)
    ranking_answer = ranking_frames["answer"]
    ranking_text = "".join(
        part.get("v", "") for paragraph in ranking_answer["paragraphs"] for part in paragraph
    )
    assert "A: Sample Cloud" in ranking_text
    assert "B: Example Suite" in ranking_text
    assert "999" not in ranking_text
