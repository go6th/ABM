"""Golden comparison reports structural parity without disclosing workbook or document content."""

from __future__ import annotations

from datetime import date
from pathlib import Path

from docx import Document
from openpyxl import Workbook

from parity.compare_workspace import compare_workspace


def _write_docx(path: Path, text: str) -> None:
    document = Document()
    document.add_heading(text, level=1)
    table = document.add_table(rows=1, cols=2)
    table.cell(0, 0).text = "Evidence"
    table.cell(0, 1).text = "Source A"
    document.save(path)


def _write_xlsx(path: Path, value: object) -> None:
    workbook = Workbook()
    sheet = workbook.active
    assert sheet is not None
    sheet.title = "Main"
    sheet.append(["Date", "Count"])
    sheet.append([value, 5])
    workbook.save(path)


def _workspace(directory: Path, *, doc_text: str, date_value: object) -> None:
    directory.mkdir(parents=True)
    for name in ("Account_Summary", "Sources_and_Evidence"):
        _write_docx(directory / f"Acme_{name}.docx", doc_text)
    for name in ("People_List", "Job_Postings", "Tech_Stack_and_Teams"):
        _write_xlsx(directory / f"Acme_{name}.xlsx", date_value)
    _write_docx(directory / "Acme_Internal_Only.docx", "private")


def test_compares_deliverables_with_whitespace_and_date_normalization(tmp_path: Path) -> None:
    golden = tmp_path / "golden"
    rebuilt = tmp_path / "rebuilt"
    _workspace(golden, doc_text="Account   summary", date_value=date(2026, 10, 20))
    _workspace(rebuilt, doc_text="Account summary", date_value="20 October 2026")

    report = compare_workspace(golden, rebuilt)

    assert report["equal"] is True
    assert {role: value["equal"] for role, value in report["roles"].items()} == {
        "summary": True,
        "evidence": True,
        "people": True,
        "jobs": True,
        "tech": True,
    }


def test_report_counts_cell_and_document_differences_without_echoing_content(
    tmp_path: Path,
) -> None:
    golden = tmp_path / "golden"
    rebuilt = tmp_path / "rebuilt"
    _workspace(golden, doc_text="Account summary", date_value=date(2026, 10, 20))
    _workspace(rebuilt, doc_text="Changed account", date_value="20 October 2026")
    workbook_path = rebuilt / "Acme_Job_Postings.xlsx"
    workbook = Workbook()
    sheet = workbook.active
    assert sheet is not None
    sheet.title = "Main"
    sheet.append(["Date", "Count"])
    sheet.append(["20 October 2026", 7])
    workbook.save(workbook_path)

    report = compare_workspace(golden, rebuilt)

    assert report["equal"] is False
    assert report["roles"]["jobs"]["cell_differences"] == 1
    assert report["roles"]["jobs"]["cell_locations"] == ["Main!B2"]
    assert report["roles"]["summary"]["structure_differences"] == 1
    assert "Changed account" not in repr(report)
