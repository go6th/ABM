"""Synthetic workspace ZIP fixtures for the non-executing archive boundary."""

from __future__ import annotations

import io
import stat
import zipfile

import pytest
from docx import Document
from openpyxl import Workbook

from exports.repair import ingest


def _docx(heading: str) -> bytes:
    doc = Document()
    doc.add_heading(heading, level=1)
    doc.add_paragraph("Synthetic fixture content.")
    out = io.BytesIO()
    doc.save(out)
    return out.getvalue()


def _xlsx() -> bytes:
    book = Workbook()
    sheet = book.active
    assert sheet is not None
    sheet.title = "Jobs"
    sheet.append(["Title", "Platforms named"])
    sheet.append(["Synthetic role", "Example platform"])
    out = io.BytesIO()
    book.save(out)
    return out.getvalue()


def _archive(files: dict[str, bytes]) -> bytes:
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as archive:
        for path, body in files.items():
            archive.writestr(path, body)
    return out.getvalue()


def _valid_files() -> dict[str, bytes]:
    return {
        "acme/RESTORE.md": (
            b"# Acme (Acme Corporation) workspace\n"
            b"Run date: 20 October 2026. Pursuing client: Client.\n"
            b"## Canonical query definitions\n"
            b'- "Acme postings": 3 (2 open).\n'
            b"- A strict query that returns zero is reported as zero, then show the nearest set.\n"
            b"## Entity rules\n"
            b"- Waters positions are excluded from account counts.\n"
            b"- Databricks and Siebel are out of scope: never searched.\n"
        ),
        "acme/deliverables/Acme_Account_Summary.docx": _docx("Account summary"),
        "acme/deliverables/Acme_Sources_and_Evidence.docx": _docx("Sources and evidence"),
        "acme/deliverables/Acme_People_List.xlsx": _xlsx(),
        "acme/deliverables/Acme_Job_Postings.xlsx": _xlsx(),
        "acme/deliverables/Acme_Tech_Stack_and_Teams.xlsx": _xlsx(),
        "acme/Acme_Internal_Only.docx": _docx("Internal notes"),
        "acme/data/jobs.json": b'{"jobs": [{"id": "synthetic-1"}, {"id": "synthetic-2"}]}',
        "acme/data/company_record.json": (
            b'{"company_name":"Acme Corporation","domain":"acme.example"}'
        ),
        "acme/build/checked.json": b'["Example platform"]',
        "acme/build/stack_names.json": b'["Example product"]',
        "acme/build/drop_example.json": b'[["Example platform","https://jobs.example/1"]]',
        "acme/build/platform_ranking_acme.py": (
            b'PLATFORMS = [("Example platform", "Cloud", "Digital", r"example\\b")]\n'
            b"raise RuntimeError('must never be executed')"
        ),
        "acme/build/build_stack.py": b'LANE = {"example": "Digital"}',
        "acme/build/build_people.py": b'lanes = ["Technology", "Commercial"]',
        "acme/build/build_jobs.py": b"raise RuntimeError('must never be executed')",
    }


def test_inspects_contract_files_and_structural_counts_without_running_builders() -> None:
    result = ingest.inspect_workspace_archive(_archive(_valid_files()))

    assert result.root == "acme"
    assert result.deliverables_found == 5
    assert dict(result.deliverables)["jobs"] == "acme/deliverables/Acme_Job_Postings.xlsx"
    assert result.internal_paths == ("acme/Acme_Internal_Only.docx",)
    assert result.issues == ()
    assert result.restore_facts is not None
    assert result.restore_facts.account_name == "Acme Corporation"
    assert result.restore_facts.account_short == "Acme"
    assert result.restore_facts.pursuing_client_display == "Client"
    assert str(result.restore_facts.run_date) == "2026-10-20"
    assert result.restore_facts.canonical_queries == (("Acme postings", "3 (2 open)."),)
    assert result.restore_facts.entity_rules == (
        "Waters positions are excluded from account counts.",
        "Databricks and Siebel are out of scope: never searched.",
    )
    assert result.restore_facts.out_of_scope_platforms == ("Databricks", "Siebel")
    assert result.company_name == "Acme Corporation"
    assert result.company_domain == "acme.example"
    assert result.build_config.checked_platforms == ("Example platform",)
    assert result.build_config.stack_names == ("Example product",)
    assert result.build_config.false_positive_drops == (
        ("Example platform", "https://jobs.example/1"),
    )
    assert result.build_config.platform_dictionary == (
        ("Example platform", "Cloud", "Digital", r"example\b"),
    )
    assert result.build_config.stack_lane_map == (("example", "Digital"),)
    assert result.build_config.people_lane_names == ("Technology", "Commercial")
    assert set(result.build_config.sources) == {
        "acme/build/checked.json",
        "acme/build/stack_names.json",
        "acme/build/drop_example.json",
        "acme/build/platform_ranking_acme.py",
        "acme/build/build_stack.py",
        "acme/build/build_people.py",
    }
    jobs = next(f for f in result.files if f.path.endswith("jobs.json"))
    assert jobs.json_arrays == (("jobs", 2),)
    book = next(f for f in result.files if f.path.endswith("Job_Postings.xlsx"))
    assert [(s.name, s.row_count) for s in book.sheet_info] == [("Jobs", 2)]
    assert book.sheet_info[0].header_candidates == ("Title", "Platforms named")
    summary = next(f for f in result.files if f.path.endswith("Account_Summary.docx"))
    assert summary.headings == ("heading 1: Account summary",)
    assert summary.table_count == 0


def test_reports_missing_and_ambiguous_contract_members() -> None:
    files = _valid_files()
    del files["acme/deliverables/Acme_People_List.xlsx"]
    files["acme/deliverables/Acme2_Job_Postings.xlsx"] = _xlsx()

    result = ingest.inspect_workspace_archive(_archive(files))

    assert "people:missing" in result.issues
    assert "jobs:ambiguous" in result.issues
    assert result.deliverables_found == 3


def test_prefers_restore_root_deliverables_over_historical_copies() -> None:
    files = _valid_files()
    for path, body in tuple(files.items()):
        if path.startswith("acme/deliverables/"):
            files[path.replace("acme/deliverables/", "acme/deliverables/prior/")] = body

    result = ingest.inspect_workspace_archive(_archive(files))

    assert result.deliverables_found == 5
    assert dict(result.deliverables)["jobs"] == "acme/deliverables/Acme_Job_Postings.xlsx"


@pytest.mark.parametrize(
    ("path", "body", "attr"),
    [
        ("../escape.txt", b"x", None),
        ("folder/./escape.txt", b"x", None),
        ("folder//escape.txt", b"x", None),
        ("/absolute.txt", b"x", None),
        ("folder\\escape.txt", b"x", None),
        ("link", b"x", (stat.S_IFLNK | 0o777) << 16),
    ],
)
def test_rejects_unsafe_zip_member_paths_and_types(
    path: str, body: bytes, attr: int | None
) -> None:
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w") as archive:
        info = zipfile.ZipInfo(path)
        if attr is not None:
            info.external_attr = attr
        archive.writestr(info, body)

    with pytest.raises(ingest.WorkspaceArchiveError):
        ingest.inspect_workspace_archive(out.getvalue())


def test_rejects_case_insensitive_duplicate_paths() -> None:
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w") as archive:
        archive.writestr("data/File.json", "{}")
        archive.writestr("data/file.JSON", "{}")

    with pytest.raises(ingest.WorkspaceArchiveError, match="duplicate"):
        ingest.inspect_workspace_archive(out.getvalue())


def test_reports_ambiguous_static_build_config_without_picking_a_value() -> None:
    result = ingest.inspect_workspace_archive(
        _archive(
            {
                "one/build/checked.json": b'["Platform A"]',
                "two/build/checked.json": b'["Platform B"]',
            }
        )
    )

    assert result.build_config.checked_platforms == ()
    assert any("ambiguous duplicate static build input" in issue for issue in result.issues)


def test_rejects_excessive_compression_ratio(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ingest, "MAX_COMPRESSION_RATIO", 2)
    with pytest.raises(ingest.WorkspaceArchiveError, match="compression ratio"):
        ingest.inspect_workspace_archive(_archive({"data.txt": b"x" * 10_000}))


def test_rejects_member_and_aggregate_size_limits(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ingest, "MAX_MEMBER_BYTES", 4)
    with pytest.raises(ingest.WorkspaceArchiveError, match="oversized"):
        ingest.inspect_workspace_archive(_archive({"data.bin": b"12345"}))

    monkeypatch.setattr(ingest, "MAX_MEMBER_BYTES", 100)
    monkeypatch.setattr(ingest, "MAX_TOTAL_BYTES", 6)
    with pytest.raises(ingest.WorkspaceArchiveError, match="expands beyond"):
        ingest.inspect_workspace_archive(_archive({"a.txt": b"1234", "b.txt": b"5678"}))


def test_malformed_json_is_reported_without_exposing_payload() -> None:
    result = ingest.inspect_workspace_archive(_archive({"data/source.json": b"{nope"}))

    assert "data/source.json: invalid JSON: ValueError" in result.issues
    assert "nope" not in repr(result)


def test_duplicate_json_object_keys_are_reported_as_invalid() -> None:
    result = ingest.inspect_workspace_archive(
        _archive({"data/source.json": b'{"jobs": [], "jobs": [{"id": "x"}]}'})
    )

    assert "data/source.json: invalid JSON: ValueError" in result.issues
    assert '"x"' not in repr(result)


def test_invalid_zip_is_refused() -> None:
    with pytest.raises(ingest.WorkspaceArchiveError, match="readable ZIP"):
        ingest.inspect_workspace_archive(b"not a zip")
