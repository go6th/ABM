"""Canonical query compilation stays conservative and traceable to RESTORE text."""

from __future__ import annotations

from account_intelligence.replica.workspace_queries import match_canonical_query
from exports.repair.canonical import compile_restore_queries


def test_canonical_query_predicates_are_derived_from_restore_prose() -> None:
    queries = compile_restore_queries(
        (
            (
                "Account postings",
                "rows in Example_Job_Postings.xlsx, sheet Jobs, where Platforms named "
                "contains Product A and Entity starts with Example. Base: dated rows. "
                "Answer: 25 (5 open).",
            ),
            (
                "Same workbook query",
                "same sheet, Platforms named contains Product B (also known by an alias). "
                "Answer: 9.",
            ),
            (
                "People query",
                "Example_People_List.xlsx, Meets seniority rule equals Yes: 14 of 30.",
            ),
        )
    )

    assert queries[0]["role"] == "jobs"
    assert queries[0]["sheet"] == "Jobs"
    assert queries[0]["where"] == [
        {"column": "Platforms named", "op": "contains", "value": "Product A"},
        {"column": "Entity", "op": "starts_with", "value": "Example"},
    ]
    assert queries[0]["base"] == "dated rows"
    assert queries[1]["where"] == [
        {"column": "Platforms named", "op": "contains", "value": "Product B"},
        {"column": "Entity", "op": "starts_with", "value": "Example"},
    ]
    assert queries[1]["base"] == "dated rows"
    assert queries[2]["where"] == [
        {"column": "Meets seniority rule", "op": "equals", "value": "Yes"}
    ]


def test_complex_or_unscoped_queries_remain_explicitly_not_derived() -> None:
    query = compile_restore_queries((("Unscoped query", "The answer needs analyst judgment."),))[0]
    assert query["derivable"] is False
    assert query["not_derived"] == ["query_scope_or_predicate_or_answer_shape"]


def test_secondary_metrics_are_not_derived_but_platform_ranking_reads_the_sheet() -> None:
    queries = compile_restore_queries(
        (
            (
                "Waters postings",
                "rows in Example_Job_Postings.xlsx, sheet Jobs, where Entity equals Waters. "
                "Base: current. Answer: 5 plus 2 pre-close.",
            ),
            (
                "Platform rank",
                "rows in Example_Tech_Stack_and_Teams.xlsx, sheet Platform Ranking. Answer: 10.",
            ),
        )
    )
    assert queries[0]["derivable"] is False
    assert queries[0]["not_derived"] == ["pre_close_count"]
    assert queries[1]["derivable"] is True
    assert queries[1]["role"] == "tech"
    assert queries[1]["sheet"] == "Platform Ranking"
    assert queries[1]["where"] == []


def test_canonical_question_match_must_be_unambiguous_and_supported() -> None:
    queries = compile_restore_queries(
        (
            (
                "Salesforce postings",
                "Sample_Job_Postings.xlsx, sheet Jobs, where Platforms named contains Salesforce.",
            ),
            (
                "SAP postings",
                "Sample_Job_Postings.xlsx, sheet Jobs, where Platforms named contains SAP.",
            ),
        )
    )
    assert match_canonical_query("How many Salesforce postings?", queries) == queries[0]
    assert match_canonical_query("How many postings?", queries) is None


def test_job_queries_keep_the_explicit_account_entity_scope() -> None:
    queries = compile_restore_queries(
        (
            (
                "Platform postings",
                "rows in Sample_Job_Postings.xlsx, sheet Jobs, where Platforms named contains "
                "Platform A and Entity starts with SAMPLE. Base: current.",
            ),
            ("Build roles", "Class equals Build role. Answer: 5."),
            ("Divested postings", "same sheet, Entity equals Divested business. Answer: 2."),
        )
    )
    assert queries[1]["where"] == [
        {"column": "Class", "op": "equals", "value": "Build role"},
        {"column": "Entity", "op": "starts_with", "value": "SAMPLE"},
    ]
    assert queries[1]["base"] == "current"
    assert queries[2]["where"] == [
        {"column": "Entity", "op": "equals", "value": "Divested business"}
    ]
