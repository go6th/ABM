"""Imported workbook tables preserve ordered source rows and typed columns."""

from __future__ import annotations

from exports.repair.table_store import _schema


def test_schema_preserves_source_rows_and_marks_long_text_as_payload() -> None:
    schema, rows = _schema(
        {
            "name": "Jobs",
            "rows": [
                ["Requisition", "Platforms named", "Full description"],
                ["R-1", "SAP, Workday", "x" * 700],
                ["R-2", "Salesforce", "short"],
            ],
        }
    )

    assert [column["raw"] for column in schema["columns"]] == [
        "Requisition",
        "Platforms named",
        "Full description",
    ]
    assert schema["payload_columns"] == ["full_description"]
    assert [row_no for row_no, _seq, _cells in rows] == [2, 3]
    assert rows[0][2]["platforms_named"] == "SAP, Workday"
    assert rows[1][2]["full_description"] == "short"


def test_repeated_and_empty_headers_have_unique_normalized_keys() -> None:
    schema, rows = _schema({"rows": [["Name", "Name", ""], ["A", "B", "C"]]})
    assert [column["name"] for column in schema["columns"]] == ["name", "name_2", "column_3"]
    assert rows[0][2] == {"name": "A", "name_2": "B", "column_3": "C"}


def test_header_is_selected_from_inspection_candidates_not_a_title_row() -> None:
    schema, rows = _schema(
        {
            "rows": [
                ["Platform ranking"],
                [None],
                ["Rank", "Platform", "Postings naming it"],
                ["A", "Example platform", 12],
            ]
        },
        ["Rank", "Platform", "Postings naming it"],
    )
    assert [column["raw"] for column in schema["columns"]] == [
        "Rank",
        "Platform",
        "Postings naming it",
    ]
    assert len(rows) == 1
    assert rows[0][2]["postings_naming_it"] == 12
