"""Parsed client views preserve deliverables and keep internal files out of exports."""

from __future__ import annotations

import io
import zipfile

from docx import Document
from openpyxl import Workbook

from exports.repair.ingest import inspect_workspace_archive
from exports.repair.views import build_workspace_view_payloads


def _docx(title: str, paragraph: str) -> bytes:
    document = Document()
    document.add_heading(title, level=1)
    document.add_paragraph(paragraph)
    output = io.BytesIO()
    document.save(output)
    return output.getvalue()


def _xlsx(sheet: str, rows: list[list[str]]) -> bytes:
    workbook = Workbook()
    page = workbook.active
    page.title = sheet
    for row in rows:
        page.append(row)
    output = io.BytesIO()
    workbook.save(output)
    return output.getvalue()


def test_views_parse_deliverables_and_export_only_client_files() -> None:
    source = io.BytesIO()
    files = {
        "Sample_Account_Summary.docx": _docx("Summary", "Client-facing summary."),
        "Sample_Sources_and_Evidence.docx": _docx("Evidence", "Source details."),
        "Sample_People_List.xlsx": _xlsx("People", [["Name", "Title"], ["Person", "Leader"]]),
        "Sample_Job_Postings.xlsx": _xlsx("Jobs", [["Title", "Status"], ["Engineer", "Open"]]),
        "Sample_Tech_Stack_and_Teams.xlsx": _xlsx("Platform Ranking", [["Platform", "Rank"]]),
        "Sample_Internal_Only.docx": _docx("Internal", "Must never be exported."),
        "RESTORE.md": b"# Sample workspace\n",
    }
    with zipfile.ZipFile(source, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, body in files.items():
            archive.writestr(f"sample/{name}", body)

    raw = source.getvalue()
    inspected = inspect_workspace_archive(raw)
    payloads = build_workspace_view_payloads(raw, inspected)

    assert set(payloads.views) == {"summary", "evidence", "people", "jobs", "tech"}
    assert payloads.issues == ()
    assert payloads.download is not None
    with zipfile.ZipFile(io.BytesIO(payloads.download)) as archive:
        names = set(archive.namelist())
        assert names == {
            f"deliverables/{name}"
            for name in files
            if name.endswith((".docx", ".xlsx")) and "Internal" not in name
        }
        assert "Must never be exported." not in str(archive.namelist())
