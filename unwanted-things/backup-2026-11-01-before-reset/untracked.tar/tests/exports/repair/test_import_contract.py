"""The importer persists a schema-validated subset and labels unparsed rules explicitly."""

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

from account_intelligence.api.routes.account_workspace import (
    WorkspaceImportConfig,
    WorkspaceImportValidation,
    _inspection_config,
    _inspection_report,
)
from exports.repair.ingest import inspect_workspace_archive


def test_partial_import_config_and_report_match_the_typed_contract() -> None:
    archive_bytes = io.BytesIO()
    with zipfile.ZipFile(archive_bytes, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(
            "sample/RESTORE.md",
            "# Sample (Sample Holdings) workspace\n"
            "Run date: 20 October 2026. Pursuing client: Client.\n"
            "## Canonical query definitions\n"
            '- "Sample postings": 7 open.\n'
            "## Entity rules\n- Legacy unit is out of scope.\n",
        )
        archive.writestr("sample/build/checked.json", '["Platform A"]')
        archive.writestr("sample/build/stack_names.json", '["Product A"]')
        archive.writestr(
            "sample/build/drop_platform.json",
            '[["Platform A","https://jobs.example/42"]]',
        )
        archive.writestr(
            "sample/build/platform_ranking_sample.py",
            'PLATFORMS = [("Platform A", "Cloud", "Digital", r"platforma")]',
        )
        archive.writestr("sample/build/build_stack.py", 'LANE = {"platforma": "Digital"}')
        archive.writestr("sample/build/build_people.py", 'lanes = ["Technology"]')
    inspection = inspect_workspace_archive(archive_bytes.getvalue())

    config = _inspection_config(inspection, "sample.example")
    schema = json.loads(
        (
            Path(__file__).resolve().parents[3] / "src/parity/schema/workspace_import.schema.json"
        ).read_text()
    )
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(config)
    WorkspaceImportConfig.model_validate(config)
    report = _inspection_report(inspection)
    validated_report = WorkspaceImportValidation.model_validate(report)

    assert config["completeness"] == "partial"
    assert config["not_derived"]
    assert config["canonical_queries"] == [
        {
            "query": "Sample postings",
            "answer": "7 open.",
            "role": None,
            "sheet": None,
            "where": [],
            "base": None,
            "entity_rule": None,
            "derivable": False,
            "not_derived": ["query_scope_or_predicate_or_answer_shape"],
        }
    ]
    assert config["checked_platforms"] == ["Platform A"]
    assert config["stack_names"] == ["Product A"]
    assert config["false_positive_drops"] == [
        {"platform": "Platform A", "url": "https://jobs.example/42"}
    ]
    assert config["platform_dictionary"] == [
        {"name": "Platform A", "category": "Cloud", "lane": "Digital", "pattern": "platforma"}
    ]
    assert config["stack_lane_map"] == {"platforma": "Digital"}
    assert config["people_lane_names"] == ["Technology"]
    assert config["derivation_sources"] == [
        "sample/build/checked.json",
        "sample/build/stack_names.json",
        "sample/build/drop_platform.json",
        "sample/build/platform_ranking_sample.py",
        "sample/build/build_stack.py",
        "sample/build/build_people.py",
    ]
    assert validated_report.pipeline_ready is False
    assert validated_report.deliverables_found == 0
