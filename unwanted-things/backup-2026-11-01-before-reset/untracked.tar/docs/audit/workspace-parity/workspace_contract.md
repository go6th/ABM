# Generic workspace contract (Phase 1 audit)

## Current repository contract

The current pipeline's input contract is a database-backed account/workspace profile plus normalized records, not an uploaded raw workspace zip. `src/exports/repair/core.py` defines ordered schemas for jobs, all postings, people, leadership, ranking, stack, teams, news, news facts, sources, searches, signals, coverage and mail. Explicit placeholders are `Not found`, `Not applicable`, `Unknown`, `Outside window`, `Not the account`, and `Not collected: <reason>`. `src/exports/repair/pipeline.py::repair_tables` fixes transform order; `repair()` returns checks, report and exclusions.

The documented repair package is the result of processing workspace tables. The package contains README, deliverables, Tables in CSV/XLSX, internal files and logs, as specified by `docs/repair/workspace_repair_spec.md` §10. The application also has a separate 6th Library flow that inspects/stores five finished deliverables, not arbitrary raw workspace ingestion (`src/account_intelligence/replica/library.py::inspect_package`).

The legacy input shape described in the template (RESTORE, raw data, build scripts, notes) is variable in actual archives. The selected BD Downloads archive has 372 entries / 191,256,802 uncompressed bytes; the older BD inventory in this tree describes a different 366-file copy. The current GSK zip has 22 entries / 1,937,771 uncompressed bytes, including a PPTX and prior deliverables. See [`inventory.md`](inventory.md) and the archive-specific inventories. Therefore the illustration cannot safely be imposed as a strict schema without an explicit compatibility contract.

## Existing JSON Schema

`src/parity/schema/workspace_config.schema.json` is present in the worktree and defines a candidate `workspace_config` schema, including identity, domains, date window, lanes, platforms, entity rules, title exclusions, out-of-scope platforms, checked platforms, drops, canonical queries and zero-result rule. It is currently untracked in git at audit time; treat it as work-in-progress evidence, not as a released API contract. It has a `BD` reference illustration in its descriptions, but no validated full BD instance was present alongside it.

## Required variable configuration (recommended schema surface)

The candidate schema should capture at minimum:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "required": ["account", "domains", "run_window", "lanes", "platforms", "entities", "canonical_queries"],
  "properties": {
    "account": {"type": "object", "required": ["name", "short_name"], "properties": {"name": {"type": "string"}, "short_name": {"type": "string"}, "aliases": {"type": "array", "items": {"type": "string"}}}},
    "domains": {"type": "array", "items": {"type": "string"}},
    "run_window": {"type": "object", "required": ["from", "to"], "properties": {"from": {"type": "string", "format": "date"}, "to": {"type": "string", "format": "date"}}},
    "lanes": {"type": "array", "items": {"type": "object"}},
    "platforms": {"type": "array", "items": {"type": "object"}},
    "entities": {"type": "array", "items": {"type": "object", "required": ["label", "counts_as_account"]}},
    "title_exclusions": {"type": "array", "items": {"type": "string"}},
    "out_of_scope_platforms": {"type": "array", "items": {"type": "string"}},
    "checked_platforms": {"type": "array", "items": {"type": "string"}},
    "false_positive_drops": {"type": "array", "items": {"type": "object"}},
    "canonical_queries": {"type": "array", "items": {"type": "object", "required": ["name", "predicates", "answer_source"]}},
    "zero_result_rule": {"type": "string"}
  }
}
```

This sketch summarizes the existing candidate, it is not a replacement schema or evidence that ingestion validates this structure end-to-end.

## BD instance status

The reference archive's full `ws/RESTORE.md` and all three `ws/notes/*.md` files were read directly from the zip. Their extracted facts appear in [`README.md`](README.md), including exact restore commands, canonical answers and entity rules. This audit did not extract and validate a complete `workspace_config` instance from all `ws/build/` scripts and intermediate JSON. The existing regression assertions document examples (Salesforce 551 / 92 open, SAP 1,068 / 150 open, ranking base 1,904; see `docs/repair/workspace_repair_spec.md` “BD regression” and `tests/parity/test_rules.py`), but those examples alone are not a full config and must not be mistaken for one.

## Generic versus account-specific

Generic/current: table schemas, placeholders, deterministic repair order, count thresholds, safe package checks, API table contracts, tenant scoping. Workspace-specific: account labels/domains/aliases, windows, lanes/platforms, entity patterns and close dates, title exclusions, out-of-scope items, false-positive drops, checked list, canonical predicates and their wording, evidence/narrative. The exact historical build flags and per-account RESTORE canonical answers remain to be extracted and validated from each archive.
