# Inventory: AmeriHealth_Caritas_workspace

Files: 31; total 9072 KB

Top level: `(root)` (1), `build` (12), `data` (12), `deliverables` (5), `notes` (1)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 1654 | 15 lines |
| `build/classify.py` | 4058 | 42 lines |
| `build/content.js` | 22467 | 108 lines |
| `build/docx_lib.js` | 4575 | 44 lines |
| `build/evidence.js` | 9860 | 39 lines |
| `build/ids.json` | 549 | list[81] |
| `build/jobs_workbook.py` | 7321 | 74 lines |
| `build/people_workbook.py` | 7793 | 75 lines |
| `build/profiles.py` | 4244 | 55 lines |
| `build/summary.js` | 12638 | 72 lines |
| `build/tech_workbook.py` | 3150 | 32 lines |
| `build/tracker.js` | 6400 | 40 lines |
| `build/urls.json` | 14297 | dict[81 keys]: S1,S2,S3,S4,S5,S6 |
| `data/jobs_12mo.json` | 7052665 | list[1318] |
| `data/live_board_postings.json` | 3862 | list[3] |
| `data/news_events.json` | 2176 | list[13] |
| `data/people_classified.json` | 45172 | dict[2 keys]: rows,removed |
| `data/people_grid.txt` | 12964 | 166 lines |
| `data/people_rows.json` | 49464 | list[161] |
| `data/posts_comments.json` | 281943 | dict[38 keys]: 1,4,5,7,9,10 |
| `data/profiles_analysis.json` | 140714 | list[160] |
| `data/profiles_full.json` | 1169505 | dict[165 keys]: 1,2,3,4,5,6 |
| `data/teams_1002.json` | 9064 | list[40] |
| `data/techstack_1002.json` | 6598 | list[54] |
| `data/techstack_detections.json` | 39142 | list[313] |
| `deliverables/AmeriHealth_Caritas_Account_Summary.docx` | 51318 | ERR AttributeError |
| `deliverables/AmeriHealth_Caritas_Job_Postings.xlsx` | 209323 | Summary=17x7; Jobs=157x13 |
| `deliverables/AmeriHealth_Caritas_People_List.xlsx` | 31831 | Summary=31x6; People=162x15 |
| `deliverables/AmeriHealth_Caritas_Sources_and_Evidence.docx` | 60659 | ERR AttributeError |
| `deliverables/AmeriHealth_Caritas_Tech_Stack_and_Teams.xlsx` | 23801 | Summary=5x6; Stack=55x4; Teams=41x5; Detections=314x6 |
| `notes/run_notes.md` | 1268 | 10 lines |
