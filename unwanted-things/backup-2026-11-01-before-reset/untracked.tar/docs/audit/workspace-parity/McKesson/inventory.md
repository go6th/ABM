# Inventory: McKesson_workspace

Files: 329; total 91267 KB

Top level: `(root)` (2), `build` (40), `data` (273), `deliverables` (6), `notes` (8)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 3515 | 26 lines |
| `build/build_evidence_doc.js` | 12578 | 130 lines |
| `build/build_jobs_workbook.py` | 6950 | 106 lines |
| `build/build_next_steps_doc.js` | 7978 | 61 lines |
| `build/build_people_workbook.py` | 7954 | 119 lines |
| `build/build_stack_workbook.py` | 5039 | 78 lines |
| `build/build_summary_doc.js` | 20010 | 193 lines |
| `build/classify_jobs.py` | 4337 | 79 lines |
| `build/content_news_tracker.json` | 13255 | dict[5 keys]: news,news_not_covered,tracker_waiting,tracker_p1,tracker_p2 |
| `build/content_service_map.json` | 21145 | dict[2 keys]: note,rows |
| `build/content_summary.json` | 27258 | dict[9 keys]: meta,narrative,signals_t1,signals_t2,signals_t3,signals_history |
| `build/docx_lib.js` | 4575 | 44 lines |
| `build/evidence_extracts.json` | 172693 | dict[8 keys]: part_b,part_c,part_e_keywords,part_e_boards,part_e_live_note,part_h_detections |
| `build/financial_voice.md` | 17220 | 111 lines |
| `build/jobs_all_min.json` | 1241359 | list[5105] |
| `build/jobs_enriched.json` | 16268624 | list[1988] |
| `build/jobs_pipeline.py` | 11558 | 212 lines |
| `build/key_people.json` | 8865 | list[29] |
| `build/make_sources.py` | 20792 | 122 lines |
| `build/news_signals.md` | 59070 | 202 lines |
| `build/package.json` | 50 | dict[1 keys]: dependencies |
| `build/people_final.json` | 2937240 | list[1978] |
| `build/people_findings.json` | 29029 | dict[5 keys]: excluded,alumni_counts,cert_counts,joiners_2026_senior,program_mentions |
| `build/people_pipeline.py` | 14001 | 270 lines |
| `build/platform_ranking_mck.py` | 11827 | 192 lines |
| `build/prep_evidence.py` | 6382 | 125 lines |
| `build/process_pulls.py` | 5588 | 98 lines |
| `build/rank_checked.json` | 272 | list[19] |
| `build/rank_stack.json` | 2097 | list[166] |
| `build/review_title_roles.json` | 70512 | list[91] |
| `build/save_fetches.py` | 6663 | 64 lines |
| `build/sources.json` | 41068 | dict[114 keys]: S1,S2,S3,S4,S5,S6 |
| `build/survey1.py` | 1985 | 67 lines |
| `build/survey2.py` | 3137 | 61 lines |
| `build/survey3.py` | 785 | 23 lines |
| `build/survey4.py` | 1023 | 25 lines |
| `build/survey5.py` | 353 | 12 lines |
| `build/survey6.py` | 1176 | 27 lines |
| `build/survey7.py` | 3331 | 71 lines |
| `build/survey8.py` | 1884 | 44 lines |
| `build/survey9.py` | 4850 | 73 lines |
| `data/company_record.json` | 672 | dict[9 keys]: domain,company_name,ticker,hq,parent_company_domain,subsidiary_domains |
| `data/connections.json` | 902888 | dict[3 keys]: count_reported,count_saved,rows |
| `data/drive_contacts_workbook.xlsx` | 54591 | McKesson key platform contacts =423x12 |
| `data/former_execs.json` | 5953 | dict[5 keys]: step,retrieved,collected_by,method,records |
| `data/jobs_12mo.json` | 38145647 | dict[3 keys]: count_reported,count_saved,rows |
| `data/jobs_keyword_counts.json` | 3880 | dict[6 keys]: lane_counts,tower_keyword_counts,bu_labels,categories,countries,status |
| `data/lane_map.json` | 3584 | dict[7 keys]: source,towers,added_lanes,standard_lanes_kept,never_query,run_decisions |
| `data/leadership.json` | 6461 | list[24] |
| `data/live_board.json` | 216491 | dict[3 keys]: boards,searches,missing_from_jobs_12mo |
| `data/news_events.json` | 93391 | dict[3 keys]: count_reported,count_saved,rows |
| `data/org_resolve.json` | 1078 | dict[4 keys]: query,results,note,source |
| `data/org_signals.json` | 11117 | dict[4 keys]: organization_id,count,signals,note |
| `data/people_grid.json` | 2581857 | list[1714] |
| `data/posts_comments.json` | 12753858 | dict[4 keys]: count,rows,note,source |
| `data/press_release_index_2026.txt` | 5867 | 35 lines |
| `data/profiles_full.json` | 8420369 | dict[3 keys]: count,profiles,source |
| `data/raw_step4/A_AWS.tsv` | 863 |  |
| `data/raw_step4/A_Agentforce.tsv` | 38 |  |
| `data/raw_step4/A_Alation.tsv` | 208 |  |
| `data/raw_step4/A_Ariba.tsv` | 635 |  |
| `data/raw_step4/A_Azure.tsv` | 737 |  |
| `data/raw_step4/A_BlueYonder.tsv` | 813 |  |
| `data/raw_step4/A_Boomi.tsv` | 16 |  |
| `data/raw_step4/A_CMDB.tsv` | 71 |  |
| `data/raw_step4/A_Collibra.tsv` | 38 |  |
| `data/raw_step4/A_CyberArk.tsv` | 38 |  |
| `data/raw_step4/A_Datadog.tsv` | 27 |  |
| `data/raw_step4/A_Dynatrace.tsv` | 202 |  |
| `data/raw_step4/A_EDI.tsv` | 1907 |  |
| `data/raw_step4/A_FHIR.tsv` | 2926 |  |
| `data/raw_step4/A_FinOps.tsv` | 38 |  |
| `data/raw_step4/A_Five9.tsv` | 16 |  |
| `data/raw_step4/A_GCP.tsv` | 480 |  |
| `data/raw_step4/A_Genesys.tsv` | 16 |  |
| `data/raw_step4/A_HealthCloud.tsv` | 1931 |  |
| `data/raw_step4/A_Informatica.tsv` | 1093 |  |
| `data/raw_step4/A_Kafka.tsv` | 794 |  |
| `data/raw_step4/A_Kinaxis.tsv` | 791 |  |
| `data/raw_step4/A_Kubernetes.tsv` | 429 |  |
| `data/raw_step4/A_Manhattan.tsv` | 16 |  |
| `data/raw_step4/A_MarketingCloud.tsv` | 833 |  |
| `data/raw_step4/A_MuleSoft.tsv` | 478 |  |
| `data/raw_step4/A_Okta.tsv` | 585 |  |
| `data/raw_step4/A_Oracle.tsv` | 567 |  |
| `data/raw_step4/A_PowerBI.tsv` | 1346 |  |
| `data/raw_step4/A_S4HANA.tsv` | 526 |  |
| `data/raw_step4/A_SAP.tsv` | 2320 |  |
| `data/raw_step4/A_SOX.tsv` | 1490 |  |
| `data/raw_step4/A_SQLServer.tsv` | 438 |  |
| `data/raw_step4/A_SailPoint.tsv` | 198 |  |
| `data/raw_step4/A_Salesforce.tsv` | 2595 |  |
| `data/raw_step4/A_ServiceNow.tsv` | 2284 |  |
| `data/raw_step4/A_Snowflake.tsv` | 1768 |  |
| `data/raw_step4/A_Splunk.tsv` | 286 |  |
| `data/raw_step4/A_Tableau.tsv` | 2619 |  |
| `data/raw_step4/A_Veeva.tsv` | 159 |  |
| `data/raw_step4/A_Workday.tsv` | 1953 |  |
| `data/raw_step4/A_contactcenter.tsv` | 2754 |  |
| `data/raw_step4/A_datagovernance.tsv` | 358 |  |
| `data/raw_step4/A_decisionintelligence.tsv` | 1029 |  |
| `data/raw_step4/A_generativeAI.tsv` | 1960 |  |
| `data/raw_step4/A_identityaccess.tsv` | 391 |  |
| `data/raw_step4/A_machinelearning.tsv` | 1114 |  |
| `data/raw_step4/careers_mckesson_technology_jobs.md` | 5061 | 33 lines |
| `data/raw_step4/missing_ids.json` | 10069 | dict[3 keys]: board_a_unique_ids,missing_count,missing |
| `data/raw_step4/posting_scrape_targets.json` | 3319 | list[13] |
| `data/redactions.txt` | 4312 | 33 lines |
| `data/releases/2016-06-27_vendor_five9_release_mckesson-executive-at-iqpc-call-center-week.md` | 3540 | 69 lines |
| `data/releases/2016-09-19_vendor_five9_release_cloud-connect-user-group-mckesson-quote.md` | 3985 | 67 lines |
| `data/releases/2017-05-17_vendor_informatica_release_2017-innovation-awards-mckesson-salesforce-customer-360.md` | 12010 | 137 lines |
| `data/releases/2019-04-08_vendor_google-cloud_wire-copy_mckesson-announces-move-to-google-cloud.md` | 16576 | 294 lines |
| `data/releases/2019-04-09_vendor_google-cloud_blog_mckesson-chooses-google-cloud.md` | 5455 | 45 lines |
| `data/releases/2019-06-05_vendor_snowflake_trade-press_snowflake-google-cloud-mckesson-first-customer.md` | 12635 | 154 lines |
| `data/releases/2019-11-15_vendor_salesforce-mulesoft_blog_google-partnership_mckesson-cto-quote.md` | 20644 | 277 lines |
| `data/releases/2020-08-18_vendor_google-cloud_blog_mckesson-database-architecture.md` | 6178 | 56 lines |
| `data/releases/2021-07-12_vendor_mulesoft_blog_mckesson-business-agility.md` | 8947 | 102 lines |
| `data/releases/2021-09-29_vendor_mulesoft_trade-press_diginomica_mckesson-uk.md` | 13255 | 179 lines |
| `data/releases/2022-01-24_fetched_vendor_mulesoft_blog_three-customers-healthcare-integration.md` | 761 | 8 lines |
| `data/releases/2022-12-09_fetched_vendor_github_customer-story_mckesson-labs-devops.md` | 864 | 9 lines |
| `data/releases/2024-05-29_person_krishnaraj_cdo-magazine-good-ai-needs-right-data-youtube.md` | 12338 | 56 lines |
| `data/releases/2024-07-01_vendor_snowflake_blog_mckesson-cross-cloud-data-journey.md` | 7100 | 100 lines |
| `data/releases/2024-07-20_person_dunbar_nacd-speaker-bio.md` | 1749 | 17 lines |
| `data/releases/2024-08-09_vendor_servicenow_community-webinar_transforming-itsm-with-training-mckesson.md` | 2114 | 26 lines |
| `data/releases/2024-10-09_vendor_gearset-salesforce_customer-story_mckesson-medical-surgical-devops.md` | 5831 | 72 lines |
| `data/releases/2024-10-17_vendor_microsoft-azure-openai_mckesson-release_ontada-collaborates-with-microsoft.md` | 6867 | 46 lines |
| `data/releases/2024-10-18_fetched_trade-press_precisionmedicineonline_ontada-microsoft-azure-ai.md` | 820 | 8 lines |
| `data/releases/2024-10-23_person_fraga_hitec-fireside-chat-capital-one.md` | 1439 | 22 lines |
| `data/releases/2024-11-23_vendor_mongodb-azure-openai_video_mckesson-supply-chain-modernization.md` | 17947 | 43 lines |
| `data/releases/2024-12-05_person_dunsire_biotech-ceo-sisterhood-interview.md` | 2021 | 24 lines |
| `data/releases/2024-12-30_person_wunderlich_what-i-wish-i-knew-podcast.md` | 1721 | 21 lines |
| `data/releases/2025-03-11_vendor_sap_partner-case-study-pdf_lemongrass_mckesson-fraga-quote.md` | 4583 | 61 lines |
| `data/releases/2025-04-16_mckesson_release_unveils-precision-care-companion.md` | 7530 | 51 lines |
| `data/releases/2025-04-29_person_srinivasan_covermymeds-barrier-breaker-podcast-ira.md` | 1831 | 23 lines |
| `data/releases/2025-05-01_mckesson-corporation-declares-quarterly-dividend.md` | 1844 | 25 lines |
| `data/releases/2025-05-01_person_hand_covermymeds-barrier-breaker-podcast-balancing-ai.md` | 1641 | 20 lines |
| `data/releases/2025-05-05_ontada_release_ispor-2025-real-world-evidence.md` | 26967 | 217 lines |
| `data/releases/2025-05-05_person_palani_heartbeat-podcast-salesforce-ai-readiness-youtube.md` | 21237 | 46 lines |
| `data/releases/2025-05-08_mckesson-reports-fiscal-2025-fourth-quarter-and-full-year-results-and-provides-f.md` | 20046 | 166 lines |
| `data/releases/2025-05-12_ontada_partner-news_atropos-health-collaborates-with-ontada.md` | 6802 | 159 lines |
| `data/releases/2025-05-13_person_eliasek_mckesson-canada-national-leadership-conference-agenda.md` | 3326 | 57 lines |
| `data/releases/2025-05-19_vendor_microsoft-azure_customer-story_mckesson-sap-to-azure.md` | 9338 | 195 lines |
| `data/releases/2025-06-01_us-oncology-network_release_asco-2025-pharmacist-driven-cost-savings.md` | 11035 | 74 lines |
| `data/releases/2025-06-03_mckesson-corporation-completes-acquisition-of-core-ventures.md` | 7429 | 45 lines |
| `data/releases/2025-06-04_person_lau_acc-inconversation-webcast.md` | 1448 | 14 lines |
| `data/releases/2025-06-09_covermymeds_release_acquires-rxlightning-and-fastauth.md` | 6944 | 79 lines |
| `data/releases/2025-06-11_mckesson-to-host-investor-day-on-september-23-2025.md` | 2510 | 27 lines |
| `data/releases/2025-06-26_mckesson-corporation-announces-first-quarter-fiscal-2026-earnings-release-date.md` | 2600 | 29 lines |
| `data/releases/2025-07-15_mckesson-ideashare-empowers-independent-pharmacies-to-innovate-and-thrive.md` | 6557 | 49 lines |
| `data/releases/2025-07-30_mckesson-corporation-raises-quarterly-dividend-by-15-to-0-82-per-share.md` | 1838 | 53 lines |
| `data/releases/2025-07-31_vendor_sap_trade-press_sapinsider_mckesson-case-study.md` | 20080 | 431 lines |
| `data/releases/2025-08-06_mckesson-corporation-reports-fiscal-2026-first-quarter-results-and-raises-full-y.md` | 15895 | 106 lines |
| `data/releases/2025-08-08_vendor_sap_supplier-notice_fresenius-kabi_mckesson-distribution-partners-s4hana.md` | 2020 | 73 lines |
| `data/releases/2025-08-26_person_attivilli_hba-dfw-leaders-leading-health-innovation-panel.md` | 3004 | 48 lines |
| `data/releases/2025-09-16_person_wetzel_fierce-pharma-webinar-brand-lifecycles.md` | 3742 | 33 lines |
| `data/releases/2025-09-18_mckesson-announces-new-organizational-structure.md` | 5057 | 47 lines |
| `data/releases/2025-09-23_investor-day-8-k-and-news-release-guidance-update.md` | 18332 | 345 lines |
| `data/releases/2025-09-23_investor_day_2025_presentation.md` | 84484 | 3383 lines |
| `data/releases/2025-09-23_investor_day_2025_transcript.md` | 186388 | 1215 lines |
| `data/releases/2025-09-23_mckesson-highlights-strategic-growth-strategies-and-updated-long-term-targets-at-investor-day.md` | 12704 | 80 lines |
| `data/releases/2025-10-01_dimitris-polygenis-named-new-president-of-mckesson-canada.md` | 3203 | 19 lines |
| `data/releases/2025-10-06_cell-and-gene-therapies-on-the-rise-new-report-reveals-growing-adoption-and-pers.md` | 5354 | 49 lines |
| `data/releases/2025-10-06_fetched_mckesson-story_logipharma-usa-2025-supply-chain.md` | 930 | 9 lines |
| `data/releases/2025-10-10_person_jhaveri_chain-drug-review-video-forum.md` | 893 | 13 lines |
| `data/releases/2025-10-17_person_fisher_ai-explained-podcast-17-day-process-to-3-minutes.md` | 1794 | 19 lines |
| `data/releases/2025-10-20_person_kettler_hlth-usa-2025-patients-know-first-panel.md` | 2803 | 28 lines |
| `data/releases/2025-10-23_person_hand_covermymeds-patient-direct-fireside-chat.md` | 2913 | 26 lines |
| `data/releases/2025-10-28_vendor_impetus_page_mckesson-data-driven-healthcare-enterprise.md` | 11712 | 309 lines |
| `data/releases/2025-10-30_mckesson-corporation-declares-quarterly-dividend.md` | 1441 | 23 lines |
| `data/releases/2025-11-04_person_kettler_covermymeds-insight-hlth-2025-patients-know-first.md` | 4221 | 37 lines |
| `data/releases/2025-11-05_earnings_call_FY26Q2.md` | 60137 | 507 lines |
| `data/releases/2025-11-05_mckesson-corporation-reports-fiscal-2026-second-quarter-results-and-raises-full.md` | 16102 | 113 lines |
| `data/releases/2025-11-06_person_gerberding_milken-future-of-health-2025-speaker.md` | 1760 | 23 lines |
| `data/releases/2025-11-29_person_hoxha_grizzhacks-tech-talk-announcement.md` | 903 | 15 lines |
| `data/releases/2025-12-01_mckesson-s-advancing-community-oncology-report-charts-a-new-era-of-innovation-fo.md` | 7193 | 46 lines |
| `data/releases/2025-12-03_person_kettler_unc-deans-speaker-keynote-youtube.md` | 62888 | 1707 lines |
| `data/releases/2025-12-04_person_hammonds_oncology-data-advisor-interview-youtube.md` | 17334 | 34 lines |
| `data/releases/2025-12-10_person_emami_leaders-in-ai-summit-speaker.md` | 782 | 18 lines |
| `data/releases/2025-12-22_mckesson-corporation-announces-third-quarter-fiscal-2026-earnings-release-date.md` | 1633 | 25 lines |
| `data/releases/2026-01-09_vendor_insightsoftware-simba_customer-story_mckesson-salesforce-odbc-businessobjects.md` | 5440 | 68 lines |
| `data/releases/2026-01-13_investor_conference_JPM_2026_presentation.md` | 31579 | 789 lines |
| `data/releases/2026-01-20_mckesson-s-practice-insights-designated-as-a-2026-qualified-clinical-data-regist.md` | 5795 | 51 lines |
| `data/releases/2026-01-28_mckesson-corporation-declares-quarterly-dividend.md` | 2347 | 27 lines |
| `data/releases/2026-01-30_mckesson-corporation-completes-divestiture-of-norwegian-operations.md` | 4112 | 35 lines |
| `data/releases/2026-02-04_earnings_call_FY26Q3.md` | 62231 | 390 lines |
| `data/releases/2026-02-04_mckesson-corporation-reports-fiscal-2026-third-quarter-results-and-raises-full-y.md` | 15241 | 116 lines |
| `data/releases/2026-02-08_person_hammonds_targeted-oncology-community-oncology-report-interview.md` | 7090 | 46 lines |
| `data/releases/2026-02-09_person_kaminsky_top-line-podcast-community-oncology.md` | 1840 | 14 lines |
| `data/releases/2026-02-28_person_modgil_convergence-ai-dallas-2026-speaker.md` | 1294 | 21 lines |
| `data/releases/2026-03-01_vendor_sap_customer-document_mckesson-advanced-track-and-trace-s4hana.md` | 2076 | 25 lines |
| `data/releases/2026-03-05_mckesson-announces-planned-cfo-transition.md` | 8058 | 43 lines |
| `data/releases/2026-03-06_mckesson-corporation-announces-fourth-quarter-fiscal-2026-earnings-release-date.md` | 3111 | 30 lines |
| `data/releases/2026-03-09_covermymeds_release_expands-specialty-access-and-affordability-solutions.md` | 7033 | 64 lines |
| `data/releases/2026-03-10_person_branick_hda-distribution-management-conference-2026-sessions.md` | 3761 | 72 lines |
| `data/releases/2026-03-18_vendor_sap-microsoft_conference-session_mckesson-sap-migration-to-azure.md` | 2380 | 50 lines |
| `data/releases/2026-03-19_mckesson-ideashare-2026-invites-independent-pharmacists-to-learn-connect-and-gro.md` | 6617 | 50 lines |
| `data/releases/2026-04-20_mckesson-signs-agreement-with-apollo-funds-for-strategic-minority-interest-in-me.md` | 7739 | 54 lines |
| `data/releases/2026-04-22_event_asembia-axs26_biologics-by-mckesson-sessions-and-team.md` | 4880 | 62 lines |
| `data/releases/2026-04-22_mckesson-corporation-declares-quarterly-dividend.md` | 2362 | 27 lines |
| `data/releases/2026-04-29_person_wetzel_covermymeds-webinar-whats-new-access-affordability.md` | 2878 | 28 lines |
| `data/releases/2026-04-30_person_delatore_pharmaceutical-commerce-ai-and-the-access-gap.md` | 2566 | 20 lines |
| `data/releases/2026-05-05_mckesson-canada-health-care-at-a-turning-point-patient-innovation-summit.md` | 5438 | 13 lines |
| `data/releases/2026-05-07_earnings_call_FY26Q4.md` | 81899 | 901 lines |
| `data/releases/2026-05-07_mckesson-reports-fiscal-2026-fourth-quarter-and-full-year-results-provides-fisca.md` | 19426 | 157 lines |
| `data/releases/2026-05-07_person_delatore_pharmaceutical-commerce-asembia-axs26-next-phase-specialty.md` | 2135 | 27 lines |
| `data/releases/2026-05-07_sec_10-K_FY2026_excerpts.md` | 116016 | 579 lines |
| `data/releases/2026-05-14_ontada_release_12-real-world-studies-at-ispor-2026-on-journey.md` | 16336 | 212 lines |
| `data/releases/2026-05-21_ontada_release_integrates-florida-cancer-specialists-data.md` | 17219 | 217 lines |
| `data/releases/2026-05-21_person_palani_crm-coe-roundtable-april-2026-youtube.md` | 28099 | 38 lines |
| `data/releases/2026-05-27_inspirogene-by-mckesson-expands-us-patient-access-to-kite-car-t-cell-therapies.md` | 3662 | 19 lines |
| `data/releases/2026-05-28_ontada_release_asco-2026-glp1-study.md` | 17124 | 162 lines |
| `data/releases/2026-05-29_us-oncology-network_release_asco-2026-app-led-models.md` | 9552 | 59 lines |
| `data/releases/2026-06-02_mckesson-closes-strategic-investment-with-apollo-funds-for-minority-interest-in.md` | 6699 | 49 lines |
| `data/releases/2026-06-12_sec_DEF14A_2026_proxy_excerpts.md` | 76262 | 1162 lines |
| `data/releases/2026-06-23_mckesson-ideashare-2026-fuels-momentum-for-independent-pharmacies.md` | 7842 | 59 lines |
| `data/releases/2026-06-23_tech_wire_mckesson-selects-moore-oklahoma-automated-regional-distribution-center.md` | 15104 | 188 lines |
| `data/releases/2026-06-24_mckesson-corporation-announces-first-quarter-fiscal-2027-earnings-release-date.md` | 2600 | 29 lines |
| `data/releases/2026-07-01_sec_8-K_chief_strategy_officer_transition.md` | 3976 | 120 lines |
| `data/releases/2026-07-08_person_tyler_dceo-dallas-500-interview.md` | 4606 | 40 lines |
| `data/releases/2026-07-13_mckesson-releases-fiscal-year-2026-impact-report.md` | 4843 | 43 lines |
| `data/releases/2026-07-14_person_helton_targeted-oncology-intelligent-medical-record-article.md` | 4968 | 67 lines |
| `data/releases/2026-07-15_tech_trade-press_distribution-strategy_mckesson-bets-on-ai.md` | 10336 | 120 lines |
| `data/releases/2026-07-22_mckesson-corporation-raises-quarterly-dividend-by-15-to-0-94-per-share.md` | 2934 | 29 lines |
| `data/releases/2026-08-05_earnings_call_FY27Q1.md` | 55722 | 421 lines |
| `data/releases/2026-08-05_mckesson-reports-fiscal-2027-first-quarter-results-and-raises-full-year-adjusted.md` | 16391 | 120 lines |
| `data/releases/2026-08-05_sec_10-Q_Q1_FY2027_excerpts.md` | 46087 | 340 lines |
| `data/releases/2026-08-05_vendor_kinaxis_mckesson-job-posting_sr-architect-maestro-kinaxis.md` | 28770 | 489 lines |
| `data/releases/2026-08-21_person_jhaveri_drug-store-news-video-barriers-to-care.md` | 1040 | 20 lines |
| `data/releases/2026-08-25_mckesson-signs-agreement-to-acquire-precision-medicine-group-llc.md` | 5383 | 39 lines |
| `data/releases/2026-08-28_sec_8-K_cybersecurity_incident_item_7-01.md` | 4136 | 121 lines |
| `data/releases/2026-08-28_trade-press_bleepingcomputer_mckesson-discloses-breach.md` | 13546 | 171 lines |
| `data/releases/2026-08-28_trade-press_start-with-identity_mckesson-breach-okta-sso-salesforce-snowflake.md` | 1829 | 19 lines |
| `data/releases/2026-08-31_trade-press_fierce-healthcare_mckesson-confirms-cybersecurity-incident.md` | 11903 | 174 lines |
| `data/releases/2026-09-01_substack_rod-trent_security-check-in-mckesson-extortion-breach.md` | 1713 | 19 lines |
| `data/releases/2026-09-08_mckesson-statement_notice-of-data-breach.md` | 5261 | 37 lines |
| `data/releases/2026-09-18_trade-press_hipaa-journal_mckesson-cyberattack-stolen-data.md` | 25587 | 302 lines |
| `data/releases/2026-09-21_mckesson-statement_customer-cybersecurity-information-center-updates-aug28-aug29-sep21.md` | 5321 | 83 lines |
| `data/releases/2026-09-22_leadership_trade-press_cara-mcdonough-joins-medical-surgical-chief-product-strategy.md` | 1993 | 19 lines |
| `data/releases/2026-09-23_mckesson-corporation-announces-second-quarter-fiscal-2027-earnings-release-date.md` | 2612 | 29 lines |
| `data/releases/2026-09-28_person_wetzel_covermymeds-insight-faster-therapy-starts.md` | 3284 | 44 lines |
| `data/releases/2026-10-01_mckesson-corporation-extends-pharmaceutical-distribution-agreement-with-cvs-heal.md` | 4847 | 35 lines |
| `data/releases/2026-10-05_new-2026-cell-and-gene-therapy-report-charts-the-path-from-scientific-progress.md` | 13382 | 188 lines |
| `data/releases/2026-10-05_person_modgil_avant-south-2026-speakers.md` | 356 | 13 lines |
| `data/releases/2026-10-06_cd-r-and-mckesson-corporation-sign-agreement-to-acquire-option-care-health.md` | 20211 | 110 lines |
| `data/releases/2026-10-07_person_helton_oncology-news-central-intelligent-medical-record-interview.md` | 4509 | 51 lines |
| `data/releases/2026-10-08_substack_buy-build-exit_mckesson-option-care-play.md` | 2951 | 34 lines |
| `data/releases/2026-10-13_event_dreamforce-2025_mckesson-agentforce-customer-onboarding-session.md` | 1225 | 36 lines |
| `data/releases/2026-10-13_event_ideashare-2026_general-sessions-keynote-agenda.md` | 4601 | 65 lines |
| `data/releases/2026-10-13_event_mckesson-compile_events-page.md` | 2995 | 37 lines |
| `data/releases/2026-10-13_event_mckesson-health-systems_conferences-and-events-page.md` | 6296 | 78 lines |
| `data/releases/2026-10-13_fetched_investor_wells-fargo-2026-healthcare-conference.md` | 379 | 5 lines |
| `data/releases/2026-10-13_fetched_mckesson-story_ideashare-2026-ai-advocacy-community-care.md` | 693 | 9 lines |
| `data/releases/2026-10-13_fetched_pharmacytimes_ideashare-2026-van-norman-supply-chain-ai.md` | 1048 | 10 lines |
| `data/releases/2026-10-13_fetched_review-site_g2_mckesson-seller-page.md` | 535 | 9 lines |
| `data/releases/2026-10-13_leadership_aggregator_org-chart-under-cio-cto-francisco-fraga.md` | 3072 | 140 lines |
| `data/releases/2026-10-13_leadership_mckesson-bio_francisco-fraga-evp-cio-cto.md` | 1945 | 21 lines |
| `data/releases/2026-10-13_leadership_mckesson-bio_jason-hammonds-president-oncology-multispecialty.md` | 1746 | 25 lines |
| `data/releases/2026-10-13_leadership_mckesson-bio_joan-eliasek-president-na-pharmaceutical-distribution.md` | 2335 | 25 lines |
| `data/releases/2026-10-13_leadership_mckesson-bio_kenny-cheung-evp-cfo.md` | 2564 | 25 lines |
| `data/releases/2026-10-13_leadership_mckesson-bio_kevin-kettler-president-prescription-technology-solutions.md` | 2017 | 21 lines |
| `data/releases/2026-10-13_leadership_mckesson-bio_ramesh-srinivasan-evp-chief-strategy-officer.md` | 2398 | 27 lines |
| `data/releases/2026-10-13_live_JR0140831_senior-lead-data-scientist.md` | 4853 | 50 lines |
| `data/releases/2026-10-13_live_JR0147160_salesforce-crm-developer.md` | 3788 | 65 lines |
| `data/releases/2026-10-13_live_JR0148633_senior-manager-ai-products-copilot-solutions.md` | 4908 | 69 lines |
| `data/releases/2026-10-13_live_JR0149101_senior-manager-data-hub-engineering-data-products.md` | 6218 | 74 lines |
| `data/releases/2026-10-13_live_JR0151827_service-now-ai-devops-specialist.md` | 4028 | 59 lines |
| `data/releases/2026-10-13_live_JR0152404_sr-ai-first-full-stack-engineer.md` | 6904 | 73 lines |
| `data/releases/2026-10-13_live_JR0152750_sr-product-security-engineer-ai-devsecops.md` | 5251 | 54 lines |
| `data/releases/2026-10-13_live_JR0153271_senior-specialist-ai-transformation.md` | 5534 | 58 lines |
| `data/releases/2026-10-13_live_JR0153913_principal-ai-transformation-strategist-ftc.md` | 6425 | 78 lines |
| `data/releases/2026-10-13_live_JR0154550_principle-employee-enablement-architect.md` | 6836 | 50 lines |
| `data/releases/2026-10-13_live_JR0155012_lead-technology-integration-mississauga.md` | 4373 | 59 lines |
| `data/releases/2026-10-13_live_JR0155013_lead-technology-integration-irving.md` | 4390 | 59 lines |
| `data/releases/2026-10-13_live_JR0155354_senior-full-stack-ai-software-engineer-java.md` | 5287 | 68 lines |
| `data/releases/2026-10-13_mckesson-canada_view-all-press-releases-page.md` | 89508 | 242 lines |
| `data/releases/2026-10-13_mckesson-statement_cybersecurity-page-as-captured.md` | 2550 | 53 lines |
| `data/releases/2026-10-13_person_bashiti_future-forums-decision-velocity-talk.md` | 706 | 22 lines |
| `data/releases/2026-10-13_person_bashiti_world-finance-forum-philadelphia-2027-speaker.md` | 958 | 38 lines |
| `data/releases/2026-10-13_person_bhanawat_leaders-in-ai-summit-2024-speaker.md` | 1519 | 16 lines |
| `data/releases/2026-10-13_person_delatore_mckesson-from-start-to-scale-specialty-access.md` | 2636 | 37 lines |
| `data/releases/2026-10-13_person_hammonds_endpoints-asco-2026-panel-community-oncology.md` | 3706 | 33 lines |
| `data/releases/2026-10-13_person_helton_mckesson-intelligent-medical-record-community-oncology.md` | 1755 | 29 lines |
| `data/releases/2026-10-13_person_kaminsky_milken-future-of-health-summit-2024-speaker.md` | 2001 | 14 lines |
| `data/releases/2026-10-13_person_rehman_patient-support-summit-2025-speakers.md` | 1241 | 29 lines |
| `data/releases/2026-10-13_person_rowe_hida-streamlining-healthcare-distributor-qa.md` | 983 | 30 lines |
| `data/releases/2026-10-13_undated-captured_mckesson-story_digitally-transforming-specialty-medication-workflows.md` | 6177 | 102 lines |
| `data/releases/2026-10-13_undated-captured_tech_covermymeds_latent-health-intelligent-automation-fhir.md` | 7534 | 85 lines |
| `data/releases/2026-10-13_undated-captured_tech_mckesson-story_ai-in-community-oncology.md` | 9469 | 121 lines |
| `data/releases/2026-10-13_undated-captured_tech_mckesson-story_reducing-administrative-burden-with-ai-tools.md` | 9526 | 140 lines |
| `data/releases/2026-10-13_undated-captured_vendor_blue-yonder_customer-story_mckesson-canada.md` | 14132 | 297 lines |
| `data/releases/2026-10-13_undated-captured_vendor_five9_trade-press_emerj_ai-at-mckesson-three-use-cases.md` | 26089 | 256 lines |
| `data/releases/2026-10-13_undated-captured_vendor_five9_webinar_five9-x-mckesson-town-hall.md` | 1961 | 58 lines |
| `data/releases/2026-10-13_undated-captured_vendor_genesys_mckesson-job-posting_sr-contact-center-specialist-genesys.md` | 12835 | 208 lines |
| `data/releases/2026-10-13_undated-captured_vendor_informatica_video_mckesson-where-healthcare-data-comes-to-life.md` | 3364 | 54 lines |
| `data/releases/2026-10-13_undated-captured_vendor_microsoft-azure-openai_customer-story_ontada-150-million-documents.md` | 13441 | 222 lines |
| `data/releases/2026-10-13_undated-captured_vendor_okta_integration-network_mckesson-supply-manager.md` | 16569 | 420 lines |
| `data/releases/2026-10-13_undated-captured_vendor_openai_mckesson-job-posting_sr-ai-first-full-stack-engineer.md` | 13370 | 200 lines |
| `data/releases/2026-10-13_undated-captured_vendor_sap_partner-case-study_lemongrass_mckesson.md` | 6733 | 107 lines |
| `data/releases/2026-10-13_undated-captured_vendor_servicenow_customer-story_mckesson-itsm-rollout.md` | 19665 | 370 lines |
| `data/releases/2026-10-13_undated-captured_vendor_snowflake_marketplace_mckesson-compile-provider-listing.md` | 6857 | 76 lines |
| `data/releases/2026-10-13_undated-captured_vendor_tableau_account-page_mckesson.md` | 4424 | 142 lines |
| `data/releases/2026-10-13_undated-captured_vendor_workday-evisort_success-story_mckesson-contracting-at-scale.md` | 4904 | 186 lines |
| `data/releases/2026-10-13_undated-captured_vendor_workday_customer-story_mckesson-contract-review-ai.md` | 14182 | 259 lines |
| `data/releases/2026-10-13_vendor_tableau-okta_mckesson-analytics-portal-sign-in-page.md` | 329 | 17 lines |
| `data/site_map_news.txt` | 23575 | 231 lines |
| `data/subsidiary_domains.json` | 2457704 | dict[10 keys]: usoncology.com,mckessoncompile.com,covermymeds.health,mckesson.ca,healthmart.com,mckesson.eu |
| `data/subsidiary_domains_banner.json` | 5748 | dict[3 keys]: pulled,source,domains |
| `data/teams.json` | 135064 | dict[3 keys]: total_matching,teams,source |
| `data/techstack_confirmed.json` | 5147 | dict[5 keys]: organization_id,tool_label_note,metric,stack,source |
| `data/techstack_detections.json` | 212982 | dict[3 keys]: count_reported,count_saved,rows |
| `data/web_searches.json` | 131241 | list[626] |
| `data/web_searches_step10.json` | 88744 | INVALID JSON (JSONDecodeError) |
| `data/web_searches_step2.json` | 30165 | list[72] |
| `data/web_searches_step4.json` | 11695 | INVALID JSON (JSONDecodeError) |
| `deliverables/McKesson_Account_Summary.docx` | 69444 | 112 paras, 36 headings, 22 tables |
| `deliverables/McKesson_Job_Postings.xlsx` | 3286091 | Summary=33x8; Jobs=1991x15 |
| `deliverables/McKesson_Next_Steps.docx` | 14473 | 17 paras, 4 headings, 1 tables |
| `deliverables/McKesson_People_List.xlsx` | 245516 | Summary=22x8; People=1981x14 |
| `deliverables/McKesson_Sources_and_Evidence.docx` | 107190 | 395 paras, 50 headings, 14 tables |
| `deliverables/McKesson_Tech_Stack_and_Teams.xlsx` | 25323 | Platform Ranking=53x10; Confirmed stack=176x5; Platform teams=30x8 |
| `notes/pass1.md` | 3352 | 21 lines |
| `notes/person_search_targets.json` | 20579 | list[119] |
| `notes/posts_row_ids.json` | 4302 | list[611] |
| `notes/profile_row_ids.json` | 6016 | list[826] |
| `notes/run_spec.md` | 1501 | 8 lines |
| `notes/s1_page2_targets.json` | 2833 | dict[2 keys]: profiles,posts |
| `notes/sense_check.md` | 6220 | 52 lines |
| `notes/title_lists.md` | 2324 | 4 lines |
| `pull_log.md` | 17750 | 115 lines |
