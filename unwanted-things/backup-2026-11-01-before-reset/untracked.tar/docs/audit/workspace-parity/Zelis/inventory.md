# Inventory: Zelis_workspace

Files: 91; total 22759 KB

Top level: `(root)` (2), `build` (22), `data` (59), `deliverables` (5), `notes` (3)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 1791 | 22 lines |
| `build/all_ids.json` | 432 | list[75] |
| `build/checked.json` | 79 | list[4] |
| `build/common.js` | 1876 | 21 lines |
| `build/evidence.js` | 13699 | 116 lines |
| `build/evidence_data.json` | 61928 | dict[6 keys]: ext,lanerows,board,kws,det,news |
| `build/evidence_data.py` | 4639 | 58 lines |
| `build/excluded_names.json` | 297 | list[17] |
| `build/jobs12.json` | 5472015 | list[713] |
| `build/jobs_base.json` | 50356 | list[347] |
| `build/jobs_wb.py` | 8200 | 116 lines |
| `build/lane_rows.json` | 929447 | list[112] |
| `build/people_build.py` | 9249 | 114 lines |
| `build/people_merged.json` | 241064 | dict[4 keys]: people,excl_sec,excl_ent,moved |
| `build/people_wb.py` | 8133 | 109 lines |
| `build/profile_findings.json` | 12267 | dict[4 keys]: si,kw,recent_joins,certs |
| `build/profile_findings2.json` | 14598 | dict[13 keys]: base_people,with_profile,senior,si,si_senior,any_si |
| `build/profile_findings2.py` | 4233 | 47 lines |
| `build/stack_names.json` | 2149 | list[145] |
| `build/stack_wb.py` | 5120 | 76 lines |
| `build/summary.js` | 48472 | 302 lines |
| `build/summary_ids.json` | 387 | list[67] |
| `build/urls.js` | 23087 | 82 lines |
| `data/company_record.json` | 652 | dict[9 keys]: source,domain,company_name,hq,locations,parent_domain |
| `data/connections.json` | 89537 | dict[5 keys]: source,params,count_reported,count_saved,connections |
| `data/jobs_12mo.json` | 6014303 | dict[5 keys]: source,params,count_reported,count_saved,jobs |
| `data/jobs_keyword_counts.json` | 1843 | dict[29 keys]: Salesforce,MuleSoft,ServiceNow,SAP,Tableau,Veeva |
| `data/leadership.json` | 2326 | dict[8 keys]: source,page,page_modified,captured,executives,investor_logos_on_page |
| `data/live_board.json` | 39550 | dict[14 keys]: collected_on,source,boards,boards_linked_not_scraped,subsidiary_boards,search_url_pattern |
| `data/news_events.json` | 10343 | dict[5 keys]: source,params,count_reported,count_saved,events |
| `data/newsroom.json` | 1702 | dict[5 keys]: source,page,captured,latest_announcements,in_the_news |
| `data/org_resolve.json` | 453 | dict[9 keys]: source,organization_id,slug,name,url,employee_count |
| `data/org_signals.json` | 82 | dict[4 keys]: source,organization_id,signals,count |
| `data/people_gapcheck.json` | 5285 | dict[4 keys]: source,params_common,note,lanes |
| `data/people_grid_history.json` | 749478 | dict[3 keys]: source,note,rows |
| `data/posts_comments.json` | 3301614 | dict[7 keys]: source,rule,rows_run,rows_with_output,post_items,comment_items |
| `data/profiles_full.json` | 4623452 | dict[5 keys]: source,rows,rows_without_profile,profiles,current_employer_counts |
| `data/releases/2022-04-26_web_zelis-linda-zukauckas-board-appointment.md` | 3802 | 29 lines |
| `data/releases/2022-08-16_web_zelis-wayne-deveydt-board-appointment.md` | 3882 | 33 lines |
| `data/releases/2023-04-03_web_zelis-announces-sue-schick-president-cro.md` | 4347 | 35 lines |
| `data/releases/2024-03-21_zelis-and-strategic-alliance-[redacted].md` | 5557 | 36 lines |
| `data/releases/2025-05-08_zelis-health-bill-assist-wins-healthcare-insurance-innovation-award.md` | 5929 | 39 lines |
| `data/releases/2025-06-03_zelis-acquires-assets-of-medxoom.md` | 3145 | 20 lines |
| `data/releases/2025-07-01_zelis-recognized-as-a-2025-great-place-to-work-in-the-us-and-india.md` | 3564 | 32 lines |
| `data/releases/2025-08-04_web_beckers-meet-unitedhealth-groups-new-cfo.md` | 1329 | 27 lines |
| `data/releases/2025-09-22_web_builtin_senior-product-manager-salesforce-platform.md` | 1811 | 14 lines |
| `data/releases/2025-10-16_zelis-study-shows-employers-consumers-believe-ai-digital-tools-transparency-will-improve-healthcare.md` | 7682 | 62 lines |
| `data/releases/2025-10-23_zelis-celebrated-again-as-a-fortune-best-workplaces-for-women.md` | 2955 | 22 lines |
| `data/releases/2025-10-29_zelis-intelligent-pricing-platform-launch.md` | 5219 | 42 lines |
| `data/releases/2025-11-14_duck-creek-working-with-zelis-on-payments.md` | 4007 | 24 lines |
| `data/releases/2025-11-19_web_builtin_director-salesforce-coe.md` | 4176 | 21 lines |
| `data/releases/2025-12-04_zelis-appoints-jim-bridges-as-president-of-price-optimization.md` | 2787 | 20 lines |
| `data/releases/2026-01-12_zelis-acquires-rivet.md` | 3037 | 22 lines |
| `data/releases/2026-01-29_zelis-introduces-zapp-edge.md` | 3439 | 24 lines |
| `data/releases/2026-02-04_zelis-earns-top-score-on-hrc-corporate-equality-index-second-consecutive-year.md` | 2917 | 22 lines |
| `data/releases/2026-03-27_jopari-solutions-expands-digital-payments-through-partnership-with-zelis.md` | 4386 | 38 lines |
| `data/releases/2026-04-02_web_builtin_sr-salesforce-developer-2.md` | 455 | 7 lines |
| `data/releases/2026-04-20_new-chief-strategy-revenue-officers.md` | 4585 | 34 lines |
| `data/releases/2026-05-07_zelis-wins-2026-medtech-breakthrough-award-for-healthcare-payments-innovation.md` | 5022 | 38 lines |
| `data/releases/2026-05-22_zelis-recognized-as-a-2026-great-place-to-work-in-the-us-and-india.md` | 3492 | 26 lines |
| `data/releases/2026-06-18_zelis-picks-aws-to-automate-healthcare-pricing-and-payments.md` | 3148 | 31 lines |
| `data/releases/2026-06-19_zelis-selects-aws-to-modernize-the-healthcare-financial-experience.md` | 2848 | 22 lines |
| `data/releases/2026-06-24_zelis-launches-ai-native-solution-to-help-payers-address-rising-idr-challenges.md` | 6481 | 54 lines |
| `data/releases/2026-07-10_zelis-a-leader-in-everest-groups-peak-matrix-assessment-2026.md` | 8604 | 68 lines |
| `data/releases/2026-07-30_zelis-research-on-payer-concerns-over-administrative-complexity.md` | 7222 | 58 lines |
| `data/releases/2026-08-17_vyne-dental-and-zelis-partner-to-modernize-insurance-payments.md` | 4649 | 41 lines |
| `data/releases/2026-09-14_web_businesswire-zelis-names-jim-young-cfo-succeeding-gladden.md` | 3246 | 27 lines |
| `data/releases/2026-09-14_zelis-names-jim-young-chief-financial-administrative-officer.md` | 2929 | 18 lines |
| `data/releases/2026-09-17_zelis-brings-clarity-to-healthcare-costs.md` | 5683 | 43 lines |
| `data/releases/2026-10-07_live_JR108546_2nd-machine-operators-fenton-mo.md` | 5226 | 87 lines |
| `data/releases/undated_web_drexel-lebow-sue-schick-bio.md` | 2571 | 19 lines |
| `data/releases/undated_web_investorshangout-sue-schick-turningpoint-ceo.md` | 4154 | 38 lines |
| `data/releases/undated_web_marketscreener-linda-zukauckas-profile.md` | 2264 | 46 lines |
| `data/releases/undated_web_marketscreener-sue-schick-profile.md` | 1898 | 39 lines |
| `data/releases/undated_web_marketscreener-wayne-deveydt-profile.md` | 3147 | 59 lines |
| `data/releases/undated_web_moduscreate-homepage-not-zelis-case-study.md` | 2929 | 41 lines |
| `data/releases/undated_web_zelis-leadership-sue-schick-redirect.md` | 1068 | 15 lines |
| `data/subsidiary_domains.json` | 106554 | dict[2 keys]: source,subsidiaries |
| `data/teams.json` | 81429 | dict[5 keys]: source,params,total_matching,count_saved,teams |
| `data/techstack_confirmed.json` | 12021 | dict[5 keys]: source,organization,pulled,note,business_functions |
| `data/techstack_detections.json` | 115642 | dict[5 keys]: source,params,count_reported,count_saved,detections |
| `data/web_searches.json` | 245185 | dict[3 keys]: source,queries,former_exec_checks |
| `deliverables/Zelis_Account_Summary.docx` | 49655 | ERR AttributeError |
| `deliverables/Zelis_Job_Postings.xlsx` | 519053 | Summary=33x9; Jobs=348x18 |
| `deliverables/Zelis_People_List.xlsx` | 65374 | Summary=34x6; People=572x12; Excluded=27x3 |
| `deliverables/Zelis_Sources_and_Evidence.docx` | 77558 | ERR AttributeError |
| `deliverables/Zelis_Tech_Stack_and_Teams.xlsx` | 46876 | Platform Ranking=37x10; Confirmed Stack=148x5; Platform Teams=28x6; Technology Detections=689x4 |
| `notes/pass1.md` | 1303 | 9 lines |
| `notes/phase2_notes.md` | 1979 | 21 lines |
| `notes/sense_check.md` | 5837 | 37 lines |
| `pull_log.md` | 67559 | 408 lines |
