# Inventory: Tolmar_workspace.zip

Archive: `/home/sakib/Downloads/Tolmar_workspace.zip`
SHA-256: `1827773b4c636f85bfa36a3277b0ee53803a172b5de2c03539522d362ff357e2`
Archive bytes: 2253933

Members: 82; uncompressed bytes: 10440339

| Path | Bytes | Type / counts |
|---|---:|---|
| `Tolmar/` | 0 | file |
| `Tolmar/deliverables/` | 0 | file |
| `Tolmar/deliverables/Tolmar_Job_Postings.xlsx` | 119025 | XLSX; Summary=23 rows, Jobs=60 rows |
| `Tolmar/deliverables/Tolmar_Account_Summary.docx` | 47954 | DOCX; DOCX 25 headings, 14 tables; headings: Heading 1: 1. How to read this file / Heading 1: 2. Narrative, in plain words / Heading 2: The account picture / Heading 2: What stands out / Heading 2: What it likely means for each lane (interpretation) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: 3. Recent news / Heading 1: 4. Company and transformation baseline / Heading 1: 5. Signals / Heading 2: Tier 1: budget proximate / Heading 2: Tier 2: one step removed / Heading 2: Tier 3: context and openers / Heading 2: Context and history (older than 18 months) / Heading 1: 6. Platform picture by lane / Heading 1: 7. People / Heading 2: Key people (priority A, senior) / Heading 2: Findings from profiles / Heading 2: People whose status changed / Heading 1: 8. Hypotheses to test / Heading 1: 9. Questions for a first conversation / Heading 1: 10. Research coverage tracker / Heading 2: Pass 1: summary homework / Heading 2: Pass 2: detailed homework / Heading 1: 11. Source links |
| `Tolmar/deliverables/Tolmar_People_List.xlsx` | 26771 | XLSX; Summary=28 rows, People=120 rows, Former staff seen=6 rows |
| `Tolmar/deliverables/Tolmar_Tech_Stack_and_Teams.xlsx` | 13547 | XLSX; Platform Ranking=20 rows, Confirmed stack=38 rows, About=5 rows, Platform teams=18 rows |
| `Tolmar/deliverables/Tolmar_Sources_and_Evidence.docx` | 70084 | DOCX; DOCX 46 headings, 8 tables; headings: Heading 1: Part A: Source register / Heading 1: Part B: Job posting extracts (postings read in depth) / Heading 2: J1. Salesforce Platform Mgr / Heading 2: J2. AI Engineer I, Hybrid / Heading 2: J3. Manager Electronic Batch Record (EBR), Hybrid / Heading 2: J4. Project Manager IT, (Hybrid) / Heading 2: J5. Sr Financial Analyst, FP&A and Systems / Heading 2: J6. Sr Financial Analyst, FP&A / Heading 2: J7. Senior Accountant / Heading 2: J8. Manager Quality Systems, EDMS, Patient Safety and Change Control (On Site) / Heading 2: J9. Quality Systems Specialist, EDMS (On Site) / Heading 2: J10. Manager Product Launch, Hybrid / Heading 2: J11. MS&T Manufacturing Operations Engineer (Temporary 6 months) Onsite / Heading 2: J12. Sr Quality Automation and CSV Engineer (Onsite) / Heading 2: J13. Associate Director Supply Chain Analytics / Heading 2: J14. Sr Analyst, Compliance / Heading 2: J15. Key Account Manager, Pediatric Endocrinology / Heading 2: J16. Director Corporate Accounts, UroNova / Heading 2: J17. Senior Supervisor Production, Specialty Injectables (3rd Shift) / Heading 2: J18. Strategic Partnerships Director, Ped Endo, Remote / Heading 2: J19. Intern, Distribution & Warehouse/Supply Chain / Heading 2: J21. Marketing Operations Specialist / Heading 2: J22. VP Sales and Marketing, US Oncology/Breast Cancer / Heading 2: J23. Intern, Regulatory Affairs / Heading 2: J24. Intern, EPMO / Heading 1: Part C: Postings read one by one, primary lanes / Heading 1: Part D: Video and article extracts / Heading 2: S13. Adastra video, From 12 Systems to One (2026-03-24) / Heading 2: S14, S15, S16. Jon Steffey at PharmaCon 2026 (Adastra podcast page, full video, AIM Media House article) / Heading 2: S17. Sean Diwan, Becker Private Equity and Business podcast (2026-06-17, personal capacity) / Heading 2: S18, S19. Veeva customer stories (2023) / Heading 2: S4, S5. Alpha Tau collaboration / Heading 2: S22, S23, S24. UroNova / Heading 2: S54 to S58. Internal history (neutral form, no links) / Heading 1: Part E: Job board captures / Heading 1: Part F: Leads not verified / Heading 1: Part G: Keeping copies of the original pages / Heading 1: Part H: Data pulls / Heading 2: H1. Technology detections by lane (S27) / Heading 2: H2. Postings naming a platform, twelve months (S26) / Heading 2: H3. Structured news events, 18 months (S26 feed) / Heading 2: H4. Partner and vendor page connections (S32), lane relevant rows / Heading 2: H5. Platform teams (S28) / Heading 2: H6. Profiles and activity (S29, S30) / Heading 2: H7. Company signal feed (S31) / Heading 1: Part I: Full URLs |
| `Tolmar/notes/` | 0 | file |
| `Tolmar/notes/pass1.md` | 1811 | MD |
| `Tolmar/notes/sense_check.md` | 16480 | MD |
| `Tolmar/RESTORE.md` | 1989 | MD |
| `Tolmar/data/` | 0 | file |
| `Tolmar/data/teams.json` | 51844 | JSON; JSON object, 3 keys; arrays: queries[3] |
| `Tolmar/data/live_board.json` | 20661 | JSON; JSON object, 5 keys; arrays: postings[46], keyword_searches.Salesforce.postings[2], keyword_searches.MuleSoft.postings[0], keyword_searches.ServiceNow.postings[0], keyword_searches.SAP.postings[0], keyword_searches.Tableau.postings[1], keyword_searches.Veeva.postings[1], keyword_searches.Workday.postings[0], keyword_searches.CRM.postings[3], keyword_searches.Power BI.postings[2], keyword_searches.LIMS.postings[4] |
| `Tolmar/data/profile_findings.json` | 9185 | JSON; JSON object, 8 keys; arrays: alumni[36], joined_last_12_months[11], new_role_last_12_months[10], longest[8], certs[15], mentions.Deacom[3], mentions.Veeva[3], mentions.Salesforce[2], mentions.Tableau[1], mentions.LIMS[3], mentions.Electronic batch records[1], mentions.MES[1] |
| `Tolmar/data/ranking_checked.json` | 163 | JSON; JSON array, 12 records |
| `Tolmar/data/stack_names.json` | 605 | JSON; JSON array, 37 records |
| `Tolmar/data/baseline_search.json` | 1916 | JSON; JSON object, 3 keys; arrays: queries[4], results_kept[6] |
| `Tolmar/data/connections.json` | 26888 | JSON; JSON object, 3 keys; arrays: rows[100] |
| `Tolmar/data/gap_check_people.json` | 55685 | JSON; JSON object, 3 keys; arrays: queries[2] |
| `Tolmar/data/urls.json` | 36883 | JSON; JSON object, 2 keys |
| `Tolmar/data/techstack_confirmed.json` | 16178 | JSON; JSON object, 4 keys; arrays: org_resolve.organizations[1], confirmed_stack.business_functions[12], org_signals.signals[0] |
| `Tolmar/data/ids.json` | 606 | JSON; JSON array, 89 records |
| `Tolmar/data/transcripts/` | 0 | file |
| `Tolmar/data/transcripts/youtube_ZJDdZx76eSY_tolmar_fabric_60_days.md` | 3732 | MD |
| `Tolmar/data/transcripts/adastra_jon_steffey_interview.md` | 2356 | MD |
| `Tolmar/data/transcripts/youtube_ALBMIghV06M_steffey_full_interview.md` | 4001 | MD |
| `Tolmar/data/transcripts/youtube__6OsIYhXKvM_sean_diwan_becker.md` | 2307 | MD |
| `Tolmar/data/evidence.txt` | 129262 | TXT |
| `Tolmar/data/techstack_detections.json` | 23459 | JSON; JSON object, 4 keys; arrays: rows[130] |
| `Tolmar/data/web_searches_phase2.json` | 2386 | JSON; JSON object, 3 keys; arrays: searches[5] |
| `Tolmar/data/jobs_keyword_counts.json` | 2897 | JSON; JSON object, 4 keys; arrays: locations_top[15] |
| `Tolmar/data/summary.json` | 70077 | JSON; JSON array, 56 records |
| `Tolmar/data/jobs12.json` | 2791333 | JSON; JSON array, 362 records |
| `Tolmar/data/jobs_classified.json` | 527815 | JSON; JSON array, 59 records |
| `Tolmar/data/releases/` | 0 | file |
| `Tolmar/data/releases/alpha-tau-and-tolmar-announce-strategic-collaboration-to-bring-alpha-dart-therap.md` | 30845 | MD |
| `Tolmar/data/releases/the-pharma-group-enters-into-an-exclusive-promotional-agreement-with-tolmar-inc.md` | 15676 | MD |
| `Tolmar/data/releases/tolmar-launches-care-partner-corner-first-in-class-resource-dedicated-to-prostat.md` | 12077 | MD |
| `Tolmar/data/releases/2026_aim_media_steffey_ai_in_pharma.md` | 2468 | MD |
| `Tolmar/data/releases/delsitech-and-tolmar-announce-global-license-and-development-agreement-302059757.md` | 7605 | MD |
| `Tolmar/data/releases/tolmar-launches-dedicated-youtube-channel-to-empower-advanced-practice-providers.md` | 9554 | MD |
| `Tolmar/data/releases/tolmar-collaborates-with-direct-to-patient-telemedicine-company-upscripthealth-t.md` | 14584 | MD |
| `Tolmar/data/releases/tolmar-announces-expanded-indication-for-rubraca-rucaparib-first-and-only-parp-i.md` | 20695 | MD |
| `Tolmar/data/posts_comments.json` | 775458 | JSON; JSON object, 3 keys; arrays: rows[39] |
| `Tolmar/data/jobs_prior.json` | 957253 | JSON; JSON object, 4 keys; arrays: rows[131] |
| `Tolmar/data/company_pages/` | 0 | file |
| `Tolmar/data/company_pages/treatments.md` | 13175 | MD |
| `Tolmar/data/company_pages/author-eric-rustomji.md` | 1084 | MD |
| `Tolmar/data/company_pages/about-tolmar.md` | 7681 | MD |
| `Tolmar/data/company_pages/technology-commercialization.md` | 3822 | MD |
| `Tolmar/data/company_pages/manufacturing.md` | 3094 | MD |
| `Tolmar/data/company_pages/working-at-tolmar.md` | 10625 | MD |
| `Tolmar/data/company_pages/media.md` | 2682 | MD |
| `Tolmar/data/people_merged.json` | 73470 | JSON; JSON object, 4 keys; arrays: people[119], removed[11], former[5] |
| `Tolmar/data/summary.txt` | 71189 | TXT |
| `Tolmar/data/web_searches.json` | 16344 | JSON; JSON object, 4 keys; arrays: searches[13], step2_lane_vendor_partnership_searches_2026_10_12[7], step2_selects_deploys_modernizes_2026_10_12[1], step3_subsidiary_and_board_searches_2026_10_12[2] |
| `Tolmar/data/ranking_drop.json` | 545 | JSON; JSON array, 3 records |
| `Tolmar/data/jobs_12mo.json` | 2860715 | JSON; JSON object, 4 keys; arrays: rows[362] |
| `Tolmar/data/subsidiary_domains.json` | 1062 | JSON; JSON object, 4 keys; arrays: domains[2], feed_reported_subsidiary_domains[0] |
| `Tolmar/data/newsroom.json` | 3426 | JSON; JSON object, 7 keys; arrays: items[8], site_map_notes[3] |
| `Tolmar/data/people_gapcheck.json` | 4556 | JSON; JSON object, 4 keys; arrays: searches[6] |
| `Tolmar/data/company_record.json` | 450 | JSON; JSON object, 6 keys; arrays: locations[4], subsidiary_companies[0], similar_companies[5] |
| `Tolmar/data/people_second_source.json` | 25943 | JSON; JSON object, 6 keys; arrays: rows[67] |
| `Tolmar/data/people_grid.json` | 61809 | JSON; JSON object, 6 keys; arrays: rows[130] |
| `Tolmar/data/evidence.json` | 145859 | JSON; JSON array, 178 records |
| `Tolmar/data/profiles_full.json` | 935715 | JSON; JSON object, 2 keys; arrays: rows[106] |
| `Tolmar/data/company_record_second_source.json` | 394 | JSON; JSON object, 8 keys; arrays: naics[7] |
| `Tolmar/data/signal_feed_company.json` | 120919 | JSON; JSON object, 5 keys; arrays: company.industries[1], signals[60], coverage.signal_types_available[14] |
| `Tolmar/data/news_events.json` | 2205 | JSON; JSON object, 4 keys; arrays: events[5] |
| `Tolmar/build/` | 0 | file |
| `Tolmar/build/profile_findings.py` | 4058 | PY |
| `Tolmar/build/jobs_classify.py` | 8035 | PY |
| `Tolmar/build/render_docx.js` | 1915 | JS |
| `Tolmar/build/people_merge.py` | 12553 | PY |
| `Tolmar/build/evidence_content.py` | 16857 | PY |
| `Tolmar/build/sources.py` | 21262 | PY |
| `Tolmar/build/workbooks.py` | 15453 | PY |
| `Tolmar/build/redact_check.py` | 905 | PY |
| `Tolmar/build/redact.py` | 1359 | PY |
| `Tolmar/build/summary_content.py` | 43116 | PY |
| `Tolmar/pull_log.md` | 23947 | MD |
