# Inventory: ws

Files: 366; total 186774 KB

Top level: `(root)` (2), `build` (29), `data` (327), `deliverables` (5), `notes` (3)

| Path | Bytes | Content |
|---|---:|---|
| `BD_[redacted]_Only.docx` | 12159 | 13 paras, 3 headings, 0 tables |
| `RESTORE.md` | 3584 | 28 lines |
| `build/build_evidence.js` | 7393 | 68 lines |
| `build/build_jobs.py` | 8364 | 98 lines |
| `build/build_people.py` | 17869 | 147 lines |
| `build/build_[redacted]_only.js` | 3491 | 17 lines |
| `build/build_stack.py` | 4741 | 55 lines |
| `build/build_summary.js` | 13299 | 124 lines |
| `build/checked.json` | 32 | list[3] |
| `build/classify.py` | 2771 | 36 lines |
| `build/classify2.py` | 2287 | 19 lines |
| `build/content.json` | 138276 | dict[27 keys]: run_date,sources,jobs,jobs_counts,ent_counts,lane_rows_bd |
| `build/content.py` | 72180 | 381 lines |
| `build/decisions.py` | 17418 | 93 lines |
| `build/docx_lib.js` | 4575 | 44 lines |
| `build/drop_salesforce.json` | 648 | list[6] |
| `build/evidence_extra.json` | 80430 | dict[6 keys]: extracts,live_lane_count,live_rows,leads,detections,news_events |
| `build/evidence_extra.py` | 27339 | 117 lines |
| `build/ids.json` | 822 | list[120] |
| `build/jobs_all.json` | 48491400 | list[7237] |
| `build/jobs_bd.json` | 42704282 | list[6552] |
| `build/jobs_lane_rows_final.json` | 14720344 | list[1897] |
| `build/lane_rows.json` | 1343528 | list[1587] |
| `build/people_excluded.json` | 16416 | dict[4 keys]: domain,security,unresolved,below_rule_no_stack |
| `build/people_merged.json` | 297657 | list[736] |
| `build/people_named.json` | 3575 | list[11] |
| `build/platform_ranking_bd.py` | 10969 | 184 lines |
| `build/prep_jobs.py` | 3547 | 48 lines |
| `build/profile_findings.json` | 23249 | dict[15 keys]: senior_with_profiles,join_year_hist,tenure_median,joined_2024_or_later,joined_2025_or_later,joined_2026 |
| `build/profile_findings.py` | 7409 | 70 lines |
| `build/stack_names.json` | 2644 | list[188] |
| `data/company_record.json` | 972 | dict[11 keys]: source,domain,company_name,friendly_name,ticker,hq |
| `data/company_searches.json` | 48611 | dict[4 keys]: source,step,searches,paid_page_scrapes_used |
| `data/connections.json` | 355629 | dict[6 keys]: source,query,count_reported,count_saved,note,connections |
| `data/former_exec_checks.json` | 42353 | dict[3 keys]: source,step,checks |
| `data/jobs_12mo.json` | 50486152 | dict[5 keys]: source,query,count_reported,count_saved,jobs |
| `data/leadership.json` | 4447 | dict[8 keys]: source,page,captured,capture_method,executives,board_partial_from_excerpt |
| `data/live_board.json` | 55579 | dict[8 keys]: source,board,boards_found,captured,keywords,it_category |
| `data/news_events.json` | 181154 | dict[5 keys]: source,query,count_reported,count_saved,events |
| `data/org_resolve.json` | 708 | dict[9 keys]: source,match_input,org_id,name,employee_count,headquarters_country |
| `data/org_signals.json` | 11551 | dict[5 keys]: source,organization_id,count,note,signals |
| `data/people_gapcheck.json` | 3367 | dict[4 keys]: source,org_id,params_common,lanes |
| `data/people_grid.txt` | 527859 | 1485 lines |
| `data/people_grid_rows.json` | 826335 | list[1484] |
| `data/person_searches_A.json` | 416677 | dict[5 keys]: source,step,searches,paid_page_scrapes_used,notes |
| `data/person_searches_B.json` | 364961 | dict[4 keys]: source,step,searches,paid_page_scrapes_used |
| `data/posts_comments.json` | 9976550 | dict[7 keys]: source,rule,rows,rows_with_posts,rows_with_comments,note |
| `data/profiles_full.json` | 11193436 | dict[4 keys]: source,rows,profiles_returned,profiles |
| `data/releases/2017-07-31_veeva-9-of-top-15-medtech-move-to-vault.md` | 7491 | 48 lines |
| `data/releases/2023-08-17_servicenow-bd-riseup-story-pdf.md` | 7636 | 220 lines |
| `data/releases/2023-09-07_pwc-bd-ecommerce-transformation.md` | 13791 | 205 lines |
| `data/releases/2025-04-21_bd-launches-next-generation-hemodynamic-monitoring-solution.md` | 11496 | 104 lines |
| `data/releases/2025-04-23_bd-launches-industry-first-bioabsorbable-mesh-designed-for-u.md` | 10084 | 105 lines |
| `data/releases/2025-04-29_bd-board-declares-dividend.md` | 34707 | 453 lines |
| `data/releases/2025-04-30_bd-to-present-at-bank-of-america-securities-health-care-conf.md` | 35084 | 456 lines |
| `data/releases/2025-05-01_bd-reports-second-quarter-fiscal-2025-financial-results.md` | 101825 | 1078 lines |
| `data/releases/2025-05-12_bd-to-announce-financial-results-for-its-third-quarter-of-fi.md` | 7911 | 91 lines |
| `data/releases/2025-05-13_bd-launches-landmark-cell-analyzer-featuring-breakthrough-sp.md` | 11570 | 105 lines |
| `data/releases/2025-05-21_cancer-patients-face-elevated-risk-of-carrying-antimicrobial.md` | 11936 | 111 lines |
| `data/releases/2025-05-27_bd-to-present-at-goldman-sachs-46th-annual-global-healthcare.md` | 7553 | 89 lines |
| `data/releases/2025-05-28_bd-to-initiate-real-world-patient-data-registry-for-the-rota.md` | 38094 | 470 lines |
| `data/releases/2025-07-07_bd-appoints-bilal-muhsin-as-executive-vice-president-and-pre.md` | 10351 | 98 lines |
| `data/releases/2025-07-14_waters-and-bds-biosciences-diagnostic-solutions-business-to.md` | 34397 | 222 lines |
| `data/releases/2025-07-22_bd-board-declares-dividend.md` | 7122 | 86 lines |
| `data/releases/2025-07-23_bd-announces-first-pharma-sponsored-clinical-trial-using-bd.md` | 12178 | 112 lines |
| `data/releases/2025-07-30_bd-receives-fda-510k-clearance-for-rapid-point-of-care-covid.md` | 9201 | 113 lines |
| `data/releases/2025-07-31_bd-aims-to-save-lives-by-empowering-women-with-choice-and-ac.md` | 38933 | 471 lines |
| `data/releases/2025-08-04_bd-to-invest-35-million-in-nebraska-facility-to-expand-prefi.md` | 10849 | 101 lines |
| `data/releases/2025-08-04_bd-to-invest-35-million-in-nebraska-facility-to-expand-prefi_2.md` | 9584 | 108 lines |
| `data/releases/2025-08-04_bd-to-invest-35-million-in-nebraska-facility-to-expand-prefi_3.md` | 8703 | 83 lines |
| `data/releases/2025-08-05_bd-businesses-become-first-in-medtech-to-achieve-hircs-diamo.md` | 8072 | 101 lines |
| `data/releases/2025-08-07_bd-reports-third-quarter-fiscal-2025-financial-results.md` | 78235 | 778 lines |
| `data/releases/2025-08-14_bd-to-present-at-wells-fargo-2025-healthcare-conference.md` | 4428 | 49 lines |
| `data/releases/2025-08-21_bd-advanced-patient-monitoring-hosts-inaugural-patient-day-t.md` | 7288 | 75 lines |
| `data/releases/2025-09-02_bd-expands-peripheral-artery-disease-awareness-efforts-with-.md` | 11112 | 112 lines |
| `data/releases/2025-09-12_bd-provides-update-on-voluntary-recall-of-certain-bd-alaris-.md` | 7369 | 71 lines |
| `data/releases/2025-09-17_bd-marks-1,000th-bd-rhapsody-system,-driving-scientific-brea.md` | 9181 | 111 lines |
| `data/releases/2025-09-22_bd-and-henry-ford-health-sign-pharmacy-automation-partnershi.md` | 9397 | 121 lines |
| `data/releases/2025-10-03_bd-celebrates-55-years-of-manufacturing-excellence-and-impac.md` | 9597 | 94 lines |
| `data/releases/2025-10-08_bd-and-opentrons-collaborate-to-accelerate-single-cell-multi.md` | 9006 | 91 lines |
| `data/releases/2025-10-08_the-bd-in-celebration-of-her-tm-program-surpasses-1-million-.md` | 7578 | 85 lines |
| `data/releases/2025-10-09_bd-reaches-major-milestone-for-rotarex-tm-catheter-system-wi.md` | 10240 | 113 lines |
| `data/releases/2025-10-09_bd-to-announce-financial-results-for-its-fourth-quarter-and-.md` | 5255 | 45 lines |
| `data/releases/2025-10-15_bd-announces-cfo-transition-plan.md` | 22616 | 124 lines |
| `data/releases/2025-10-16_bd-looks-ahead-to-the-next-era-of-manufacturing-excellence-i.md` | 10341 | 98 lines |
| `data/releases/2025-10-20_bd-launches-new-ai-enabled-solutions-connectivity.md` | 8083 | 73 lines |
| `data/releases/2025-10-20_bd-launches-new-ai-enabled-solutions-to-drive-connectivity-a.md` | 9295 | 116 lines |
| `data/releases/2025-10-22_bd-simplifies-at-home-hpv-testing-to-broaden-access-to-cervi.md` | 7457 | 68 lines |
| `data/releases/2025-11-03_bd-receives-fda-510-k-clearance-and-ce-ivdr-certification-fo.md` | 10337 | 97 lines |
| `data/releases/2025-11-04_bd-achieves-milestone-in-agility-study-of-revello-tm-vascula.md` | 8607 | 97 lines |
| `data/releases/2025-11-06_bd-board-increases-dividend-for-54th-consecutive-year.md` | 4747 | 47 lines |
| `data/releases/2025-11-06_bd-reports-fourth-quarter-and-full-year-fiscal-2025-financia.md` | 73279 | 734 lines |
| `data/releases/2025-11-06_transcript-bd-q4-fy2025-earnings-call.md` | 57190 | 204 lines |
| `data/releases/2025-11-12_bd-expands-purewick-tm-portfolio-with-first-of-its-kind-port.md` | 9315 | 114 lines |
| `data/releases/2025-11-13_duncan-regional-hospital-becomes-first-in-u-s-to-implement-b.md` | 14500 | 115 lines |
| `data/releases/2025-11-17_bd-appoints-robert-huffines-and-jacqueline-wright-to-board-o.md` | 9607 | 121 lines |
| `data/releases/2025-11-17_bd-onclarity-tm-hpv-assay-for-bd-cor-tm-and-bd-viper-tm-lt-s.md` | 9981 | 107 lines |
| `data/releases/2025-11-18_icn-and-bd-foundation-empower-nursing-leadership-across-lati.md` | 7976 | 99 lines |
| `data/releases/2025-11-20_bd,-nafc-and-medshare-expand-health-access,-bring-critical-u.md` | 11253 | 116 lines |
| `data/releases/2025-11-24_bd-surgiphor-tm-surgical-wound-irrigation-system-expands-to-.md` | 7743 | 111 lines |
| `data/releases/2025-11-25_bd-form-10-k-fy2025-item-1-business.md` | 50597 | 282 lines |
| `data/releases/2025-12-03_bd-launches-new-cell-analyzer-configurations-to-bring-cuttin.md` | 8997 | 106 lines |
| `data/releases/2025-12-04_bd-and-chemoglo-tm-collaborate-to-expand-hazardous-drug-cont.md` | 10589 | 119 lines |
| `data/releases/2025-12-08_bd-showcases-innovation-in-connected-medication-management-a.md` | 8015 | 95 lines |
| `data/releases/2025-12-15_bd-expands-bd-max-tm-system-menu-with-new-ivdr-certified-via.md` | 9329 | 112 lines |
| `data/releases/2025-12-18_bd-and-penn-institute-for-immunology-and-immune-health-colla.md` | 9203 | 96 lines |
| `data/releases/2026-01-05_bd-marks-milestone-with-first-phasix-tm-hernia-prevention-ca.md` | 8367 | 87 lines |
| `data/releases/2026-01-12_bd-to-host-virtual-2026-annual-meeting-of-shareholders.md` | 5072 | 49 lines |
| `data/releases/2026-01-13_bd-announces-110-million-to-support-u-s-pharmaceutical-suppl.md` | 10434 | 115 lines |
| `data/releases/2026-01-14_bd-names-shawn-bevec-as-senior-vice-president-of-investor-re.md` | 6954 | 101 lines |
| `data/releases/2026-01-15_bd-receives-fda-510-k-clearance-for-encor-encompass-tm-breas.md` | 10243 | 112 lines |
| `data/releases/2026-01-19_bd-to-highlight-advanced-biologics-and-large-volume-delivery.md` | 11658 | 155 lines |
| `data/releases/2026-01-21_bd-and-ypsomed-expand-partnership-to-address-rapidly-growing.md` | 11100 | 147 lines |
| `data/releases/2026-01-23_bd-helps-scientists-advance-immunology-and-cancer-research-w.md` | 8435 | 107 lines |
| `data/releases/2026-01-27_bd-announces-record-date-for-the-spin-off-of-its-biosciences.md` | 15916 | 73 lines |
| `data/releases/2026-01-27_bd-board-declares-dividend,-authorizes-10-million-additional.md` | 5594 | 48 lines |
| `data/releases/2026-01-27_bd-to-announce-financial-results-for-its-first-quarter-of-fi.md` | 5209 | 47 lines |
| `data/releases/2026-01-29_bd-and-envetec-demonstrate-closed-loop-recycling-solution-fo.md` | 7899 | 73 lines |
| `data/releases/2026-02-04_bd-extends-leadership-in-connected-medication-management-win.md` | 6856 | 62 lines |
| `data/releases/2026-02-09_bd-completes-combination-of-biosciences-diagnostic-solutions.md` | 9412 | 75 lines |
| `data/releases/2026-02-09_bd-reports-first-quarter-fiscal-2026-financial-results.md` | 46307 | 433 lines |
| `data/releases/2026-02-09_transcript-bd-q1-fy2026-earnings-call.md` | 55161 | 480 lines |
| `data/releases/2026-02-10_becton,-dickinson-and-company-announces-tender-offers-for-ou.md` | 15399 | 99 lines |
| `data/releases/2026-02-19_lanesha-minnix-named-general-counsel-for-bd.md` | 5957 | 97 lines |
| `data/releases/2026-02-23_bd-expands-testing-capabilities-to-help-clinicians-improve-d.md` | 8116 | 97 lines |
| `data/releases/2026-02-23_bd-to-present-at-barclays-28th-annual-global-healthcare-conf.md` | 4219 | 45 lines |
| `data/releases/2026-02-25_becton,-dickinson-and-company-announces-early-tender-results.md` | 15738 | 94 lines |
| `data/releases/2026-02-25_becton,-dickinson-and-company-announces-pricing-of-the-tende.md` | 14933 | 90 lines |
| `data/releases/2026-03-02_bd-pioneers-new-standard-in-surgical-safety-with-fda-cleared.md` | 7150 | 68 lines |
| `data/releases/2026-03-05_bd-advances-iliac-artery-treatment-across-the-european-union.md` | 7858 | 70 lines |
| `data/releases/2026-03-06_bd-named-a-top-100-global-innovator-by-lexisnexis.md` | 6950 | 71 lines |
| `data/releases/2026-03-11_bd-and-sinteco-expand-advanced-robotics-offering-to-streamli.md` | 8397 | 89 lines |
| `data/releases/2026-04-01_bd-launches-ai-enabled-medication-dispensing-system-to-the-e.md` | 8544 | 97 lines |
| `data/releases/2026-04-07_when-every-beat-matters,-bd-helps-clinicians-eliminate-blind.md` | 9605 | 111 lines |
| `data/releases/2026-04-08_bd-delivers-next-generation-tips-innovation-to-advance-porta.md` | 9152 | 95 lines |
| `data/releases/2026-04-09_bd-to-announce-financial-results-for-its-second-quarter-of-f.md` | 4756 | 43 lines |
| `data/releases/2026-04-09_for-women-managing-nighttime-incontinence,-better-sleep-and-.md` | 9674 | 117 lines |
| `data/releases/2026-04-09_rick-byrd-to-retire-from-bd.md` | 5325 | 53 lines |
| `data/releases/2026-04-16_bd-earns-industry-top-honors-for-transparency,-resiliency-an.md` | 6374 | 57 lines |
| `data/releases/2026-04-24_capgemini-bd-client-story-pdf.md` | 7821 | 112 lines |
| `data/releases/2026-04-27_bd-and-suttons-creek-partner-to-help-pharma-and-biotech-comp.md` | 9978 | 110 lines |
| `data/releases/2026-04-27_bd-to-present-at-bank-of-america-securities-health-care-conf.md` | 4227 | 45 lines |
| `data/releases/2026-04-27_capgemini-bd-global-integration-landscape.md` | 23787 | 323 lines |
| `data/releases/2026-04-28_bd-board-declares-dividend.md` | 3668 | 46 lines |
| `data/releases/2026-04-29_bd-reimagines-central-line-insertion,-advancing-leadership-i.md` | 11481 | 170 lines |
| `data/releases/2026-04-30_bd-achieves-excellence-in-employee-well-being,-earning-top-i.md` | 7331 | 57 lines |
| `data/releases/2026-05-05_bd-and-wellstar-advance-patient-care-and-safety-with-medicat.md` | 9537 | 94 lines |
| `data/releases/2026-05-07_bd-appoints-vitor-roque-chief-financial-officer.md` | 6439 | 53 lines |
| `data/releases/2026-05-07_bd-reports-second-quarter-fiscal-2026-financial-results.md` | 57373 | 452 lines |
| `data/releases/2026-05-07_transcript-bd-q2-fy2026-earnings-call.md` | 65786 | 354 lines |
| `data/releases/2026-05-18_peter-menziuso-named-evp-and-president,-bd-interventional.md` | 6147 | 81 lines |
| `data/releases/2026-05-21_bd-delivers-kidney-stone-care-for-urology-teams-with-the-ely.md` | 8386 | 113 lines |
| `data/releases/2026-06-23_bd-awarded-another-program-account-innovative-technology-contract-for-centro.md` | 9235 | 91 lines |
| `data/releases/2026-07-01_bd-appoints-matthew-sassone-as-worldwide-president-of-pharma.md` | 5709 | 79 lines |
| `data/releases/2026-07-09_bd-named-to-times-2026-list-of-americas-best-companies.md` | 5294 | 63 lines |
| `data/releases/2026-07-09_bd-to-announce-financial-results-for-its-third-quarter-of-fi.md` | 4754 | 43 lines |
| `data/releases/2026-07-22_mike-garrison-to-retire-from-bd.md` | 5411 | 53 lines |
| `data/releases/2026-07-28_bd-board-declares-dividend.md` | 3672 | 44 lines |
| `data/releases/2026-07-29_ems-and-bd-expand-access-to-glp-1-therapies-in-brazil-with-s.md` | 6968 | 89 lines |
| `data/releases/2026-07-31_bd-issues-nationwide-recall-for-specific-lots-of-bd-r-intrao.md` | 7863 | 86 lines |
| `data/releases/2026-08-06_bd-reports-third-quarter-fiscal-2026-financial-results.md` | 56276 | 452 lines |
| `data/releases/2026-08-06_transcript-bd-q3-fy2026-earnings-call.md` | 73787 | 923 lines |
| `data/releases/2026-08-12_bd-accelerates-advanced-tissue-regeneration-strategy-with-la.md` | 6935 | 103 lines |
| `data/releases/2026-08-17_bd-appoints-gary-sorsher-as-chief-quality-officer-jeff-silve.md` | 6511 | 99 lines |
| `data/releases/2026-08-26_bd-to-present-at-wells-fargo-21st-annual-healthcare-conferen.md` | 4198 | 45 lines |
| `data/releases/2026-08-27_bd-extends-leadership-in-advanced-tissue-regeneration-throug.md` | 10485 | 102 lines |
| `data/releases/2026-09-10_bd-celebrates-30-years-of-innovation-and-shared-prosperity-i.md` | 7200 | 61 lines |
| `data/releases/2026-09-14_bd-advances-intelligent-robotics-to-transform-the-future-of-.md` | 9716 | 112 lines |
| `data/releases/2026-09-21_arthur-hu-to-join-bd-as-chief-information-and-digital-office.md` | 6812 | 99 lines |
| `data/releases/2026-09-29_bd-celebrates-70-years-of-manufacturing,-innovation-and-comm.md` | 8538 | 90 lines |
| `data/releases/2026-10-06_bd-and-u-s-government-launch-landmark-partnership-to-expand-.md` | 12062 | 124 lines |
| `data/releases/2026-10-06_bd-appoints-ferass-abuzaina-as-worldwide-president-of-surger.md` | 5982 | 83 lines |
| `data/releases/2026-10-06_bd-celebrates-65-years-of-manufacturing,-innovation-and-comm.md` | 10327 | 155 lines |
| `data/releases/2026-10-07_bd-strengthens-leadership-in-peripheral-vascular-innovation-.md` | 9457 | 98 lines |
| `data/releases/2026-10-08_bd-and-global-health-leaders-call-for-accelerated-maternal-l.md` | 9856 | 117 lines |
| `data/releases/2026-10-08_bd-to-announce-financial-results-for-its-fourth-quarter-and-.md` | 4852 | 45 lines |
| `data/releases/2026-10-19_live_100012216144_termelesi-biokemikus-konjugacio.md` | 14936 | 329 lines |
| `data/releases/2026-10-19_live_100110267872_sr-international-specialist.md` | 13967 | 271 lines |
| `data/releases/2026-10-19_live_100158166656_hypo-north-production-assoicate.md` | 14981 | 426 lines |
| `data/releases/2026-10-19_live_100356942192_senior-customer-service-rep.md` | 15968 | 385 lines |
| `data/releases/2026-10-19_live_100378013488_molding-electro-mechanical-technician-a-shift.md` | 14711 | 401 lines |
| `data/releases/2026-10-19_live_100432595600_procedural-specialist.md` | 17394 | 386 lines |
| `data/releases/2026-10-19_live_100617062992_bd-2027-summer-internship-supply-chain-development.md` | 19485 | 383 lines |
| `data/releases/2026-10-19_live_100628874432_material-handler-iii.md` | 18395 | 487 lines |
| `data/releases/2026-10-19_live_100628877088_field-service-engineer-colorado-springs-co.md` | 11366 | 249 lines |
| `data/releases/2026-10-19_live_100723630112_marketing-operations-associate-mms.md` | 17618 | 344 lines |
| `data/releases/2026-10-19_live_100758736896_cost-accounting-manager.md` | 14529 | 341 lines |
| `data/releases/2026-10-19_live_100773937760_field-service-technician-field-based-northern-va-d.md` | 15860 | 275 lines |
| `data/releases/2026-10-19_live_100939541456_consultant-en-deploiement-bilingue-bilingual-deplo.md` | 20886 | 307 lines |
| `data/releases/2026-10-19_live_100950639552_deployment-consultant-infusion-on-qc.md` | 17697 | 295 lines |
| `data/releases/2026-10-19_live_100950652576_field-service-engineer-tampa-fl.md` | 14638 | 270 lines |
| `data/releases/2026-10-19_live_100950654096_senior-project-manager-bc-al-on-based.md` | 16568 | 326 lines |
| `data/releases/2026-10-19_live_101043132128_tecnico-de-produccion.md` | 13841 | 350 lines |
| `data/releases/2026-10-19_live_101090623264_set-up-operator.md` | 14020 | 358 lines |
| `data/releases/2026-10-19_live_101090623472_quality-engineer-1-year.md` | 10052 | 232 lines |
| `data/releases/2026-10-19_live_101090623600_quality-control-representative-d-shift.md` | 11823 | 274 lines |
| `data/releases/2026-10-19_live_101137440784_senior-manager-global-marketing-communications-spe.md` | 16188 | 349 lines |
| `data/releases/2026-10-19_live_101319798832_senior-reconciliation-specialist.md` | 13367 | 318 lines |
| `data/releases/2026-10-19_live_101319802192_supply-chain-production-planner.md` | 13354 | 342 lines |
| `data/releases/2026-10-19_live_101362059872_senior-international-regulatory-affairs-specialist.md` | 16083 | 375 lines |
| `data/releases/2026-10-19_live_101405713248_procurement-manager.md` | 17034 | 372 lines |
| `data/releases/2026-10-19_live_101405713264_principal-indirect-sourcing-manager.md` | 16387 | 363 lines |
| `data/releases/2026-10-19_live_101453743088_quality-associate-scientist.md` | 12577 | 237 lines |
| `data/releases/2026-10-19_live_101561238720_senior-isc-data-scientist.md` | 12179 | 364 lines |
| `data/releases/2026-10-19_live_101565944752_analista-fiscal-sr.md` | 11721 | 311 lines |
| `data/releases/2026-10-19_live_101565945264_analista-fiscal-pl.md` | 12330 | 317 lines |
| `data/releases/2026-10-19_live_101565948912_senior-manager-marketing-and-commercial-operations.md` | 17453 | 325 lines |
| `data/releases/2026-10-19_live_101565949216_business-development-manager-beyond-hospital-care-.md` | 15183 | 347 lines |
| `data/releases/2026-10-19_live_101575435744_field-service-technician.md` | 10444 | 229 lines |
| `data/releases/2026-10-19_live_101610557488_production-associate.md` | 11537 | 307 lines |
| `data/releases/2026-10-19_live_101610557504_production-associate.md` | 11484 | 305 lines |
| `data/releases/2026-10-19_live_101610557520_production-associate.md` | 10836 | 290 lines |
| `data/releases/2026-10-19_live_101619706688_analista-planej-producao-pl.md` | 11624 | 318 lines |
| `data/releases/2026-10-19_live_101619708608_clinical-specialist-atlanta-ga.md` | 15016 | 253 lines |
| `data/releases/2026-10-19_live_101619711056_especialista-processos-industriais-pl.md` | 12447 | 291 lines |
| `data/releases/2026-10-19_live_101619714128_acheteur-bilingue-contrat-12-mois.md` | 17149 | 359 lines |
| `data/releases/2026-10-19_live_101619715472_lider-tecnico-manutencao.md` | 12047 | 293 lines |
| `data/releases/2026-10-19_live_101619715552_regional-director-sales-apm.md` | 13410 | 328 lines |
| `data/releases/2026-10-19_live_101663218736_analyst-2-customer-contract-administration.md` | 12277 | 231 lines |
| `data/releases/2026-10-19_live_101705939328_territory-manager-non-acute-remote-canada.md` | 18047 | 364 lines |
| `data/releases/2026-10-19_live_101705943328_operator-technician.md` | 14558 | 360 lines |
| `data/releases/2026-10-19_live_101709231408_ingeniero-de-automatizacion-sr.md` | 13875 | 316 lines |
| `data/releases/2026-10-19_live_101748630192_hr-service-delivery-operations-specialist.md` | 17527 | 349 lines |
| `data/releases/2026-10-19_live_101748636336_associate-director-trade-compliance.md` | 19285 | 455 lines |
| `data/releases/2026-10-19_live_101748636752_gerente-de-ventas.md` | 15216 | 331 lines |
| `data/releases/2026-10-19_live_101751812704_hypo-north-production-associate.md` | 14588 | 385 lines |
| `data/releases/2026-10-19_live_101899736768_area-sales-manager.md` | 13403 | 345 lines |
| `data/releases/2026-10-19_live_101916544720_auxiliar-administrativo-de-almacen.md` | 12652 | 312 lines |
| `data/releases/2026-10-19_live_101933769088_hypo-north-production-associate-3rd-shift.md` | 15220 | 375 lines |
| `data/releases/2026-10-19_live_101955697504_clinical-specialist-oncology-and-infusion-care-cha.md` | 18151 | 373 lines |
| `data/releases/2026-10-19_live_102041053296_planeador-comprador.md` | 12599 | 304 lines |
| `data/releases/2026-10-19_live_102041057520_account-manager-sm-luzon.md` | 15074 | 332 lines |
| `data/releases/2026-10-19_live_102041057888_tecnico-de-produccion.md` | 13792 | 350 lines |
| `data/releases/2026-10-19_live_102041059472_territory-manager-research-academia.md` | 16570 | 340 lines |
| `data/releases/2026-10-19_live_102041060576_molding-technician-i.md` | 14111 | 317 lines |
| `data/releases/2026-10-19_live_102168814544_asistente-de-contabilidad.md` | 12689 | 316 lines |
| `data/releases/2026-10-19_live_102168821504_customer-service-representative-18-month-fixed-ter.md` | 14698 | 321 lines |
| `data/releases/2026-10-19_live_102168823456_customer-service-representative.md` | 14507 | 320 lines |
| `data/releases/2026-10-19_live_102168826656_technical-support-specialist-2.md` | 15421 | 305 lines |
| `data/releases/2026-10-19_live_102168830320_warehouse-operator.md` | 11628 | 314 lines |
| `data/releases/2026-10-19_live_102168830352_warehouse-operator.md` | 11627 | 315 lines |
| `data/releases/2026-10-19_live_102168830368_warehouse-operator.md` | 11626 | 314 lines |
| `data/releases/2026-10-19_live_102168830720_territory-manager-breast-and-plastic-surgery-south.md` | 16185 | 351 lines |
| `data/releases/2026-10-19_live_47696043392_senior-specialist-sap-plm.md` | 11419 | 283 lines |
| `data/releases/2026-10-19_live_82761017392_manager-or-senior-analyst-fp-and-a.md` | 12454 | 346 lines |
| `data/releases/2026-10-19_live_94317252704_business-planning-and-analysis-bp-and-a-global-fin.md` | 12784 | 320 lines |
| `data/releases/2026-10-19_live_94732473504_financial-analyst.md` | 17154 | 337 lines |
| `data/releases/2026-10-19_live_95939905600_associate-director-global-supply-planning.md` | 19579 | 461 lines |
| `data/releases/2026-10-19_live_96217644336_director-marketing-data-and-analytics.md` | 25205 | 573 lines |
| `data/releases/2026-10-19_live_96589556448_tender-and-contract-specialist-gsa-m-f-d.md` | 10434 | 247 lines |
| `data/releases/2026-10-19_live_97925230784_process-engineer.md` | 14976 | 422 lines |
| `data/releases/2026-10-19_live_98122382976_assistant-manager-business-analytics.md` | 16855 | 366 lines |
| `data/releases/2026-10-19_live_98126988448_controls-specialist.md` | 18873 | 546 lines |
| `data/releases/2026-10-19_live_98574172320_product-lifecycle-engineer.md` | 17599 | 484 lines |
| `data/releases/2026-10-19_live_98693287136_financial-reporting-senior-accountant.md` | 16646 | 348 lines |
| `data/releases/2026-10-19_live_98693287184_financial-reporting-accountant.md` | 16067 | 345 lines |
| `data/releases/2026-10-19_live_98708250736_staff-devops-engineer-salesforce.md` | 18522 | 406 lines |
| `data/releases/2026-10-19_live_98708253712_hypo-north-production-associate-d-shift.md` | 14539 | 391 lines |
| `data/releases/2026-10-19_live_98754724432_single-cell-multiomics-sales-specialist-us-south-c.md` | 18482 | 372 lines |
| `data/releases/2026-10-19_live_98833518016_laboratoriumi-technikus.md` | 14535 | 340 lines |
| `data/releases/2026-10-19_live_99110440304_accounts-receivable-service-delivery-lead.md` | 16398 | 356 lines |
| `data/releases/2026-10-19_live_99376909232_manufacturing-maintenance-technician.md` | 14830 | 343 lines |
| `data/releases/2026-10-19_live_99677188816_lead-qa-engineer.md` | 17528 | 370 lines |
| `data/releases/2026-10-19_live_99721418128_account-manager-md-and-northern-va.md` | 19729 | 506 lines |
| `data/releases/2026-10-19_live_99762872208_maintenance-technician-ii.md` | 16827 | 402 lines |
| `data/releases/2026-10-19_live_99784696128_lead-design-engineer.md` | 20343 | 393 lines |
| `data/releases/2026-10-19_live_99855913136_point-of-care-specialist-respiratory-sales.md` | 19935 | 579 lines |
| `data/releases/2026-10-19_live_99855919504_lead-tech-mechanical-engineer.md` | 14952 | 393 lines |
| `data/releases/person_alex-armbruster_forma-revops-sales-comp-planning-panel.md` | 23887 | 438 lines |
| `data/releases/person_alex-armbruster_forma-sales-incentive-planning-webinar.md` | 9107 | 261 lines |
| `data/releases/person_bilal-muhsin_fierce-ai-healthcare.md` | 23319 | 183 lines |
| `data/releases/person_bilal-muhsin_gulf-business-interview.md` | 11065 | 79 lines |
| `data/releases/person_bilal-muhsin_healthcaredive-qa.md` | 8501 | 79 lines |
| `data/releases/person_bilal-muhsin_hospitals-magazine-gcc.md` | 13884 | 69 lines |
| `data/releases/person_bilal-muhsin_hospitalsmagazine-interview.md` | 8860 | 53 lines |
| `data/releases/person_bilal-muhsin_newsweek-interview.md` | 29556 | 264 lines |
| `data/releases/person_carla-calizaire_home-page.md` | 1593 | 35 lines |
| `data/releases/person_carla-calizaire_speaking-engagements.md` | 4981 | 146 lines |
| `data/releases/person_deepak-jain_industry-magnates-interview.md` | 25951 | 731 lines |
| `data/releases/person_denise-russell-fleming_apple-podcasts-au.md` | 13419 | 308 lines |
| `data/releases/person_denise-russell-fleming_apple-podcasts-zh.md` | 13326 | 304 lines |
| `data/releases/person_denise-russell-fleming_bd-cybersecurity-awareness.md` | 6132 | 60 lines |
| `data/releases/person_denise-russell-fleming_cio-com-interview.md` | 13485 | 67 lines |
| `data/releases/person_denise-russell-fleming_podscan-tech-whisperers.md` | 15522 | 265 lines |
| `data/releases/person_denise-russell-fleming_youtube-tech-whisperers.md` | 52216 | 1378 lines |
| `data/releases/person_diether-recktenwald_lehigh-particles-workshop-talk.md` | 5827 | 72 lines |
| `data/releases/person_diether-recktenwald_smithsonian-cell-sorter-videohistory.md` | 30345 | 330 lines |
| `data/releases/person_elizabeth-mccombs_apple-podcasts-the-beat.md` | 13534 | 299 lines |
| `data/releases/person_elizabeth-mccombs_devicetalks-boston-speaker.md` | 3765 | 91 lines |
| `data/releases/person_elizabeth-mccombs_devicetalks-castos-cto-episode.md` | 3807 | 79 lines |
| `data/releases/person_elizabeth-mccombs_devicetalks-keynote.md` | 1078 | 23 lines |
| `data/releases/person_frederique-pedretti-abel_bd-contamination-control-interview.md` | 19649 | 538 lines |
| `data/releases/person_frederique-pedretti-abel_elemed-podcast.md` | 1723 | 27 lines |
| `data/releases/person_frederique-pedretti-abel_european-medical-device-summit-2024.md` | 22145 | 907 lines |
| `data/releases/person_giorgio-benigni_aboutpharma-in-buone-mani-podcast.md` | 16980 | 217 lines |
| `data/releases/person_giorgio-benigni_meetingrimini-panel-video.md` | 47289 | 1361 lines |
| `data/releases/person_giorgio-benigni_spotify-ecosistema-della-salute.md` | 21350 | 314 lines |
| `data/releases/person_giorgio-benigni_youtube-lean-healthcare-award.md` | 1348 | 46 lines |
| `data/releases/person_greg-lusardi_antec-2018-molding-panel.md` | 8320 | 205 lines |
| `data/releases/person_hermes-vallejo_zeno-tech-whisperers-episode.md` | 2369 | 39 lines |
| `data/releases/person_jeff-stevens_utahbusiness-needle-free.md` | 7009 | 71 lines |
| `data/releases/person_jim-sullivan_sapinsider-author.md` | 17929 | 502 lines |
| `data/releases/person_kathryn-kelly-mba-ms_ted-talk.md` | 3023 | 67 lines |
| `data/releases/person_manish-sinha_hcli-local-to-global-leader.md` | 2295 | 56 lines |
| `data/releases/person_miguel-crespo_hitec-ai-role-of-ciso-panel.md` | 44497 | 1156 lines |
| `data/releases/person_miguel-crespo_sinet-new-york-2024-speakers.md` | 6060 | 383 lines |
| `data/releases/person_miguel-crespo_sinet-ny-speaker-post.md` | 699 | 20 lines |
| `data/releases/person_mike-roby_leading-with-balanced-positivity.md` | 3466 | 33 lines |
| `data/releases/person_mike-roby_michaelroby-speaking-page.md` | 4738 | 103 lines |
| `data/releases/person_nimi-ocholi_bd-blog-simpler-smarter-secure-care.md` | 2653 | 43 lines |
| `data/releases/person_nimi-ocholi_bd-chime-cyber-webinar-part1.md` | 7991 | 81 lines |
| `data/releases/person_nimi-ocholi_bd-chime-cyber-webinar-part2.md` | 5681 | 73 lines |
| `data/releases/person_nimi-ocholi_medical-device-developments-2024-cyber-feature.md` | 19338 | 151 lines |
| `data/releases/person_paula-pizzi_boldjourney-interview.md` | 6871 | 66 lines |
| `data/releases/person_pavan-mocherla_ceo-magazine-interview.md` | 6423 | 57 lines |
| `data/releases/person_pavan-mocherla_ceo-magazine-listing.md` | 11007 | 163 lines |
| `data/releases/person_pavan-mocherla_schoolofhr-ceo-dialogue.md` | 28473 | 585 lines |
| `data/releases/person_pavan-mocherla_youtube-vgsom.md` | 7475 | 119 lines |
| `data/releases/person_roland-goette_pharmaboardroom-interview.md` | 11492 | 61 lines |
| `data/releases/person_roland-goette_youtube-join-bd.md` | 2471 | 84 lines |
| `data/releases/person_sandeep-arora_retailcioconnect-speaker.md` | 1038 | 34 lines |
| `data/releases/person_sandeep-arora_ssow-autumn-speaker.md` | 2035 | 36 lines |
| `data/releases/person_saurabh-patel_digital-marketing-asia-speaker.md` | 1559 | 25 lines |
| `data/releases/person_sunil-agarwal_rd-dynamics-mro-xpo-interview.md` | 6263 | 166 lines |
| `data/releases/person_tamer-elsockary_mlo-qa.md` | 6569 | 35 lines |
| `data/releases/person_todd-dieckhoner_acuitymd-platform.md` | 5268 | 92 lines |
| `data/releases/person_todd-dieckhoner_acuitymd-talk-to-an-expert.md` | 2673 | 63 lines |
| `data/releases/person_todd-dieckhoner_businesswire-acuitymd.md` | 12074 | 130 lines |
| `data/releases/person_todd-dieckhoner_medline-syringes.md` | 8076 | 127 lines |
| `data/releases/person_tom-polen_bd-devicetalks-keynote.md` | 2985 | 38 lines |
| `data/releases/person_tom-polen_bd-devicetalks-podcast.md` | 2301 | 36 lines |
| `data/releases/person_tom-polen_citeline-true-north-podcast.md` | 11212 | 143 lines |
| `data/releases/person_tom-polen_devicetalks-boston-keynote-blog.md` | 10013 | 144 lines |
| `data/releases/person_tom-polen_devicetalks-castos-boston-keynote.md` | 4185 | 81 lines |
| `data/releases/person_tom-polen_devicetalks-growth-episode.md` | 1562 | 21 lines |
| `data/releases/person_tom-polen_youtube-medtech-pov.md` | 45127 | 1189 lines |
| `data/releases/person_vitor-roque_yahoo-q2-fy2026-call.md` | 2434 | 39 lines |
| `data/releases/undated_bd-job-sr-software-engineering-manager-salesforce.md` | 18583 | 263 lines |
| `data/releases/undated_sap-bd-customer-story-video.md` | 2442 | 33 lines |
| `data/releases/undated_servicenow-bd-riseup-customer-page.md` | 34849 | 421 lines |
| `data/releases/undated_veeva-bd-clinical-trials-customer-story.md` | 3293 | 69 lines |
| `data/releases/web_asug-sap-commerce-cloud.md` | 12028 | 85 lines |
| `data/releases/web_capgemini-mulesoft-integration.md` | 6487 | 79 lines |
| `data/releases/web_pwc-salesforce-purewick-ecommerce.md` | 4305 | 57 lines |
| `data/releases/web_servicenow-bd-riseup.md` | 7100 | 83 lines |
| `data/releases/web_veeva-clinical-etmf-ctms.md` | 754 | 25 lines |
| `data/releases/web_veeva-promomats-claims.md` | 548 | 15 lines |
| `data/releases/web_yt-connected-intelligence-beth-mccombs.md` | 19960 | 523 lines |
| `data/releases/web_yt-quip-one-bd-account-team.md` | 3256 | 78 lines |
| `data/releases/web_yt-servicenow-university-trish-johnson.md` | 2313 | 66 lines |
| `data/releases_gap_2025.json` | 7239 | dict[3 keys]: source,listing_pages,releases |
| `data/site_map_news.txt` | 20809 | 159 lines |
| `data/subsidiary_domains.json` | 278342 | dict[3 keys]: source,note,domains |
| `data/teams.json` | 314007 | dict[5 keys]: source,params,total_matching,credits_used,teams |
| `data/techstack_confirmed.json` | 17479 | dict[4 keys]: source,organization,note,business_functions |
| `data/techstack_detections.json` | 511244 | dict[5 keys]: source,query,count_reported,count_saved,detections |
| `data/transcripts_index.json` | 1696 | dict[3 keys]: source,calls,filings |
| `data/web_searches.json` | 4508 | list[8] |
| `deliverables/BD_Account_Summary.docx` | 60810 | 120 paras, 29 headings, 14 tables |
| `deliverables/BD_Job_Postings.xlsx` | 3051060 | Summary=21x8; Jobs=1898x14 |
| `deliverables/BD_People_List.xlsx` | 90782 | Summary=33x6; People=737x13 |
| `deliverables/BD_Sources_and_Evidence.docx` | 100780 | 273 paras, 43 headings, 14 tables |
| `deliverables/BD_Tech_Stack_and_Teams.xlsx` | 37330 | Platform Ranking=45x10; Confirmed stack=216x5; Platform teams=29x8 |
| `notes/pass1.md` | 2776 | 34 lines |
| `notes/pull_log_phase1.md` | 20303 | 81 lines |
| `notes/sense_check.md` | 9870 | 71 lines |
