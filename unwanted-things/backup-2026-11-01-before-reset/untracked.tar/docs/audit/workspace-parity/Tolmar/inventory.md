# Inventory: Tolmar

Files: 74; total 10195 KB

Top level: `(root)` (2), `build` (10), `data` (55), `deliverables` (5), `notes` (2)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 1989 | 18 lines |
| `build/evidence_content.py` | 16857 | 160 lines |
| `build/jobs_classify.py` | 8035 | 67 lines |
| `build/people_merge.py` | 12553 | 169 lines |
| `build/profile_findings.py` | 4058 | 46 lines |
| `build/redact.py` | 1359 | 20 lines |
| `build/redact_check.py` | 905 | 15 lines |
| `build/render_docx.js` | 1915 | 35 lines |
| `build/sources.py` | 21262 | 97 lines |
| `build/summary_content.py` | 43116 | 250 lines |
| `build/workbooks.py` | 15453 | 148 lines |
| `data/baseline_search.json` | 1916 | dict[3 keys]: query_objective,queries,results_kept |
| `data/company_pages/about-tolmar.md` | 7681 | 217 lines |
| `data/company_pages/author-eric-rustomji.md` | 1084 | 27 lines |
| `data/company_pages/manufacturing.md` | 3094 | 105 lines |
| `data/company_pages/media.md` | 2682 | 45 lines |
| `data/company_pages/technology-commercialization.md` | 3822 | 100 lines |
| `data/company_pages/treatments.md` | 13175 | 214 lines |
| `data/company_pages/working-at-tolmar.md` | 10625 | 218 lines |
| `data/company_record.json` | 450 | dict[6 keys]: domain,company_name,locations,parent_company_domain,subsidiary_companies,similar_companies |
| `data/company_record_second_source.json` | 394 | dict[8 keys]: tool,domain,name,industry,linkedin_industry,exact_revenue_field |
| `data/connections.json` | 26888 | dict[3 keys]: domain,meta_count,rows |
| `data/evidence.json` | 145859 | list[178] |
| `data/evidence.txt` | 129262 | 1748 lines |
| `data/gap_check_people.json` | 55685 | dict[3 keys]: pulled,note,queries |
| `data/ids.json` | 606 | list[89] |
| `data/jobs12.json` | 2791333 | list[362] |
| `data/jobs_12mo.json` | 2860715 | dict[4 keys]: domain,filter,meta_count,rows |
| `data/jobs_classified.json` | 527815 | list[59] |
| `data/jobs_keyword_counts.json` | 2897 | dict[4 keys]: base,status,keyword_matches_title_or_description,locations_top |
| `data/jobs_prior.json` | 957253 | dict[4 keys]: domain,filter,meta_count,rows |
| `data/live_board.json` | 20661 | dict[5 keys]: board_url,full_list_count_reported,scraped_on,postings,keyword_searches |
| `data/news_events.json` | 2205 | dict[4 keys]: domain,filter,meta_count,events |
| `data/newsroom.json` | 3426 | dict[7 keys]: source,total_items_reported_by_site,items_listed_first_page,note,careers_url_verified,items |
| `data/people_gapcheck.json` | 4556 | dict[4 keys]: pulled,source,rule,searches |
| `data/people_grid.json` | 61809 | dict[6 keys]: grid,searches,row_count,unique_people,rows,merge_note |
| `data/people_merged.json` | 73470 | dict[4 keys]: people,removed,former,counts |
| `data/people_second_source.json` | 25943 | dict[6 keys]: tool,query,total_reported,rows_returned,emails_and_phones,rows |
| `data/posts_comments.json` | 775458 | dict[3 keys]: tool,rule,rows |
| `data/profile_findings.json` | 9185 | dict[8 keys]: base,alumni,joined_last_12_months,new_role_last_12_months,tenure_bands,longest |
| `data/profiles_full.json` | 935715 | dict[2 keys]: tool,rows |
| `data/ranking_checked.json` | 163 | list[12] |
| `data/ranking_drop.json` | 545 | list[3] |
| `data/releases/2026_aim_media_steffey_ai_in_pharma.md` | 2468 | 29 lines |
| `data/releases/alpha-tau-and-tolmar-announce-strategic-collaboration-to-bring-alpha-dart-therap.md` | 30845 | 287 lines |
| `data/releases/delsitech-and-tolmar-announce-global-license-and-development-agreement-302059757.md` | 7605 | 116 lines |
| `data/releases/the-pharma-group-enters-into-an-exclusive-promotional-agreement-with-tolmar-inc.md` | 15676 | 189 lines |
| `data/releases/tolmar-announces-expanded-indication-for-rubraca-rucaparib-first-and-only-parp-i.md` | 20695 | 220 lines |
| `data/releases/tolmar-collaborates-with-direct-to-patient-telemedicine-company-upscripthealth-t.md` | 14584 | 188 lines |
| `data/releases/tolmar-launches-care-partner-corner-first-in-class-resource-dedicated-to-prostat.md` | 12077 | 167 lines |
| `data/releases/tolmar-launches-dedicated-youtube-channel-to-empower-advanced-practice-providers.md` | 9554 | 153 lines |
| `data/signal_feed_company.json` | 120919 | dict[5 keys]: company,signals,signal_summary,coverage,meta |
| `data/stack_names.json` | 605 | list[37] |
| `data/subsidiary_domains.json` | 1062 | dict[4 keys]: pulled,source,domains,feed_reported_subsidiary_domains |
| `data/summary.json` | 70077 | list[56] |
| `data/summary.txt` | 71189 | 1130 lines |
| `data/teams.json` | 51844 | dict[3 keys]: pulled,queries,note |
| `data/techstack_confirmed.json` | 16178 | dict[4 keys]: pulled,org_resolve,confirmed_stack,org_signals |
| `data/techstack_detections.json` | 23459 | dict[4 keys]: domain,filter,meta_count,rows |
| `data/transcripts/adastra_jon_steffey_interview.md` | 2356 | 15 lines |
| `data/transcripts/youtube_ALBMIghV06M_steffey_full_interview.md` | 4001 | 18 lines |
| `data/transcripts/youtube_ZJDdZx76eSY_tolmar_fabric_60_days.md` | 3732 | 9 lines |
| `data/transcripts/youtube__6OsIYhXKvM_sean_diwan_becker.md` | 2307 | 14 lines |
| `data/urls.json` | 36883 | dict[2 keys]: S,J |
| `data/web_searches.json` | 16344 | dict[4 keys]: searches,step2_lane_vendor_partnership_searches_2026_10_12,step2_selects_deploys_modernizes_2026_10_12,step3_subsidiary_and_board_searches_2026_10_12 |
| `data/web_searches_phase2.json` | 2386 | dict[3 keys]: phase,date,searches |
| `deliverables/Tolmar_Account_Summary.docx` | 47954 | ERR AttributeError |
| `deliverables/Tolmar_Job_Postings.xlsx` | 119025 | Summary=26x8; Jobs=60x13 |
| `deliverables/Tolmar_People_List.xlsx` | 26771 | Summary=32x8; People=120x18; Former staff seen=6x4 |
| `deliverables/Tolmar_Sources_and_Evidence.docx` | 70084 | ERR AttributeError |
| `deliverables/Tolmar_Tech_Stack_and_Teams.xlsx` | 13547 | Platform Ranking=23x10; Confirmed stack=38x5; About=6x8; Platform teams=18x10 |
| `notes/pass1.md` | 1811 | 17 lines |
| `notes/sense_check.md` | 16480 | 122 lines |
| `pull_log.md` | 23947 | 176 lines |
