# Inventory: Zelis_workspace.zip

Archive: `/home/sakib/Downloads/Zelis_workspace.zip`
SHA-256: `96741933f39d65018380749f3a3ad87c3d06e5876a28841f50b6b1913aa02ddb`
Archive bytes: 5278638

Members: 91; uncompressed bytes: 23305755

| Path | Bytes | Type / counts |
|---|---:|---|
| `Zelis_workspace/RESTORE.md` | 1791 | MD |
| `Zelis_workspace/pull_log.md` | 67559 | MD |
| `Zelis_workspace/deliverables/Zelis_Tech_Stack_and_Teams.xlsx` | 46876 | XLSX; Platform Ranking=34 rows, Confirmed Stack=147 rows, Platform Teams=27 rows, Technology Detections=688 rows |
| `Zelis_workspace/deliverables/Zelis_People_List.xlsx` | 65374 | XLSX; Summary=31 rows, People=572 rows, Excluded=27 rows |
| `Zelis_workspace/deliverables/Zelis_Account_Summary.docx` | 49655 | DOCX; DOCX 27 headings, 14 tables; headings: Heading 1: How to read this file / Heading 1: Narrative, in plain words / Heading 2: The account picture / Heading 2: What stands out / Heading 2: What it likely means for each lane (interpretation) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: Recent news / Heading 1: Company and transformation baseline / Heading 1: Signals / Heading 2: Tier 1, budget proximate / Heading 2: Tier 2, one step removed / Heading 2: Tier 3, context and openers / Heading 2: Context and history / Heading 1: Platform picture / Heading 1: People / Heading 2: Key people: senior and priority A / Heading 2: Findings from profiles / Heading 2: People whose status changed / Heading 1: Hypotheses to test / Heading 2: Cautions / Heading 1: Questions for a first conversation / Heading 1: Research coverage tracker / Heading 2: Decisions waiting on the account owner / Heading 2: Pass 1: summary homework / Heading 2: Pass 2: detailed homework / Heading 1: Source links |
| `Zelis_workspace/deliverables/Zelis_Job_Postings.xlsx` | 519053 | XLSX; Summary=31 rows, Jobs=348 rows |
| `Zelis_workspace/deliverables/Zelis_Sources_and_Evidence.docx` | 77558 | DOCX; DOCX 24 headings, 11 tables; headings: Heading 1: Part A: Source register / Heading 1: Part B: Extracts from postings read in full / Heading 2: J1. JR111620 Director, Salesforce Architecture (Boston) / Heading 2: J2. JR110600 Salesforce Manager (Hyderabad) / Heading 2: J3. JR109561 Salesforce Tech Lead, Sales and Service / Heading 2: J4. JR109562 Salesforce Tech Lead, Data and AI / Heading 2: J5. JR111520 Director, Contact Center Technology / Heading 2: J6. JR110717 Enterprise Architect / Heading 2: J7. JR110664 Sr Specialist, Marketing Automation / Heading 2: J8. JR111531 Marketing Analytics Engineer, Data Products and Activation / Heading 2: J9. JR110294 M365 Tech Lead / Heading 2: U1. JR106755 Salesforce Developer (Hyderabad) / Heading 1: Part C: Lane postings read one by one / Heading 1: Part D: Article and post extracts / Heading 1: Part E: Job board captures / Heading 2: Keyword searches / Heading 2: Every live listing / Heading 1: Part F: Leads not verified / Heading 1: Part G: How to keep copies of the original pages / Heading 1: Part H: Data pulls / Heading 2: Postings that name each platform / Heading 2: Technology detections, lane relevant rows / Heading 2: News event feed / Heading 1: Part I: Full URLs |
| `Zelis_workspace/notes/phase2_notes.md` | 1979 | MD |
| `Zelis_workspace/notes/pass1.md` | 1303 | MD |
| `Zelis_workspace/notes/sense_check.md` | 5837 | MD |
| `Zelis_workspace/data/teams.json` | 81429 | JSON; JSON object, 5 keys; arrays: teams[25] |
| `Zelis_workspace/data/live_board.json` | 39550 | JSON; JSON object, 14 keys; arrays: boards[7], boards_linked_not_scraped[3], keyword_searches[36], category_pages[3], matched_to_feed[78], new_live_postings[1], not_scraped_budget[0], notes[1] |
| `Zelis_workspace/data/connections.json` | 89537 | JSON; JSON object, 5 keys; arrays: connections[359] |
| `Zelis_workspace/data/techstack_confirmed.json` | 12021 | JSON; JSON object, 5 keys; arrays: business_functions.Engineering & R&D.Programming Languages and Frameworks.primary[4], business_functions.Engineering & R&D.Programming Languages and Frameworks.evidence[10], business_functions.Engineering & R&D.Cloud Vendor.primary[2], business_functions.Engineering & R&D.Cloud Vendor.evidence[3], business_functions.Engineering & R&D.CI/CD.primary[3], business_functions.Engineering & R&D.CI/CD.evidence[6], business_functions.Engineering & R&D.Logging, Observability & Monitoring.primary[4], business_functions.Engineering & R&D.Logging, Observability & Monitoring.evidence[10], business_functions.Engineering & R&D.Cloud and Container Orchestration Platforms.primary[6], business_functions.Engineering & R&D.Cloud and Container Orchestration Platforms.evidence[7], business_functions.Data & Analytics.Cloud Data Warehouse.primary[1], business_functions.Data & Analytics.Cloud Data Warehouse.evidence[3] |
| `Zelis_workspace/data/leadership.json` | 2326 | JSON; JSON object, 8 keys; arrays: executives[11], investor_logos_on_page[3], careers_links_on_site[2] |
| `Zelis_workspace/data/org_signals.json` | 82 | JSON; JSON object, 4 keys; arrays: signals[0] |
| `Zelis_workspace/data/techstack_detections.json` | 115642 | JSON; JSON object, 5 keys; arrays: detections[687] |
| `Zelis_workspace/data/jobs_keyword_counts.json` | 1843 | JSON; JSON object, 29 keys |
| `Zelis_workspace/data/posts_comments.json` | 3301614 | JSON; JSON object, 7 keys; arrays: rows[133] |
| `Zelis_workspace/data/org_resolve.json` | 453 | JSON; JSON object, 9 keys; arrays: subsidiary_ids[5] |
| `Zelis_workspace/data/web_searches.json` | 245185 | JSON; JSON object, 3 keys; arrays: queries[169], former_exec_checks[5] |
| `Zelis_workspace/data/people_grid_history.json` | 749478 | JSON; JSON object, 3 keys; arrays: rows[587] |
| `Zelis_workspace/data/jobs_12mo.json` | 6014303 | JSON; JSON object, 5 keys; arrays: jobs[713] |
| `Zelis_workspace/data/subsidiary_domains.json` | 106554 | JSON; JSON object, 2 keys; arrays: subsidiaries.rivethealth.com.jobs_12mo.jobs[14], subsidiaries.rivethealth.com.tech_24mo.detections[93], subsidiaries.myzelis.com.jobs_12mo.jobs[0], subsidiaries.myzelis.com.tech_24mo.technologies[18] |
| `Zelis_workspace/data/newsroom.json` | 1702 | JSON; JSON object, 5 keys; arrays: latest_announcements[3], in_the_news[3] |
| `Zelis_workspace/data/people_gapcheck.json` | 5285 | JSON; JSON object, 4 keys; arrays: lanes.Salesforce.people[10], lanes.MuleSoft.people[0], lanes.ServiceNow.people[1], lanes.SAP.people[2], lanes.Tableau.people[3] |
| `Zelis_workspace/data/company_record.json` | 652 | JSON; JSON object, 9 keys; arrays: locations[6], subsidiary_domains[2], similar_companies_reported[5] |
| `Zelis_workspace/data/profiles_full.json` | 4623452 | JSON; JSON object, 5 keys; arrays: profiles[594] |
| `Zelis_workspace/data/news_events.json` | 10343 | JSON; JSON object, 5 keys; arrays: events[23] |
| `Zelis_workspace/data/releases/2026-06-24_zelis-launches-ai-native-solution-to-help-payers-address-rising-idr-challenges.md` | 6481 | MD |
| `Zelis_workspace/data/releases/2022-08-16_web_zelis-wayne-deveydt-board-appointment.md` | 3882 | MD |
| `Zelis_workspace/data/releases/undated_web_zelis-leadership-sue-schick-redirect.md` | 1068 | MD |
| `Zelis_workspace/data/releases/2025-08-04_web_beckers-meet-unitedhealth-groups-new-cfo.md` | 1329 | MD |
| `Zelis_workspace/data/releases/2026-04-20_new-chief-strategy-revenue-officers.md` | 4585 | MD |
| `Zelis_workspace/data/releases/2026-04-02_web_builtin_sr-salesforce-developer-2.md` | 455 | MD |
| `Zelis_workspace/data/releases/2025-12-04_zelis-appoints-jim-bridges-as-president-of-price-optimization.md` | 2787 | MD |
| `Zelis_workspace/data/releases/2025-10-29_zelis-intelligent-pricing-platform-launch.md` | 5219 | MD |
| `Zelis_workspace/data/releases/2024-03-21_zelis-and-strategic-alliance-[redacted].md` | 5557 | MD |
| `Zelis_workspace/data/releases/2026-08-17_vyne-dental-and-zelis-partner-to-modernize-insurance-payments.md` | 4649 | MD |
| `Zelis_workspace/data/releases/2026-09-17_zelis-brings-clarity-to-healthcare-costs.md` | 5683 | MD |
| `Zelis_workspace/data/releases/2026-02-04_zelis-earns-top-score-on-hrc-corporate-equality-index-second-consecutive-year.md` | 2917 | MD |
| `Zelis_workspace/data/releases/2025-06-03_zelis-acquires-assets-of-medxoom.md` | 3145 | MD |
| `Zelis_workspace/data/releases/2026-05-22_zelis-recognized-as-a-2026-great-place-to-work-in-the-us-and-india.md` | 3492 | MD |
| `Zelis_workspace/data/releases/2025-11-19_web_builtin_director-salesforce-coe.md` | 4176 | MD |
| `Zelis_workspace/data/releases/undated_web_moduscreate-homepage-not-zelis-case-study.md` | 2929 | MD |
| `Zelis_workspace/data/releases/2023-04-03_web_zelis-announces-sue-schick-president-cro.md` | 4347 | MD |
| `Zelis_workspace/data/releases/2025-09-22_web_builtin_senior-product-manager-salesforce-platform.md` | 1811 | MD |
| `Zelis_workspace/data/releases/2026-07-10_zelis-a-leader-in-everest-groups-peak-matrix-assessment-2026.md` | 8604 | MD |
| `Zelis_workspace/data/releases/2026-01-12_zelis-acquires-rivet.md` | 3037 | MD |
| `Zelis_workspace/data/releases/undated_web_marketscreener-wayne-deveydt-profile.md` | 3147 | MD |
| `Zelis_workspace/data/releases/2026-09-14_zelis-names-jim-young-chief-financial-administrative-officer.md` | 2929 | MD |
| `Zelis_workspace/data/releases/undated_web_investorshangout-sue-schick-turningpoint-ceo.md` | 4154 | MD |
| `Zelis_workspace/data/releases/2026-05-07_zelis-wins-2026-medtech-breakthrough-award-for-healthcare-payments-innovation.md` | 5022 | MD |
| `Zelis_workspace/data/releases/2025-07-01_zelis-recognized-as-a-2025-great-place-to-work-in-the-us-and-india.md` | 3564 | MD |
| `Zelis_workspace/data/releases/2026-01-29_zelis-introduces-zapp-edge.md` | 3439 | MD |
| `Zelis_workspace/data/releases/2026-10-07_live_JR108546_2nd-machine-operators-fenton-mo.md` | 5226 | MD |
| `Zelis_workspace/data/releases/2022-04-26_web_zelis-linda-zukauckas-board-appointment.md` | 3802 | MD |
| `Zelis_workspace/data/releases/undated_web_marketscreener-sue-schick-profile.md` | 1898 | MD |
| `Zelis_workspace/data/releases/2026-03-27_jopari-solutions-expands-digital-payments-through-partnership-with-zelis.md` | 4386 | MD |
| `Zelis_workspace/data/releases/2026-06-19_zelis-selects-aws-to-modernize-the-healthcare-financial-experience.md` | 2848 | MD |
| `Zelis_workspace/data/releases/2026-07-30_zelis-research-on-payer-concerns-over-administrative-complexity.md` | 7222 | MD |
| `Zelis_workspace/data/releases/undated_web_marketscreener-linda-zukauckas-profile.md` | 2264 | MD |
| `Zelis_workspace/data/releases/2025-10-16_zelis-study-shows-employers-consumers-believe-ai-digital-tools-transparency-will-improve-healthcare.md` | 7682 | MD |
| `Zelis_workspace/data/releases/2025-11-14_duck-creek-working-with-zelis-on-payments.md` | 4007 | MD |
| `Zelis_workspace/data/releases/2026-09-14_web_businesswire-zelis-names-jim-young-cfo-succeeding-gladden.md` | 3246 | MD |
| `Zelis_workspace/data/releases/2026-06-18_zelis-picks-aws-to-automate-healthcare-pricing-and-payments.md` | 3148 | MD |
| `Zelis_workspace/data/releases/undated_web_drexel-lebow-sue-schick-bio.md` | 2571 | MD |
| `Zelis_workspace/data/releases/2025-05-08_zelis-health-bill-assist-wins-healthcare-insurance-innovation-award.md` | 5929 | MD |
| `Zelis_workspace/data/releases/2025-10-23_zelis-celebrated-again-as-a-fortune-best-workplaces-for-women.md` | 2955 | MD |
| `Zelis_workspace/build/stack_wb.py` | 5120 | PY |
| `Zelis_workspace/build/profile_findings2.json` | 14598 | JSON; JSON object, 13 keys; arrays: kw.AWS.names[8], kw.Azure.names[8], kw.Salesforce (any).names[20], kw.Workday.names[7], kw.NICE CXone.names[2], kw.Snowflake.names[8], kw.Revenue Cloud or CPQ.names[2], kw.ServiceNow.names[1], kw.HubSpot.names[2], kw.Jira or Confluence.names[17], kw.Tableau.names[3], kw.Power BI.names[4] |
| `Zelis_workspace/build/lane_rows.json` | 929447 | JSON; JSON array, 112 records |
| `Zelis_workspace/build/people_wb.py` | 8133 | PY |
| `Zelis_workspace/build/profile_findings.json` | 12267 | JSON; JSON object, 4 keys; arrays: kw.Salesforce[31], kw.CPQ[3], kw.ServiceNow[1], kw.Snowflake[15], kw.Tableau[10], kw.Workday[9], kw.Power BI[15], kw.Sigma[15], kw.Agentforce[1], kw.Health Cloud[1], kw.Marketing Cloud[2], kw.SAP[3] |
| `Zelis_workspace/build/summary_ids.json` | 387 | JSON; JSON array, 67 records |
| `Zelis_workspace/build/stack_names.json` | 2149 | JSON; JSON array, 145 records |
| `Zelis_workspace/build/jobs_wb.py` | 8200 | PY |
| `Zelis_workspace/build/jobs_base.json` | 50356 | JSON; JSON array, 347 records |
| `Zelis_workspace/build/jobs12.json` | 5472015 | JSON; JSON array, 713 records |
| `Zelis_workspace/build/all_ids.json` | 432 | JSON; JSON array, 75 records |
| `Zelis_workspace/build/evidence.js` | 13699 | JS |
| `Zelis_workspace/build/evidence_data.json` | 61928 | JSON; JSON object, 6 keys; arrays: ext.J1[9], ext.J2[9], ext.J3[9], ext.J4[9], ext.J5[6], ext.J6[6], ext.J7[9], ext.J8[9], ext.J9[1], lanerows[123], board[78], kws[36] |
| `Zelis_workspace/build/people_merged.json` | 241064 | JSON; JSON object, 4 keys; arrays: people[571], excl_sec[14], excl_ent[3], moved[9] |
| `Zelis_workspace/build/checked.json` | 79 | JSON; JSON array, 4 records |
| `Zelis_workspace/build/common.js` | 1876 | JS |
| `Zelis_workspace/build/people_build.py` | 9249 | PY |
| `Zelis_workspace/build/evidence_data.py` | 4639 | PY |
| `Zelis_workspace/build/excluded_names.json` | 297 | JSON; JSON array, 17 records |
| `Zelis_workspace/build/urls.js` | 23087 | JS |
| `Zelis_workspace/build/profile_findings2.py` | 4233 | PY |
| `Zelis_workspace/build/summary.js` | 48472 | JS |
