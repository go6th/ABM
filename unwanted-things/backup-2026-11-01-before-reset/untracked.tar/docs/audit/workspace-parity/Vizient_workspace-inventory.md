# Inventory: Vizient_workspace.zip

Archive: `/home/sakib/Downloads/Vizient_workspace.zip`
SHA-256: `e411cad7efceea031ad99677047c6adbe911432897d47e39326c25f939e25ebf`
Archive bytes: 319585

Members: 48; uncompressed bytes: 602079

| Path | Bytes | Type / counts |
|---|---:|---|
| `Vizient/` | 0 | file |
| `Vizient/deliverables/` | 0 | file |
| `Vizient/deliverables/Vizient_Job_Postings.xlsx` | 31813 | XLSX; Summary=18 rows, Jobs=207 rows |
| `Vizient/deliverables/Vizient_Account_Summary.docx` | 53143 | DOCX; DOCX 26 headings, 14 tables; headings: Heading 1: 1. How to read this file / Heading 1: 2. The account in plain words / Heading 2: The account picture / Heading 2: What stands out / Heading 2: What it likely means for each lane (interpretation) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: 3. Recent news / Heading 1: 4. Company and transformation baseline / Heading 1: 5. Signals / Heading 2: Tier 1: budget proximate / Heading 2: Tier 2: one step removed / Heading 2: Tier 3: context and openers / Heading 2: Context and history (older than 18 months) / Heading 1: 6. Platform picture by lane / Heading 1: 7. People / Heading 2: Key people (priority A, senior) / Heading 2: Findings from profiles / Heading 2: People whose status changed / Heading 1: 8. Hypotheses to test / Heading 1: 9. Questions for a first conversation / Heading 1: 10. Research coverage tracker / Heading 2: Decisions waiting on the account owner / Heading 2: Pass 1: summary homework / Heading 2: Pass 2: detailed homework / Heading 1: 11. Source links |
| `Vizient/deliverables/Vizient_People_List.xlsx` | 35311 | XLSX; Summary=29 rows, People=221 rows |
| `Vizient/deliverables/Vizient_Tech_Stack_and_Teams.xlsx` | 12623 | XLSX; Summary=14 rows, Confirmed stack=123 rows, Platform teams=26 rows |
| `Vizient/deliverables/Vizient_Sources_and_Evidence.docx` | 65785 | DOCX; DOCX 16 headings, 10 tables; headings: Heading 1: Part A. Source register / Heading 1: Part B. Job posting extracts (postings read in depth) / Heading 2: Live posting read in full / Heading 1: Part C. Postings read one by one, live board, primary lanes / Heading 1: Part D. Post and article extracts / Heading 2: Article and page extracts / Heading 1: Part E. Job board captures / Heading 1: Part F. Leads not verified, with the queries tried / Heading 1: Part G. How to keep copies of the original pages / Heading 1: Part H. Data pulls / Heading 2: Confirmed technology stack by function (postings confirming use, all time; S22) / Heading 2: Platform teams (S23; 25 of 94 matching teams, ordered by postings since March 2026) / Heading 2: Lane metrics, all time (S22) / Heading 2: Structured news events, 18 months to September 29, 2026 (S21; 28 events) / Heading 2: 12 month lane job search (S37) / Heading 1: Part I. Full URLs |
| `Vizient/notes/` | 0 | file |
| `Vizient/notes/pass1.md` | 1423 | MD |
| `Vizient/notes/sense_check.md` | 12608 | MD |
| `Vizient/notes/handoff.md` | 1834 | MD |
| `Vizient/RESTORE.md` | 2217 | MD |
| `Vizient/data/` | 0 | file |
| `Vizient/data/jobs_hidden_titles.json` | 16831 | JSON; JSON object, 3 keys; arrays: jobs[26] |
| `Vizient/data/teams.json` | 5832 | JSON; JSON object, 5 keys; arrays: teams[25] |
| `Vizient/data/live_board.json` | 11342 | JSON; JSON object, 4 keys; arrays: keywords.Salesforce.page1_titles[10], keywords.Salesforce.page2_links[4], keywords.MuleSoft.links[0], keywords.ServiceNow.links[2], keywords.SAP.links[6], keywords.Tableau.links[21], keywords.Veeva.links[0], keywords.Workday.links[7], keywords.Databricks.links[20], keywords.Snowflake.links[2], keywords.Azure.links[10], read_queue.primary[40] |
| `Vizient/data/techstack_confirmed.json` | 2992 | JSON; JSON object, 4 keys |
| `Vizient/data/profiles_extract.md` | 23319 | MD |
| `Vizient/data/org_signals.json` | 79 | JSON; JSON object, 3 keys; arrays: lane_filtered[0], unfiltered[0] |
| `Vizient/data/stack_org_metrics.json` | 1648 | JSON; JSON object, 3 keys; arrays: org.subsidiary_ids[3] |
| `Vizient/data/posts_raw.psv` | 7334 | PSV |
| `Vizient/data/releases/` | 0 | file |
| `Vizient/data/releases/r03_arun_ramasubramanian_2025-06-23.md` | 757 | MD |
| `Vizient/data/releases/r04_sxanpro_2026-09-17.md` | 496 | MD |
| `Vizient/data/releases/r05_governance_board.md` | 1063 | MD |
| `Vizient/data/releases/r01_invest_1b_2026-09-23.md` | 1297 | MD |
| `Vizient/data/releases/r02_empierus_2026-06-11.md` | 848 | MD |
| `Vizient/data/profiles_compact.psv` | 5882 | PSV |
| `Vizient/data/postings_read.psv` | 8557 | PSV |
| `Vizient/data/web_searches.json` | 15010 | JSON; JSON array, 16 records |
| `Vizient/data/jobs_12mo_lanes.json` | 23210 | JSON; JSON object, 5 keys; arrays: jobs[166] |
| `Vizient/data/postings/` | 0 | file |
| `Vizient/data/postings/446720262784.md` | 2257 | MD |
| `Vizient/data/postings/446720262784_full.md` | 3741 | MD |
| `Vizient/data/people_grid_raw.psv` | 19562 | PSV |
| `Vizient/data/newsroom.json` | 12506 | JSON; JSON object, 5 keys; arrays: release_urls[41], other_urls_of_interest[12], newsroom_page1.items_on_page1[24] |
| `Vizient/data/posts_extract.json` | 27220 | JSON; JSON object, 4 keys; arrays: items[89] |
| `Vizient/data/people_grid.json` | 54252 | JSON; JSON object, 4 keys; arrays: rows[225] |
| `Vizient/data/news_events.json` | 9089 | JSON; JSON object, 4 keys; arrays: events[28] |
| `Vizient/build/` | 0 | file |
| `Vizient/build/evidence.js` | 18154 | JS |
| `Vizient/build/build_stack.py` | 4983 | PY |
| `Vizient/build/tracker.py` | 7675 | PY |
| `Vizient/build/build_jobs.py` | 10078 | PY |
| `Vizient/build/urls.js` | 15543 | JS |
| `Vizient/build/build_people.py` | 16561 | PY |
| `Vizient/build/summary.js` | 39177 | JS |
| `Vizient/pull_log.md` | 18027 | MD |
