# Inventory: athenahealth

Files: 60; total 37189 KB

Top level: `(root)` (7), `build` (16), `data` (29), `deliverables` (6), `notes` (2)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 4659 | 47 lines |
| `build/build_evidence.js` | 24553 | 139 lines |
| `build/build_evidence.v1.js.bak` | 11522 |  |
| `build/build_pete_briefing.js` | 12703 | 74 lines |
| `build/build_summary.js` | 41342 | 224 lines |
| `build/build_summary.v1.js.bak` | 29960 |  |
| `build/doc_checks.py` | 2140 | 59 lines |
| `build/doc_data.json` | 9587 | dict[17 keys]: J1,J2,J3,J4,J5,J6 |
| `build/docx_lib.js` | 4575 | 44 lines |
| `build/jobs_workbook_example.py` | 5782 | 80 lines |
| `build/make_workbooks.py` | 14191 | 209 lines |
| `build/make_workbooks.v1.py.bak` | 11318 |  |
| `build/people_workbook_example.py` | 11918 | 146 lines |
| `build/rowcheck.py` | 1680 | 43 lines |
| `build/strip_tool_names.py` | 1115 | 22 lines |
| `build/urlmap.json` | 8539 | dict[46 keys]: S1,S2,S3,S4,S5,S6 |
| `build/urls.js` | 5861 | 36 lines |
| `data/bitscale_rows_full.json` | 1340449 | list[1] |
| `data/bitscale_rows_raw.json` | 965335 | list[1] |
| `data/jobs_12mo.json` | 8364191 | list[1136] |
| `data/jobs_p1_raw.json` | 8598526 | list[1] |
| `data/jobs_p2_raw.json` | 1115046 | list[1] |
| `data/jobs_platform_hits.json` | 17658 | dict[20 keys]: Salesforce,Workday,CPQ,Tableau,Power BI,Snowflake |
| `data/jobs_sf_class.json` | 12155 | dict[155 keys]: f7c8844f-1fa5-40f5-96b0-9c2edca97ff7,75449a0e-caf8-4e28-abdf-40c3a1338c13,7bf99313-53d9-4fe7-b684-0ff477c18b82,86eb0361-4cf7-44e0-86a5-37f7dd016e97,f4b5decc-42cc-4e04-a242-99de4911580f,b9dff612-c70a-4818-abbf-92da50f3c5a3 |
| `data/news_compact.json` | 14864 | list[63] |
| `data/news_raw.json` | 375730 | list[1] |
| `data/pass3/findings.jsonl` | 12699 |  |
| `data/pass3/posts_analysis.json` | 10202 | list[21] |
| `data/pass3/profile_analysis.json` | 98230 | list[178] |
| `data/pass3/profiles_raw.json` | 1788703 | dict[178 keys]: 1,2,3,4,5,6 |
| `data/pass3/row_ids.json` | 1727 | dict[3 keys]: senior_row_ids,a_row_ids,missing_senior |
| `data/pass3/rows/page1.json` | 611442 | list[1] |
| `data/pass3/rows/page2.json` | 637435 | list[1] |
| `data/pass3/rows/page3.json` | 521283 | list[1] |
| `data/pass3/rows/page4.json` | 246501 | list[1] |
| `data/pass3/youtube_bassolino_2025-04-09.md` | 676 | 2 lines |
| `data/pass4/builders.json` | 13727 | list[40] |
| `data/pass4/sumble_pass4.json` | 520 | dict[3 keys]: salesforce_association_senior,builder_levels,tech_slug_search |
| `data/people_all.json` | 637340 | list[420] |
| `data/people_final.json` | 339086 | list[178] |
| `data/people_raw_dedup.json` | 98397 | list[300] |
| `data/people_ruled.json` | 667563 | dict[3 keys]: kept,excluded,below |
| `data/sumble_teams.json` | 13438 | dict[5 keys]: organization,teams_total,teams_page,note,teams |
| `data/sumble_tech_stack.json` | 12955 | dict[4 keys]: organization,source,org_page,functions |
| `data/tech_detections_compact.json` | 118481 | list[603] |
| `data/tech_detections_raw.json` | 1414681 | list[1] |
| `deliverables/athenahealth_Account_Summary.docx` | 40526 | ERR AttributeError |
| `deliverables/athenahealth_Job_Postings.xlsx` | 334843 | Summary=33x2; Jobs=260x10 |
| `deliverables/athenahealth_POC_Call_Briefing.docx` | 18900 | ERR AttributeError |
| `deliverables/athenahealth_People_List.xlsx` | 35472 | Summary=22x2; People=179x15; Builders and marketing data=43x9 |
| `deliverables/athenahealth_Sources_and_Evidence.docx` | 57802 | ERR AttributeError |
| `deliverables/athenahealth_Tech_Stack_and_Teams.xlsx` | 13062 | Read me=7x1; Tech stack=114x5; Teams=19x4 |
| `jobs_12mo.json` | 8780186 | list[1187] |
| `news_18mo.json` | 16374 | list[63] |
| `notes/HANDOFF.md` | 5237 | 39 lines |
| `notes/pass1.md` | 2106 | 11 lines |
| `run_state.json` | 7990 | dict[11 keys]: account,domain,pursuing_client,run_date,careers_site_verified,sumble_org |
| `sf_platform_sentences.json` | 114895 | list[162] |
| `tech_detections.json` | 328674 | list[602] |
| `tech_named.json` | 75050 | list[602] |
