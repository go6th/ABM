# Inventory: workday

Files: 73; total 41599 KB

Top level: `(root)` (3), `build` (32), `data` (31), `deck` (2), `deliverables` (5)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 5913 | 48 lines |
| `build/doc_checks.py` | 2140 | 59 lines |
| `build/docx_lib.js` | 4575 | 44 lines |
| `build/evidence_content.json` | 235590 | list[117] |
| `build/ids.json` | 10631 | dict[121 keys]: S1,S2,S3,S4,S5,S6 |
| `build/jobs.py` | 921 | 14 lines |
| `build/jobs_rows.json` | 6955945 | list[817] |
| `build/jobs_summary_grid.json` | 11722 | dict[2 keys]: cells,widths |
| `build/people_rows.json` | 175826 | list[324] |
| `build/people_summary_grid.json` | 15044 | dict[2 keys]: cells,widths |
| `build/people_wb.py` | 1128 | 18 lines |
| `build/rebuild_docs.py` | 2905 | 56 lines |
| `build/refresh_11oct/docx_helpers.py` | 3117 | 89 lines |
| `build/refresh_11oct/drop_orphan_links.py` | 350 | 9 lines |
| `build/refresh_11oct/evidence_v2.py` | 14784 | 169 lines |
| `build/refresh_11oct/evidence_v3_addendum.py` | 7268 | 110 lines |
| `build/refresh_11oct/followup_lists.json` | 9387 | dict[2 keys]: new,A |
| `build/refresh_11oct/ids_v2.json` | 829 | list[121] |
| `build/refresh_11oct/jobs_v2.py` | 11181 | 136 lines |
| `build/refresh_11oct/match.py` | 1179 | 21 lines |
| `build/refresh_11oct/paths.json` | 9857 | list[44] |
| `build/refresh_11oct/people_v2.py` | 8188 | 115 lines |
| `build/refresh_11oct/people_v3_addendum.py` | 6599 | 99 lines |
| `build/refresh_11oct/platform_ranking_wd.py` | 11439 | 192 lines |
| `build/refresh_11oct/sources_v2.py` | 9451 | 46 lines |
| `build/refresh_11oct/summary_v2.py` | 20478 | 196 lines |
| `build/refresh_11oct/summary_v3_addendum.py` | 8121 | 92 lines |
| `build/refresh_11oct/techstack_wb.py` | 6698 | 51 lines |
| `build/refresh_11oct/tracker.json` | 7002 | dict[2 keys]: intro,rows |
| `build/rowcheck.py` | 1680 | 43 lines |
| `build/summary_content.json` | 83631 | list[85] |
| `build/urls.json` | 37183 | dict[121 keys]: S1,S2,S3,S4,S5,S6 |
| `build/wb_common.py` | 1643 | 42 lines |
| `data/board_details_oct11.json` | 283967 | dict[31 keys]: JR-0110259,JR-0110629,JR-0110540,JR-0110609,JR-0110105,JR-0110631 |
| `data/board_oct11.json` | 56755 | dict[11 keys]: Salesforce,MuleSoft,Agentforce,Revenue Cloud,Databricks,Snowflake |
| `data/board_raw_oct11.json` | 50735 | dict[5 keys]: success,result,stdout,stderr,exitCode |
| `data/email_lookup_urls.json` | 4590 | list[105] |
| `data/emails_oct11.json` | 5875 | dict[83 keys]: akashkapoor9,christian-danish-96b76,farhadchoudhury,jessiemckay,joe-dossantos,mohit-nadkarni-56b1a41 |
| `data/jobs12m_oct11.json` | 24763703 | list[3136] |
| `data/jobs_new_rows_oct11.json` | 1468725 | list[186] |
| `data/jobs_oct11.json` | 1745144 | dict[3 keys]: data,included,meta |
| `data/missing172.json` | 1369793 | list[172] |
| `data/missing172_sentences.txt` | 39973 | 172 lines |
| `data/new_jobs_sentences.txt` | 25880 | 176 lines |
| `data/news_oct11.json` | 168356 | dict[3 keys]: data,included,meta |
| `data/paths_to_read.json` | 2706 | dict[31 keys]: JR-0110259,JR-0110629,JR-0110540,JR-0110609,JR-0110105,JR-0110631 |
| `data/paths_verify.json` | 9856 | dict[44 keys]: https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USAVAReston/Software-Development-Engineer--SRE--US-Federal-_JR-0110178,https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USA-CO-Boulder/Sr-Software-Development-Engineer_JR-0109804,https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/Canada-BC-Vancouver/Principal-Software-Development-Engineer---AI-Platform_JR-0110056,https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USAVAReston/Mid-Senior-Site-Reliability-Engineer--US-Federal-_JR-0110301,https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USAVAReston/Cybersecurity-Engineer_JR-0109828,https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/INDPune/Sr-Associate-Customer-Support-Analyst--AI-ML-Application-Support-_JR-0110060 |
| `data/people_pull_oct11.py` | 18642 | 97 lines |
| `data/platform_teams.json` | 151310 | dict[6 keys]: id,credits_used,credits_remaining,teams,matched_count,total |
| `data/platform_teams_compact.json` | 12073 | list[25] |
| `data/posts_priorityA_compact_oct12.json` | 211364 | dict[27 keys]: Charles Baker,Akash Kapoor,Andrea Simon,Christian Danish,Farhad Choudhury,Gaurav Kakar |
| `data/posts_priorityA_full_oct12.json` | 515267 | dict[27 keys]: Charles Baker,Akash Kapoor,Andrea Simon,Christian Danish,Farhad Choudhury,Gaurav Kakar |
| `data/posts_raw_oct11.txt` | 277101 | 5370 lines |
| `data/profile_status_oct12.json` | 8551 | dict[32 keys]: Charles Baker,Jim Delia,Tim Stucka,Kurt Steward,John Kravitz,Cara Engelbrecht |
| `data/profiles_compact_oct12.json` | 45175 | list[32] |
| `data/profiles_full_oct12.json` | 289318 | dict[32 keys]: Charles Baker,Jim Delia,Tim Stucka,Kurt Steward,John Kravitz,Cara Engelbrecht |
| `data/rank_checked.json` | 79 | list[5] |
| `data/rank_drops.json` | 10344 | list[78] |
| `data/record_check_oct11.json` | 5278 | dict[3 keys]: note,fields,rows |
| `data/stack_names.json` | 2130 | list[155] |
| `data/talent_ppm_finance_atlanta.txt` | 2029 | 7 lines |
| `data/tech_stack.json` | 8589 | dict[3 keys]: pulled,note,stack |
| `data/techdet_oct11.json` | 1541103 | dict[3 keys]: data,included,meta |
| `data/verify_open.json` | 6085 | list[43] |
| `deck/build_deck.js` | 23047 | 237 lines |
| `deck/source_slides.js` | 16597 | 175 lines |
| `deliverables/Workday_Account_Summary.docx` | 70046 | 103 paras, 24 headings, 11 tables |
| `deliverables/Workday_Job_Postings.xlsx` | 1476676 | Summary=44x7; Jobs=1004x16 |
| `deliverables/Workday_People_List.xlsx` | 58994 | Summary=72x5; People=357x19 |
| `deliverables/Workday_Sources_and_Evidence.docx` | 119000 | 160 paras, 18 headings, 11 tables |
| `deliverables/Workday_Tech_Stack_and_Teams.xlsx` | 20169 | Platform Ranking=52x10; Confirmed Stack=165x5; Platform Teams=31x6 |
| `notes_open_leads.md` | 1530 | 12 lines |
| `notes_sources.md` | 28889 | 129 lines |
