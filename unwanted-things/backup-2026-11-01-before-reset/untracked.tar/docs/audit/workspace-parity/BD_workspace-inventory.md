# Inventory: BD_workspace.zip

Archive: `/home/sakib/Downloads/BD_workspace.zip`
SHA-256: `d8a29b6b40280e72a5aa9b45a2fb143250790eeb7a842527457ff12c679cb3ac`
Archive bytes: 43445231

Members: 372; uncompressed bytes: 191256802

| Path | Bytes | Type / counts |
|---|---:|---|
| `ws/` | 0 | file |
| `ws/BD_[redacted]_Only.docx` | 12159 | DOCX; DOCX 3 headings, 0 tables; headings: Heading 1: What was found in the Client's records / Heading 1: Why it matters / Heading 1: What the client facing files say instead |
| `ws/deliverables/` | 0 | file |
| `ws/deliverables/BD_Tech_Stack_and_Teams.xlsx` | 37330 | XLSX; Platform Ranking=42 rows, Confirmed stack=215 rows, Platform teams=28 rows |
| `ws/deliverables/BD_People_List.xlsx` | 90782 | XLSX; Summary=29 rows, People=737 rows |
| `ws/deliverables/BD_Sources_and_Evidence.docx` | 100780 | DOCX; DOCX 43 headings, 14 tables; headings: Heading 1: Part A. Source register / Heading 1: Part B. Job posting extracts for postings read in full / Heading 1: Part C. Postings read one by one, by lane / Heading 2: Salesforce: 29 postings read in full (551 BD postings name it, 92 open on 19 Oct 2026) / Heading 2: MuleSoft: 4 postings read in full (10 BD postings name it, 3 open on 19 Oct 2026) / Heading 2: SAP: 25 postings read in full (1068 BD postings name it, 150 open on 19 Oct 2026) / Heading 2: ServiceNow: 0 postings read in full (26 BD postings name it, 3 open on 19 Oct 2026) / Heading 2: Veeva: 3 postings read in full (63 BD postings name it, 12 open on 19 Oct 2026) / Heading 2: Tableau: 3 postings read in full (43 BD postings name it, 2 open on 19 Oct 2026) / Heading 2: Workday: 2 postings read in full (74 BD postings name it, 9 open on 19 Oct 2026) / Heading 1: Part D. Video, article and release extracts / Heading 2: Arthur Hu to Join BD as Chief Information and Digital Officer (21 Sep 2026) (S2) / Heading 2: Arthur Hu leadership biography (S3) / Heading 2: BD Completes Combination of Biosciences and Diagnostic Solutions Business with Waters (9 Feb 2026) (S4) / Heading 2: BD Reports Third Quarter Fiscal 2026 Financial Results (6 Aug 2026) (S5) / Heading 2: Fiscal Q3 2026 earnings call (6 Aug 2026), executive voice (S6) / Heading 2: Fiscal Q2 2026 earnings call (7 May 2026), executive voice (S7) / Heading 2: Capgemini client story: Transforming BD's global integration landscape (24 Apr 2026) (S23) / Heading 2: PwC case study: E-Commerce storefront transforms medical product sales and service (7 Sep 2023) (S24) / Heading 2: ServiceNow case study: BD advances to RiseUp with ServiceNow (17 Aug 2023) (S25) / Heading 2: Becton Dickinson drives success with ServiceNow University (video, 24 Jul 2025) (S27) / Heading 2: SAP customer story video page: Becton Dickinson (Jul 2024) (S28) / Heading 2: Veeva customer story: Unifying eTMF, CTMS, and Payments to Accelerate Clinical Trials at BD (S29) / Heading 2: BD Launches New AI-enabled Solutions to Drive Connectivity Across Healthcare Settings (20 Oct 2025) (S22) / Heading 2: BD and U.S. Government Launch Landmark Partnership (6 Oct 2026) (S20) / Heading 2: The Beat podcast with CTO Beth McCombs (19 Dec 2025) (S30) / Heading 2: Fierce Biotech interview with Bilal Muhsin (19 Dec 2025) (S31) / Heading 2: CIO.com interview with Denise Russell Fleming (26 Mar 2026) (S32) / Heading 2: Michael Feld leadership biography (S34) / Heading 2: Sandeep Arora public profile (search excerpt) (S37) / Heading 2: Role descriptions on public profiles (each describes that person's own work at BD) (S61) / Heading 2: Posts by priority A people (S46 pull), last six months (S62) / Heading 1: Part E. Job board captures / Heading 2: Live postings captured on 19 October 2026 that name a lane platform / Heading 1: Part F. Leads not verified, and items checked and dropped / Heading 1: Part G. How to keep copies of the original pages / Heading 1: Part H. Data pulls / Heading 2: Technology detections for lane platforms (S42) / Heading 2: Postings naming each lane platform, BD positions, 12 months plus live captures (S41) / Heading 2: Entity split of the 12 month postings / Heading 2: News feed events (S47), newest first, 123 events; feed only unless the Summary table says Read / Heading 2: Platform teams (S43) / Heading 1: Part I. Full URLs written out |
| `ws/deliverables/BD_Account_Summary.docx` | 60810 | DOCX; DOCX 29 headings, 14 tables; headings: Heading 1: How to read this file / Heading 1: 1. The account in plain words / Heading 2: The account picture / Heading 2: What stands out / Heading 2: What it likely means for each lane (interpretation labeled) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: 2. Recent news (newest first) / Heading 1: 3. Company and transformation baseline / Heading 1: 4. Signals / Heading 2: Tier 1, budget proximate / Heading 2: Tier 2, one step removed / Heading 2: Tier 3, context and openers / Heading 2: Context and history (older than the shelf life) / Heading 1: 5. Platform picture by lane / Heading 2: Platform hiring over 12 months (BD positions only, first seen 19 October 2025 to 19 October 2026) / Heading 1: 6. People / Heading 2: Key people (priority A and the executives the lanes report to) / Heading 2: Findings from profiles / Heading 2: People whose status changed / Heading 2: Interpretation / Heading 1: 7. Hypotheses to test / Heading 2: Cautions for sensitive findings / Heading 1: 8. Questions for a first conversation / Heading 1: 9. Research coverage tracker / Heading 2: Decisions waiting on the account owner / Heading 2: Pass 1, summary homework / Heading 2: Pass 2, detailed homework / Heading 1: 10. Source links |
| `ws/deliverables/BD_Job_Postings.xlsx` | 3051060 | XLSX; Summary=17 rows, Jobs=1898 rows |
| `ws/notes/` | 0 | file |
| `ws/notes/pull_log_phase1.md` | 20303 | MD |
| `ws/notes/pass1.md` | 2776 | MD |
| `ws/notes/sense_check.md` | 9870 | MD |
| `ws/RESTORE.md` | 3584 | MD |
| `ws/data/` | 0 | file |
| `ws/data/people_grid_rows.json` | 826335 | JSON; JSON array, 1484 records |
| `ws/data/teams.json` | 314007 | JSON; JSON object, 5 keys; arrays: params.organization_ids[1], params.attributes[5], teams[25] |
| `ws/data/live_board.json` | 55579 | JSON; JSON object, 8 keys; arrays: boards_found[1], keywords.Salesforce.urls_collected[92], keywords.Salesforce.page_urls[7], keywords.MuleSoft.urls_collected[3], keywords.MuleSoft.page_urls[1], keywords.ServiceNow.urls_collected[5], keywords.ServiceNow.page_urls[1], keywords.SAP.urls_collected[172], keywords.SAP.page_urls[12], keywords.Tableau.urls_collected[3], keywords.Tableau.page_urls[1], keywords.Veeva.urls_collected[12] |
| `ws/data/site_map_news.txt` | 20809 | TXT |
| `ws/data/company_searches.json` | 48611 | JSON; JSON object, 4 keys; arrays: searches[23] |
| `ws/data/connections.json` | 355629 | JSON; JSON object, 6 keys; arrays: query.categories[4], connections[1000] |
| `ws/data/techstack_confirmed.json` | 17479 | JSON; JSON object, 4 keys; arrays: business_functions.Engineering & R&D.Programming Languages and Frameworks[15], business_functions.Engineering & R&D.Cloud Vendor[3], business_functions.Engineering & R&D.CI/CD[5], business_functions.Engineering & R&D.Javascript Frameworks[6], business_functions.Engineering & R&D.Virtualization Technologies[2], business_functions.Data & Analytics.Business Intelligence[6], business_functions.Data & Analytics.Database Technologies[7], business_functions.Data & Analytics.Cloud Data Warehouse[5], business_functions.Data & Analytics.OLAP[4], business_functions.Data & Analytics.ETL[5], business_functions.AI & ML.Machine Learning Platforms and Tools[12], business_functions.AI & ML.Commercial Data Science[5] |
| `ws/data/leadership.json` | 4447 | JSON; JSON object, 8 keys; arrays: executives[18], board_partial_from_excerpt[6], announced_changes_not_yet_on_page[2] |
| `ws/data/org_signals.json` | 11551 | JSON; JSON object, 5 keys; arrays: signals[43] |
| `ws/data/techstack_detections.json` | 511244 | JSON; JSON object, 5 keys; arrays: detections[1022] |
| `ws/data/person_searches_B.json` | 364961 | JSON; JSON object, 4 keys; arrays: searches[79] |
| `ws/data/former_exec_checks.json` | 42353 | JSON; JSON object, 3 keys; arrays: checks[12] |
| `ws/data/releases/` | 0 | file |
| `ws/data/releases/2026-10-08_bd-to-announce-financial-results-for-its-fourth-quarter-and-.md` | 4852 | MD |
| `ws/data/releases/2025-08-21_bd-advanced-patient-monitoring-hosts-inaugural-patient-day-t.md` | 7288 | MD |
| `ws/data/releases/2026-10-19_live_98708250736_staff-devops-engineer-salesforce.md` | 18522 | MD |
| `ws/data/releases/2026-05-05_bd-and-wellstar-advance-patient-care-and-safety-with-medicat.md` | 9537 | MD |
| `ws/data/releases/person_deepak-jain_industry-magnates-interview.md` | 25951 | MD |
| `ws/data/releases/web_pwc-salesforce-purewick-ecommerce.md` | 4305 | MD |
| `ws/data/releases/2025-07-31_bd-aims-to-save-lives-by-empowering-women-with-choice-and-ac.md` | 38933 | MD |
| `ws/data/releases/2025-05-27_bd-to-present-at-goldman-sachs-46th-annual-global-healthcare.md` | 7553 | MD |
| `ws/data/releases/2025-10-09_bd-to-announce-financial-results-for-its-fourth-quarter-and-.md` | 5255 | MD |
| `ws/data/releases/2025-08-05_bd-businesses-become-first-in-medtech-to-achieve-hircs-diamo.md` | 8072 | MD |
| `ws/data/releases/2026-10-19_live_98693287184_financial-reporting-accountant.md` | 16067 | MD |
| `ws/data/releases/2026-04-28_bd-board-declares-dividend.md` | 3668 | MD |
| `ws/data/releases/2026-10-19_live_101319802192_supply-chain-production-planner.md` | 13354 | MD |
| `ws/data/releases/2026-10-19_live_101619706688_analista-planej-producao-pl.md` | 11624 | MD |
| `ws/data/releases/2026-10-19_live_101705939328_territory-manager-non-acute-remote-canada.md` | 18047 | MD |
| `ws/data/releases/2025-04-23_bd-launches-industry-first-bioabsorbable-mesh-designed-for-u.md` | 10084 | MD |
| `ws/data/releases/person_tom-polen_citeline-true-north-podcast.md` | 11212 | MD |
| `ws/data/releases/2026-10-19_live_101610557504_production-associate.md` | 11484 | MD |
| `ws/data/releases/2026-01-21_bd-and-ypsomed-expand-partnership-to-address-rapidly-growing.md` | 11100 | MD |
| `ws/data/releases/2026-09-10_bd-celebrates-30-years-of-innovation-and-shared-prosperity-i.md` | 7200 | MD |
| `ws/data/releases/2023-09-07_pwc-bd-ecommerce-transformation.md` | 13791 | MD |
| `ws/data/releases/2026-10-19_live_100950652576_field-service-engineer-tampa-fl.md` | 14638 | MD |
| `ws/data/releases/person_jim-sullivan_sapinsider-author.md` | 17929 | MD |
| `ws/data/releases/2026-10-19_live_101565949216_business-development-manager-beyond-hospital-care-.md` | 15183 | MD |
| `ws/data/releases/2026-10-19_live_99855913136_point-of-care-specialist-respiratory-sales.md` | 19935 | MD |
| `ws/data/releases/person_alex-armbruster_forma-revops-sales-comp-planning-panel.md` | 23887 | MD |
| `ws/data/releases/2025-10-09_bd-reaches-major-milestone-for-rotarex-tm-catheter-system-wi.md` | 10240 | MD |
| `ws/data/releases/person_nimi-ocholi_bd-blog-simpler-smarter-secure-care.md` | 2653 | MD |
| `ws/data/releases/2026-10-07_bd-strengthens-leadership-in-peripheral-vascular-innovation-.md` | 9457 | MD |
| `ws/data/releases/person_roland-goette_youtube-join-bd.md` | 2471 | MD |
| `ws/data/releases/person_giorgio-benigni_aboutpharma-in-buone-mani-podcast.md` | 16980 | MD |
| `ws/data/releases/2026-03-11_bd-and-sinteco-expand-advanced-robotics-offering-to-streamli.md` | 8397 | MD |
| `ws/data/releases/2026-10-19_live_101565948912_senior-manager-marketing-and-commercial-operations.md` | 17453 | MD |
| `ws/data/releases/2026-10-19_live_101916544720_auxiliar-administrativo-de-almacen.md` | 12652 | MD |
| `ws/data/releases/2026-10-19_live_100950639552_deployment-consultant-infusion-on-qc.md` | 17697 | MD |
| `ws/data/releases/2025-07-14_waters-and-bds-biosciences-diagnostic-solutions-business-to.md` | 34397 | MD |
| `ws/data/releases/2026-10-19_live_100773937760_field-service-technician-field-based-northern-va-d.md` | 15860 | MD |
| `ws/data/releases/2026-10-19_live_101561238720_senior-isc-data-scientist.md` | 12179 | MD |
| `ws/data/releases/2026-10-19_live_102041059472_territory-manager-research-academia.md` | 16570 | MD |
| `ws/data/releases/person_jeff-stevens_utahbusiness-needle-free.md` | 7009 | MD |
| `ws/data/releases/2026-10-19_live_101663218736_analyst-2-customer-contract-administration.md` | 12277 | MD |
| `ws/data/releases/2026-10-19_live_101610557520_production-associate.md` | 10836 | MD |
| `ws/data/releases/2026-10-19_live_101565945264_analista-fiscal-pl.md` | 12330 | MD |
| `ws/data/releases/2026-10-19_live_101619708608_clinical-specialist-atlanta-ga.md` | 15016 | MD |
| `ws/data/releases/person_bilal-muhsin_healthcaredive-qa.md` | 8501 | MD |
| `ws/data/releases/person_nimi-ocholi_medical-device-developments-2024-cyber-feature.md` | 19338 | MD |
| `ws/data/releases/2026-02-25_becton,-dickinson-and-company-announces-pricing-of-the-tende.md` | 14933 | MD |
| `ws/data/releases/person_frederique-pedretti-abel_european-medical-device-summit-2024.md` | 22145 | MD |
| `ws/data/releases/web_capgemini-mulesoft-integration.md` | 6487 | MD |
| `ws/data/releases/2026-10-19_live_101619711056_especialista-processos-industriais-pl.md` | 12447 | MD |
| `ws/data/releases/person_todd-dieckhoner_acuitymd-platform.md` | 5268 | MD |
| `ws/data/releases/2026-10-19_live_102168821504_customer-service-representative-18-month-fixed-ter.md` | 14698 | MD |
| `ws/data/releases/person_sunil-agarwal_rd-dynamics-mro-xpo-interview.md` | 6263 | MD |
| `ws/data/releases/2026-10-19_live_101705943328_operator-technician.md` | 14558 | MD |
| `ws/data/releases/person_bilal-muhsin_hospitals-magazine-gcc.md` | 13884 | MD |
| `ws/data/releases/2026-04-16_bd-earns-industry-top-honors-for-transparency,-resiliency-an.md` | 6374 | MD |
| `ws/data/releases/2026-01-12_bd-to-host-virtual-2026-annual-meeting-of-shareholders.md` | 5072 | MD |
| `ws/data/releases/2025-09-02_bd-expands-peripheral-artery-disease-awareness-efforts-with-.md` | 11112 | MD |
| `ws/data/releases/2026-04-07_when-every-beat-matters,-bd-helps-clinicians-eliminate-blind.md` | 9605 | MD |
| `ws/data/releases/2026-10-19_live_101899736768_area-sales-manager.md` | 13403 | MD |
| `ws/data/releases/person_miguel-crespo_sinet-new-york-2024-speakers.md` | 6060 | MD |
| `ws/data/releases/undated_servicenow-bd-riseup-customer-page.md` | 34849 | MD |
| `ws/data/releases/2026-09-29_bd-celebrates-70-years-of-manufacturing,-innovation-and-comm.md` | 8538 | MD |
| `ws/data/releases/person_elizabeth-mccombs_devicetalks-keynote.md` | 1078 | MD |
| `ws/data/releases/2026-02-04_bd-extends-leadership-in-connected-medication-management-win.md` | 6856 | MD |
| `ws/data/releases/2026-04-27_bd-and-suttons-creek-partner-to-help-pharma-and-biotech-comp.md` | 9978 | MD |
| `ws/data/releases/2026-10-19_live_98754724432_single-cell-multiomics-sales-specialist-us-south-c.md` | 18482 | MD |
| `ws/data/releases/person_bilal-muhsin_fierce-ai-healthcare.md` | 23319 | MD |
| `ws/data/releases/2026-10-19_live_101709231408_ingeniero-de-automatizacion-sr.md` | 13875 | MD |
| `ws/data/releases/2026-08-26_bd-to-present-at-wells-fargo-21st-annual-healthcare-conferen.md` | 4198 | MD |
| `ws/data/releases/2026-10-19_live_82761017392_manager-or-senior-analyst-fp-and-a.md` | 12454 | MD |
| `ws/data/releases/2026-10-06_bd-celebrates-65-years-of-manufacturing,-innovation-and-comm.md` | 10327 | MD |
| `ws/data/releases/person_tom-polen_devicetalks-growth-episode.md` | 1562 | MD |
| `ws/data/releases/2025-07-23_bd-announces-first-pharma-sponsored-clinical-trial-using-bd.md` | 12178 | MD |
| `ws/data/releases/2026-10-19_live_101619715552_regional-director-sales-apm.md` | 13410 | MD |
| `ws/data/releases/2026-10-06_bd-and-u-s-government-launch-landmark-partnership-to-expand-.md` | 12062 | MD |
| `ws/data/releases/2026-05-18_peter-menziuso-named-evp-and-president,-bd-interventional.md` | 6147 | MD |
| `ws/data/releases/2026-10-19_live_100628877088_field-service-engineer-colorado-springs-co.md` | 11366 | MD |
| `ws/data/releases/2026-10-19_live_101619714128_acheteur-bilingue-contrat-12-mois.md` | 17149 | MD |
| `ws/data/releases/2026-10-19_live_102041060576_molding-technician-i.md` | 14111 | MD |
| `ws/data/releases/2026-10-19_live_101748636336_associate-director-trade-compliance.md` | 19285 | MD |
| `ws/data/releases/person_pavan-mocherla_ceo-magazine-interview.md` | 6423 | MD |
| `ws/data/releases/2025-10-15_bd-announces-cfo-transition-plan.md` | 22616 | MD |
| `ws/data/releases/undated_bd-job-sr-software-engineering-manager-salesforce.md` | 18583 | MD |
| `ws/data/releases/person_frederique-pedretti-abel_bd-contamination-control-interview.md` | 19649 | MD |
| `ws/data/releases/2026-10-19_live_101748636752_gerente-de-ventas.md` | 15216 | MD |
| `ws/data/releases/person_pavan-mocherla_schoolofhr-ceo-dialogue.md` | 28473 | MD |
| `ws/data/releases/person_giorgio-benigni_youtube-lean-healthcare-award.md` | 1348 | MD |
| `ws/data/releases/person_paula-pizzi_boldjourney-interview.md` | 6871 | MD |
| `ws/data/releases/2025-10-08_the-bd-in-celebration-of-her-tm-program-surpasses-1-million-.md` | 7578 | MD |
| `ws/data/releases/person_denise-russell-fleming_cio-com-interview.md` | 13485 | MD |
| `ws/data/releases/person_tom-polen_devicetalks-boston-keynote-blog.md` | 10013 | MD |
| `ws/data/releases/person_greg-lusardi_antec-2018-molding-panel.md` | 8320 | MD |
| `ws/data/releases/2025-10-08_bd-and-opentrons-collaborate-to-accelerate-single-cell-multi.md` | 9006 | MD |
| `ws/data/releases/2026-01-14_bd-names-shawn-bevec-as-senior-vice-president-of-investor-re.md` | 6954 | MD |
| `ws/data/releases/web_yt-servicenow-university-trish-johnson.md` | 2313 | MD |
| `ws/data/releases/web_yt-connected-intelligence-beth-mccombs.md` | 19960 | MD |
| `ws/data/releases/2026-10-19_live_101319798832_senior-reconciliation-specialist.md` | 13367 | MD |
| `ws/data/releases/2026-04-27_bd-to-present-at-bank-of-america-securities-health-care-conf.md` | 4227 | MD |
| `ws/data/releases/person_miguel-crespo_sinet-ny-speaker-post.md` | 699 | MD |
| `ws/data/releases/2026-04-09_for-women-managing-nighttime-incontinence,-better-sleep-and-.md` | 9674 | MD |
| `ws/data/releases/2025-11-06_transcript-bd-q4-fy2025-earnings-call.md` | 57190 | MD |
| `ws/data/releases/2026-10-19_live_94317252704_business-planning-and-analysis-bp-and-a-global-fin.md` | 12784 | MD |
| `ws/data/releases/person_kathryn-kelly-mba-ms_ted-talk.md` | 3023 | MD |
| `ws/data/releases/2026-08-12_bd-accelerates-advanced-tissue-regeneration-strategy-with-la.md` | 6935 | MD |
| `ws/data/releases/person_todd-dieckhoner_medline-syringes.md` | 8076 | MD |
| `ws/data/releases/2026-10-19_live_102168830352_warehouse-operator.md` | 11627 | MD |
| `ws/data/releases/2026-02-25_becton,-dickinson-and-company-announces-early-tender-results.md` | 15738 | MD |
| `ws/data/releases/2026-10-19_live_101405713264_principal-indirect-sourcing-manager.md` | 16387 | MD |
| `ws/data/releases/2026-07-29_ems-and-bd-expand-access-to-glp-1-therapies-in-brazil-with-s.md` | 6968 | MD |
| `ws/data/releases/2026-02-09_bd-completes-combination-of-biosciences-diagnostic-solutions.md` | 9412 | MD |
| `ws/data/releases/person_tamer-elsockary_mlo-qa.md` | 6569 | MD |
| `ws/data/releases/2025-10-22_bd-simplifies-at-home-hpv-testing-to-broaden-access-to-cervi.md` | 7457 | MD |
| `ws/data/releases/person_carla-calizaire_home-page.md` | 1593 | MD |
| `ws/data/releases/2026-10-19_live_101090623472_quality-engineer-1-year.md` | 10052 | MD |
| `ws/data/releases/2026-10-19_live_100628874432_material-handler-iii.md` | 18395 | MD |
| `ws/data/releases/person_denise-russell-fleming_apple-podcasts-au.md` | 13419 | MD |
| `ws/data/releases/person_alex-armbruster_forma-sales-incentive-planning-webinar.md` | 9107 | MD |
| `ws/data/releases/2026-05-07_bd-reports-second-quarter-fiscal-2026-financial-results.md` | 57373 | MD |
| `ws/data/releases/person_diether-recktenwald_lehigh-particles-workshop-talk.md` | 5827 | MD |
| `ws/data/releases/2025-09-22_bd-and-henry-ford-health-sign-pharmacy-automation-partnershi.md` | 9397 | MD |
| `ws/data/releases/person_giorgio-benigni_spotify-ecosistema-della-salute.md` | 21350 | MD |
| `ws/data/releases/2026-10-19_live_98126988448_controls-specialist.md` | 18873 | MD |
| `ws/data/releases/2026-10-19_live_98708253712_hypo-north-production-associate-d-shift.md` | 14539 | MD |
| `ws/data/releases/person_todd-dieckhoner_businesswire-acuitymd.md` | 12074 | MD |
| `ws/data/releases/person_bilal-muhsin_hospitalsmagazine-interview.md` | 8860 | MD |
| `ws/data/releases/2025-05-12_bd-to-announce-financial-results-for-its-third-quarter-of-fi.md` | 7911 | MD |
| `ws/data/releases/person_denise-russell-fleming_bd-cybersecurity-awareness.md` | 6132 | MD |
| `ws/data/releases/2026-07-09_bd-to-announce-financial-results-for-its-third-quarter-of-fi.md` | 4754 | MD |
| `ws/data/releases/2026-10-19_live_99376909232_manufacturing-maintenance-technician.md` | 14830 | MD |
| `ws/data/releases/2025-11-25_bd-form-10-k-fy2025-item-1-business.md` | 50597 | MD |
| `ws/data/releases/2025-11-06_bd-board-increases-dividend-for-54th-consecutive-year.md` | 4747 | MD |
| `ws/data/releases/2025-10-20_bd-launches-new-ai-enabled-solutions-connectivity.md` | 8083 | MD |
| `ws/data/releases/2026-10-19_live_101043132128_tecnico-de-produccion.md` | 13841 | MD |
| `ws/data/releases/2025-11-06_bd-reports-fourth-quarter-and-full-year-fiscal-2025-financia.md` | 73279 | MD |
| `ws/data/releases/person_hermes-vallejo_zeno-tech-whisperers-episode.md` | 2369 | MD |
| `ws/data/releases/2025-07-30_bd-receives-fda-510k-clearance-for-rapid-point-of-care-covid.md` | 9201 | MD |
| `ws/data/releases/2026-10-19_live_47696043392_senior-specialist-sap-plm.md` | 11419 | MD |
| `ws/data/releases/2026-10-06_bd-appoints-ferass-abuzaina-as-worldwide-president-of-surger.md` | 5982 | MD |
| `ws/data/releases/person_elizabeth-mccombs_apple-podcasts-the-beat.md` | 13534 | MD |
| `ws/data/releases/2026-10-19_live_100356942192_senior-customer-service-rep.md` | 15968 | MD |
| `ws/data/releases/2025-08-04_bd-to-invest-35-million-in-nebraska-facility-to-expand-prefi_2.md` | 9584 | MD |
| `ws/data/releases/2026-10-19_live_94732473504_financial-analyst.md` | 17154 | MD |
| `ws/data/releases/person_miguel-crespo_hitec-ai-role-of-ciso-panel.md` | 44497 | MD |
| `ws/data/releases/2026-09-14_bd-advances-intelligent-robotics-to-transform-the-future-of-.md` | 9716 | MD |
| `ws/data/releases/person_pavan-mocherla_youtube-vgsom.md` | 7475 | MD |
| `ws/data/releases/2026-07-09_bd-named-to-times-2026-list-of-americas-best-companies.md` | 5294 | MD |
| `ws/data/releases/2025-11-12_bd-expands-purewick-tm-portfolio-with-first-of-its-kind-port.md` | 9315 | MD |
| `ws/data/releases/person_bilal-muhsin_newsweek-interview.md` | 29556 | MD |
| `ws/data/releases/2026-08-06_transcript-bd-q3-fy2026-earnings-call.md` | 73787 | MD |
| `ws/data/releases/2026-01-27_bd-board-declares-dividend,-authorizes-10-million-additional.md` | 5594 | MD |
| `ws/data/releases/2025-11-24_bd-surgiphor-tm-surgical-wound-irrigation-system-expands-to-.md` | 7743 | MD |
| `ws/data/releases/2026-04-27_capgemini-bd-global-integration-landscape.md` | 23787 | MD |
| `ws/data/releases/person_diether-recktenwald_smithsonian-cell-sorter-videohistory.md` | 30345 | MD |
| `ws/data/releases/2026-10-19_live_101405713248_procurement-manager.md` | 17034 | MD |
| `ws/data/releases/2025-11-17_bd-onclarity-tm-hpv-assay-for-bd-cor-tm-and-bd-viper-tm-lt-s.md` | 9981 | MD |
| `ws/data/releases/2026-10-19_live_101453743088_quality-associate-scientist.md` | 12577 | MD |
| `ws/data/releases/2026-10-19_live_100617062992_bd-2027-summer-internship-supply-chain-development.md` | 19485 | MD |
| `ws/data/releases/2025-04-29_bd-board-declares-dividend.md` | 34707 | MD |
| `ws/data/releases/2026-10-19_live_100723630112_marketing-operations-associate-mms.md` | 17618 | MD |
| `ws/data/releases/2026-10-19_live_101955697504_clinical-specialist-oncology-and-infusion-care-cha.md` | 18151 | MD |
| `ws/data/releases/2026-03-05_bd-advances-iliac-artery-treatment-across-the-european-union.md` | 7858 | MD |
| `ws/data/releases/2025-08-04_bd-to-invest-35-million-in-nebraska-facility-to-expand-prefi_3.md` | 8703 | MD |
| `ws/data/releases/2026-10-19_live_98574172320_product-lifecycle-engineer.md` | 17599 | MD |
| `ws/data/releases/undated_sap-bd-customer-story-video.md` | 2442 | MD |
| `ws/data/releases/2025-05-28_bd-to-initiate-real-world-patient-data-registry-for-the-rota.md` | 38094 | MD |
| `ws/data/releases/2026-02-09_bd-reports-first-quarter-fiscal-2026-financial-results.md` | 46307 | MD |
| `ws/data/releases/2026-04-30_bd-achieves-excellence-in-employee-well-being,-earning-top-i.md` | 7331 | MD |
| `ws/data/releases/2026-10-19_live_101748630192_hr-service-delivery-operations-specialist.md` | 17527 | MD |
| `ws/data/releases/2025-07-07_bd-appoints-bilal-muhsin-as-executive-vice-president-and-pre.md` | 10351 | MD |
| `ws/data/releases/2026-07-22_mike-garrison-to-retire-from-bd.md` | 5411 | MD |
| `ws/data/releases/2026-10-19_live_99855919504_lead-tech-mechanical-engineer.md` | 14952 | MD |
| `ws/data/releases/2026-10-19_live_102168823456_customer-service-representative.md` | 14507 | MD |
| `ws/data/releases/undated_veeva-bd-clinical-trials-customer-story.md` | 3293 | MD |
| `ws/data/releases/2025-04-30_bd-to-present-at-bank-of-america-securities-health-care-conf.md` | 35084 | MD |
| `ws/data/releases/2023-08-17_servicenow-bd-riseup-story-pdf.md` | 7636 | MD |
| `ws/data/releases/person_roland-goette_pharmaboardroom-interview.md` | 11492 | MD |
| `ws/data/releases/2026-02-09_transcript-bd-q1-fy2026-earnings-call.md` | 55161 | MD |
| `ws/data/releases/2026-01-23_bd-helps-scientists-advance-immunology-and-cancer-research-w.md` | 8435 | MD |
| `ws/data/releases/web_veeva-clinical-etmf-ctms.md` | 754 | MD |
| `ws/data/releases/2026-10-19_live_98122382976_assistant-manager-business-analytics.md` | 16855 | MD |
| `ws/data/releases/2026-05-07_transcript-bd-q2-fy2026-earnings-call.md` | 65786 | MD |
| `ws/data/releases/person_tom-polen_devicetalks-castos-boston-keynote.md` | 4185 | MD |
| `ws/data/releases/2026-10-19_live_99762872208_maintenance-technician-ii.md` | 16827 | MD |
| `ws/data/releases/2026-06-23_bd-awarded-another-program-account-innovative-technology-contract-for-centro.md` | 9235 | MD |
| `ws/data/releases/2025-11-17_bd-appoints-robert-huffines-and-jacqueline-wright-to-board-o.md` | 9607 | MD |
| `ws/data/releases/2025-09-12_bd-provides-update-on-voluntary-recall-of-certain-bd-alaris-.md` | 7369 | MD |
| `ws/data/releases/2025-09-17_bd-marks-1,000th-bd-rhapsody-system,-driving-scientific-brea.md` | 9181 | MD |
| `ws/data/releases/web_veeva-promomats-claims.md` | 548 | MD |
| `ws/data/releases/2026-08-27_bd-extends-leadership-in-advanced-tissue-regeneration-throug.md` | 10485 | MD |
| `ws/data/releases/person_denise-russell-fleming_podscan-tech-whisperers.md` | 15522 | MD |
| `ws/data/releases/2025-08-14_bd-to-present-at-wells-fargo-2025-healthcare-conference.md` | 4428 | MD |
| `ws/data/releases/person_nimi-ocholi_bd-chime-cyber-webinar-part2.md` | 5681 | MD |
| `ws/data/releases/2026-10-19_live_95939905600_associate-director-global-supply-planning.md` | 19579 | MD |
| `ws/data/releases/2026-10-19_live_97925230784_process-engineer.md` | 14976 | MD |
| `ws/data/releases/2026-10-19_live_101137440784_senior-manager-global-marketing-communications-spe.md` | 16188 | MD |
| `ws/data/releases/2026-08-06_bd-reports-third-quarter-fiscal-2026-financial-results.md` | 56276 | MD |
| `ws/data/releases/person_nimi-ocholi_bd-chime-cyber-webinar-part1.md` | 7991 | MD |
| `ws/data/releases/2026-10-19_live_101610557488_production-associate.md` | 11537 | MD |
| `ws/data/releases/2025-12-08_bd-showcases-innovation-in-connected-medication-management-a.md` | 8015 | MD |
| `ws/data/releases/2026-10-08_bd-and-global-health-leaders-call-for-accelerated-maternal-l.md` | 9856 | MD |
| `ws/data/releases/2025-08-04_bd-to-invest-35-million-in-nebraska-facility-to-expand-prefi.md` | 10849 | MD |
| `ws/data/releases/2026-10-19_live_99784696128_lead-design-engineer.md` | 20343 | MD |
| `ws/data/releases/person_tom-polen_bd-devicetalks-keynote.md` | 2985 | MD |
| `ws/data/releases/2026-10-19_live_101090623600_quality-control-representative-d-shift.md` | 11823 | MD |
| `ws/data/releases/2026-07-31_bd-issues-nationwide-recall-for-specific-lots-of-bd-r-intrao.md` | 7863 | MD |
| `ws/data/releases/2026-09-21_arthur-hu-to-join-bd-as-chief-information-and-digital-office.md` | 6812 | MD |
| `ws/data/releases/person_denise-russell-fleming_apple-podcasts-zh.md` | 13326 | MD |
| `ws/data/releases/person_bilal-muhsin_gulf-business-interview.md` | 11065 | MD |
| `ws/data/releases/2025-10-03_bd-celebrates-55-years-of-manufacturing-excellence-and-impac.md` | 9597 | MD |
| `ws/data/releases/person_manish-sinha_hcli-local-to-global-leader.md` | 2295 | MD |
| `ws/data/releases/2025-08-07_bd-reports-third-quarter-fiscal-2025-financial-results.md` | 78235 | MD |
| `ws/data/releases/2026-01-29_bd-and-envetec-demonstrate-closed-loop-recycling-solution-fo.md` | 7899 | MD |
| `ws/data/releases/2026-10-19_live_102041053296_planeador-comprador.md` | 12599 | MD |
| `ws/data/releases/2026-08-17_bd-appoints-gary-sorsher-as-chief-quality-officer-jeff-silve.md` | 6511 | MD |
| `ws/data/releases/2026-10-19_live_96217644336_director-marketing-data-and-analytics.md` | 25205 | MD |
| `ws/data/releases/person_giorgio-benigni_meetingrimini-panel-video.md` | 47289 | MD |
| `ws/data/releases/2025-11-20_bd,-nafc-and-medshare-expand-health-access,-bring-critical-u.md` | 11253 | MD |
| `ws/data/releases/2026-02-19_lanesha-minnix-named-general-counsel-for-bd.md` | 5957 | MD |
| `ws/data/releases/2026-10-19_live_100158166656_hypo-north-production-assoicate.md` | 14981 | MD |
| `ws/data/releases/2026-10-19_live_102168830320_warehouse-operator.md` | 11628 | MD |
| `ws/data/releases/2026-02-23_bd-to-present-at-barclays-28th-annual-global-healthcare-conf.md` | 4219 | MD |
| `ws/data/releases/2025-07-22_bd-board-declares-dividend.md` | 7122 | MD |
| `ws/data/releases/2025-10-16_bd-looks-ahead-to-the-next-era-of-manufacturing-excellence-i.md` | 10341 | MD |
| `ws/data/releases/person_sandeep-arora_retailcioconnect-speaker.md` | 1038 | MD |
| `ws/data/releases/2025-12-15_bd-expands-bd-max-tm-system-menu-with-new-ivdr-certified-via.md` | 9329 | MD |
| `ws/data/releases/2026-04-09_rick-byrd-to-retire-from-bd.md` | 5325 | MD |
| `ws/data/releases/2026-10-19_live_100378013488_molding-electro-mechanical-technician-a-shift.md` | 14711 | MD |
| `ws/data/releases/2026-07-01_bd-appoints-matthew-sassone-as-worldwide-president-of-pharma.md` | 5709 | MD |
| `ws/data/releases/2026-10-19_live_102168830368_warehouse-operator.md` | 11626 | MD |
| `ws/data/releases/2026-10-19_live_100432595600_procedural-specialist.md` | 17394 | MD |
| `ws/data/releases/2017-07-31_veeva-9-of-top-15-medtech-move-to-vault.md` | 7491 | MD |
| `ws/data/releases/2026-05-07_bd-appoints-vitor-roque-chief-financial-officer.md` | 6439 | MD |
| `ws/data/releases/2026-01-27_bd-announces-record-date-for-the-spin-off-of-its-biosciences.md` | 15916 | MD |
| `ws/data/releases/2026-10-19_live_98693287136_financial-reporting-senior-accountant.md` | 16646 | MD |
| `ws/data/releases/2026-01-27_bd-to-announce-financial-results-for-its-first-quarter-of-fi.md` | 5209 | MD |
| `ws/data/releases/2025-05-13_bd-launches-landmark-cell-analyzer-featuring-breakthrough-sp.md` | 11570 | MD |
| `ws/data/releases/2026-04-24_capgemini-bd-client-story-pdf.md` | 7821 | MD |
| `ws/data/releases/person_elizabeth-mccombs_devicetalks-castos-cto-episode.md` | 3807 | MD |
| `ws/data/releases/2026-10-19_live_102168830720_territory-manager-breast-and-plastic-surgery-south.md` | 16185 | MD |
| `ws/data/releases/person_todd-dieckhoner_acuitymd-talk-to-an-expert.md` | 2673 | MD |
| `ws/data/releases/2026-03-06_bd-named-a-top-100-global-innovator-by-lexisnexis.md` | 6950 | MD |
| `ws/data/releases/person_sandeep-arora_ssow-autumn-speaker.md` | 2035 | MD |
| `ws/data/releases/2026-01-19_bd-to-highlight-advanced-biologics-and-large-volume-delivery.md` | 11658 | MD |
| `ws/data/releases/2025-04-21_bd-launches-next-generation-hemodynamic-monitoring-solution.md` | 11496 | MD |
| `ws/data/releases/2026-10-19_live_99721418128_account-manager-md-and-northern-va.md` | 19729 | MD |
| `ws/data/releases/2026-10-19_live_100110267872_sr-international-specialist.md` | 13967 | MD |
| `ws/data/releases/web_yt-quip-one-bd-account-team.md` | 3256 | MD |
| `ws/data/releases/2026-03-02_bd-pioneers-new-standard-in-surgical-safety-with-fda-cleared.md` | 7150 | MD |
| `ws/data/releases/2025-11-18_icn-and-bd-foundation-empower-nursing-leadership-across-lati.md` | 7976 | MD |
| `ws/data/releases/2026-10-19_live_101933769088_hypo-north-production-associate-3rd-shift.md` | 15220 | MD |
| `ws/data/releases/2026-01-05_bd-marks-milestone-with-first-phasix-tm-hernia-prevention-ca.md` | 8367 | MD |
| `ws/data/releases/2026-04-09_bd-to-announce-financial-results-for-its-second-quarter-of-f.md` | 4756 | MD |
| `ws/data/releases/web_asug-sap-commerce-cloud.md` | 12028 | MD |
| `ws/data/releases/2025-10-20_bd-launches-new-ai-enabled-solutions-to-drive-connectivity-a.md` | 9295 | MD |
| `ws/data/releases/2026-04-08_bd-delivers-next-generation-tips-innovation-to-advance-porta.md` | 9152 | MD |
| `ws/data/releases/person_mike-roby_leading-with-balanced-positivity.md` | 3466 | MD |
| `ws/data/releases/2026-10-19_live_98833518016_laboratoriumi-technikus.md` | 14535 | MD |
| `ws/data/releases/person_mike-roby_michaelroby-speaking-page.md` | 4738 | MD |
| `ws/data/releases/2025-11-03_bd-receives-fda-510-k-clearance-and-ce-ivdr-certification-fo.md` | 10337 | MD |
| `ws/data/releases/web_servicenow-bd-riseup.md` | 7100 | MD |
| `ws/data/releases/2025-12-03_bd-launches-new-cell-analyzer-configurations-to-bring-cuttin.md` | 8997 | MD |
| `ws/data/releases/person_denise-russell-fleming_youtube-tech-whisperers.md` | 52216 | MD |
| `ws/data/releases/2026-01-15_bd-receives-fda-510-k-clearance-for-encor-encompass-tm-breas.md` | 10243 | MD |
| `ws/data/releases/2026-10-19_live_100012216144_termelesi-biokemikus-konjugacio.md` | 14936 | MD |
| `ws/data/releases/person_vitor-roque_yahoo-q2-fy2026-call.md` | 2434 | MD |
| `ws/data/releases/person_frederique-pedretti-abel_elemed-podcast.md` | 1723 | MD |
| `ws/data/releases/2025-05-21_cancer-patients-face-elevated-risk-of-carrying-antimicrobial.md` | 11936 | MD |
| `ws/data/releases/2026-01-13_bd-announces-110-million-to-support-u-s-pharmaceutical-suppl.md` | 10434 | MD |
| `ws/data/releases/2026-07-28_bd-board-declares-dividend.md` | 3672 | MD |
| `ws/data/releases/person_carla-calizaire_speaking-engagements.md` | 4981 | MD |
| `ws/data/releases/person_tom-polen_bd-devicetalks-podcast.md` | 2301 | MD |
| `ws/data/releases/2026-10-19_live_101751812704_hypo-north-production-associate.md` | 14588 | MD |
| `ws/data/releases/2025-12-04_bd-and-chemoglo-tm-collaborate-to-expand-hazardous-drug-cont.md` | 10589 | MD |
| `ws/data/releases/2026-10-19_live_100939541456_consultant-en-deploiement-bilingue-bilingual-deplo.md` | 20886 | MD |
| `ws/data/releases/2026-10-19_live_99110440304_accounts-receivable-service-delivery-lead.md` | 16398 | MD |
| `ws/data/releases/2026-10-19_live_101565944752_analista-fiscal-sr.md` | 11721 | MD |
| `ws/data/releases/2026-10-19_live_101362059872_senior-international-regulatory-affairs-specialist.md` | 16083 | MD |
| `ws/data/releases/2026-05-21_bd-delivers-kidney-stone-care-for-urology-teams-with-the-ely.md` | 8386 | MD |
| `ws/data/releases/person_elizabeth-mccombs_devicetalks-boston-speaker.md` | 3765 | MD |
| `ws/data/releases/person_tom-polen_youtube-medtech-pov.md` | 45127 | MD |
| `ws/data/releases/2026-10-19_live_96589556448_tender-and-contract-specialist-gsa-m-f-d.md` | 10434 | MD |
| `ws/data/releases/2026-04-01_bd-launches-ai-enabled-medication-dispensing-system-to-the-e.md` | 8544 | MD |
| `ws/data/releases/2026-02-10_becton,-dickinson-and-company-announces-tender-offers-for-ou.md` | 15399 | MD |
| `ws/data/releases/person_pavan-mocherla_ceo-magazine-listing.md` | 11007 | MD |
| `ws/data/releases/2025-12-18_bd-and-penn-institute-for-immunology-and-immune-health-colla.md` | 9203 | MD |
| `ws/data/releases/person_saurabh-patel_digital-marketing-asia-speaker.md` | 1559 | MD |
| `ws/data/releases/2026-10-19_live_101619715472_lider-tecnico-manutencao.md` | 12047 | MD |
| `ws/data/releases/2026-10-19_live_101575435744_field-service-technician.md` | 10444 | MD |
| `ws/data/releases/2026-10-19_live_101090623264_set-up-operator.md` | 14020 | MD |
| `ws/data/releases/2026-04-29_bd-reimagines-central-line-insertion,-advancing-leadership-i.md` | 11481 | MD |
| `ws/data/releases/2025-05-01_bd-reports-second-quarter-fiscal-2025-financial-results.md` | 101825 | MD |
| `ws/data/releases/2026-10-19_live_102041057520_account-manager-sm-luzon.md` | 15074 | MD |
| `ws/data/releases/2026-10-19_live_102168826656_technical-support-specialist-2.md` | 15421 | MD |
| `ws/data/releases/2025-11-13_duncan-regional-hospital-becomes-first-in-u-s-to-implement-b.md` | 14500 | MD |
| `ws/data/releases/2026-10-19_live_100950654096_senior-project-manager-bc-al-on-based.md` | 16568 | MD |
| `ws/data/releases/2026-10-19_live_99677188816_lead-qa-engineer.md` | 17528 | MD |
| `ws/data/releases/2026-10-19_live_102041057888_tecnico-de-produccion.md` | 13792 | MD |
| `ws/data/releases/2026-10-19_live_102168814544_asistente-de-contabilidad.md` | 12689 | MD |
| `ws/data/releases/2026-10-19_live_100758736896_cost-accounting-manager.md` | 14529 | MD |
| `ws/data/releases/2026-02-23_bd-expands-testing-capabilities-to-help-clinicians-improve-d.md` | 8116 | MD |
| `ws/data/releases/2025-11-04_bd-achieves-milestone-in-agility-study-of-revello-tm-vascula.md` | 8607 | MD |
| `ws/data/posts_comments.json` | 9976550 | JSON; JSON object, 7 keys; arrays: records[500] |
| `ws/data/org_resolve.json` | 708 | JSON; JSON object, 9 keys; arrays: subsidiary_ids[17] |
| `ws/data/transcripts_index.json` | 1696 | JSON; JSON object, 3 keys; arrays: calls[4], filings[1] |
| `ws/data/people_grid.txt` | 527859 | TXT |
| `ws/data/web_searches.json` | 4508 | JSON; JSON array, 8 records |
| `ws/data/jobs_12mo.json` | 50486152 | JSON; JSON object, 5 keys; arrays: jobs[7148] |
| `ws/data/subsidiary_domains.json` | 278342 | JSON; JSON object, 3 keys; arrays: domains.bd.jobs.tech_24mo.rows[35], domains.bdbiosciences.com.jobs_12mo.rows[47], domains.bdbiosciences.com.tech_24mo.rows[201], domains.flowjo.com.tech_24mo.rows[59] |
| `ws/data/people_gapcheck.json` | 3367 | JSON; JSON object, 4 keys; arrays: params_common.job_function[4], params_common.job_level[5], params_common.attributes[4], lanes.MuleSoft.people[1], lanes.ServiceNow.people[1], lanes.Tableau.people[7], lanes.Veeva.people[0] |
| `ws/data/company_record.json` | 972 | JSON; JSON object, 11 keys; arrays: subsidiary_domains_reported[5], similar_companies_reported[5], locations_reported[9] |
| `ws/data/profiles_full.json` | 11193436 | JSON; JSON object, 4 keys; arrays: profiles[1484] |
| `ws/data/person_searches_A.json` | 416677 | JSON; JSON object, 5 keys; arrays: searches[78], notes[1] |
| `ws/data/releases_gap_2025.json` | 7239 | JSON; JSON object, 3 keys; arrays: listing_pages[9], releases[17] |
| `ws/data/news_events.json` | 181154 | JSON; JSON object, 5 keys; arrays: events[123] |
| `ws/build/` | 0 | file |
| `ws/build/classify.py` | 2771 | PY |
| `ws/build/profile_findings.py` | 7409 | PY |
| `ws/build/people_named.json` | 3575 | JSON; JSON array, 11 records |
| `ws/build/classify2.py` | 2287 | PY |
| `ws/build/lane_rows.json` | 1343528 | JSON; JSON array, 1587 records |
| `ws/build/profile_findings.json` | 23249 | JSON; JSON object, 15 keys; arrays: prior_employers.Johnson & Johnson[2], prior_employers.Medtronic[2], prior_employers.Stryker[2], prior_employers.Deloitte[2], prior_employers.Boston Scientific[2], prior_employers.Baxter[2], prior_employers.Siemens[2], prior_employers.IBM[2], prior_employers.PwC[2], prior_employers.Pfizer[2], prior_employers.Novartis[2], prior_employers.EY[2] |
| `ws/build/build_summary.js` | 13299 | JS |
| `ws/build/evidence_extra.py` | 27339 | PY |
| `ws/build/build_evidence.js` | 7393 | JS |
| `ws/build/docx_lib.js` | 4575 | JS |
| `ws/build/content.json` | 138276 | JSON; JSON object, 27 keys; arrays: pf.prior_employers.Johnson & Johnson[2], pf.prior_employers.Medtronic[2], pf.prior_employers.Stryker[2], pf.prior_employers.Deloitte[2], pf.prior_employers.Boston Scientific[2], pf.prior_employers.Baxter[2], pf.prior_employers.Siemens[2], pf.prior_employers.IBM[2], pf.prior_employers.PwC[2], pf.prior_employers.Pfizer[2], pf.prior_employers.Novartis[2], pf.prior_employers.EY[2] |
| `ws/build/stack_names.json` | 2644 | JSON; JSON array, 188 records |
| `ws/build/platform_ranking_bd.py` | 10969 | PY |
| `ws/build/drop_salesforce.json` | 648 | JSON; JSON array, 6 records |
| `ws/build/content.py` | 72180 | PY |
| `ws/build/ids.json` | 822 | JSON; JSON array, 120 records |
| `ws/build/build_stack.py` | 4741 | PY |
| `ws/build/people_merged.json` | 297657 | JSON; JSON array, 736 records |
| `ws/build/checked.json` | 32 | JSON; JSON array, 3 records |
| `ws/build/people_excluded.json` | 16416 | JSON; JSON object, 4 keys; arrays: domain[120], security[29], unresolved[1], below_rule_no_stack[605] |
| `ws/build/build_[redacted]_only.js` | 3491 | JS |
| `ws/build/jobs_bd.json` | 42704282 | JSON; JSON array, 6552 records |
| `ws/build/evidence_extra.json` | 80430 | JSON; JSON object, 6 keys; arrays: extracts[21], live_rows[92], leads[13], detections[147], news_events[123] |
| `ws/build/build_jobs.py` | 8364 | PY |
| `ws/build/decisions.py` | 17418 | PY |
| `ws/build/jobs_all.json` | 48491400 | JSON; JSON array, 7237 records |
| `ws/build/jobs_lane_rows_final.json` | 14720344 | JSON; JSON array, 1897 records |
| `ws/build/prep_jobs.py` | 3547 | PY |
| `ws/build/build_people.py` | 17869 | PY |
