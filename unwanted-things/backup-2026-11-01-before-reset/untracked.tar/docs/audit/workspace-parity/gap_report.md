# Gap report: legacy workspace parity versus this repository

Audit date: 2026-11-01. Ordered by impact on the requested parity target.

Phase 2 update (2026-11-01): bounded raw ZIP inspection/upload, partial config derivation,
backend-owned delivered-summary counts, parsed source views for the five deliverables, paged
workbook reads and an audited client-only deliverables ZIP are implemented. The import remains
explicitly incomplete until the rest of the legacy config and transformation rules are derived.
The current import/Ask/parity regression set passed against a disposable local PostgreSQL instance
(903 tests), and the broader `tests/parity` suite passed (153 passed, 6 skipped); the skips include
the repository's ignored reference-workspace fixture, which is absent here. Frontend typecheck,
lint and parity screen tests passed. The archive scanner
identified all five deliverable roles in each of the 11 available workspace ZIPs; GSK's historical
deliverables copy is now disambiguated by preferring a complete role set in the active RESTORE
root's `deliverables/` directory. This scan is not a golden replay. The BD golden replay still has
two unresolved Jobs description cells, and the other workspaces have not been regenerated and
compared. ZIP path validation rejects normalized dot/empty path segments and nested Office packages
receive full CRC validation. The tenant isolation matrix passed (564 tests). The first full backend
run reported 7,436 passed, 7 skipped, 1 xfailed and 14 failures; a 201-test recovery set covering
those failure groups passed after fixes, but the complete suite has not been rerun.

| Priority | Gap / finding | Evidence | Assessment |
|---|---|---|---|
| Critical | The prompt calls the target Madrid, while this approved checkout is the multi-tenant account-intelligence product. Its prior library flow accepted finished deliverables, not raw `RESTORE.md` + `data/` + `build/` archives. | `src/account_intelligence/replica/library.py::inspect_package`, `store_upload`; `src/account_intelligence/api/routes/library.py::library_upload`; `docs/repair/workspace_repair_spec.md` | User approved this checkout as the target. The raw-workspace feature is being adapted to the existing account/tenant model; full parity remains a large product-scope addition. |
| Explained, not a code defect | The isolated BD restore reproduces four deliverables exactly; two `Full description` cells differ in the Jobs workbook (`Jobs!M81`, `Jobs!M98`). | `inventory.md`; `src/parity/compare_workspace.py`; archive `ws/build/jobs_lane_rows_final.json` | Traced 2026-11-01: the archive's own intermediate `jobs_lane_rows_final.json` holds the same text the rebuild produces for requisitions R-545751 and R-551677 (22,295 and 17,888 characters, starting with the page header). The shipped workbook holds a different, earlier capture of those two postings (22,296 and 17,889 characters, starting mid-page). The shipped file was therefore built from posting text that the archive no longer contains, so the two cells cannot be reproduced from the archive's inputs by any transform. The import path serves the shipped cells as delivered. |
| Resolved for source browsing | Imported workspaces now have a read API for summary/news/evidence and paged workbook sheets, plus client-deliverables download. These views show the shipped source outputs and do not establish regenerated parity. | `src/account_intelligence/api/routes/account_workspace.py::workspace_import_view`, `download_workspace_import` | Source browsing is ready; normalized entity/query APIs and generated deliverables remain missing. |
| Resolved for delivered parity counts | Frontend used to derive Summary values from loaded bundle rows. It now renders `computed_summary` and `summary_mismatches` returned by `GET .../parity/screen`; the API no longer sends count-row projections to the client. | `src/parity/counts.py::summary_values`, `src/account_intelligence/api/routes/parity.py::parity_screen`, `web/components/accounts/ParityWorkspace.tsx` | This closes the delivered-screen count gap. Raw-workspace views and chat parity remain incomplete. |
| High | A conservative canonical Ask path matches supported compiled queries and calculates results against owner-private imported rows. It supports simple Jobs/People filters plus rank-group summaries from the imported Platform Ranking sheet. RESTORE date windows and Waters pre-close counts remain unsupported; ambiguous or unsupported queries fall back to normal Ask. | `src/account_intelligence/replica/workspace_queries.py::evaluate_canonical_query`, `_reply`; `src/exports/repair/canonical.py::compile_restore_queries`; `tests/replica/test_workspace_import_api.py::test_ask_uses_computed_canonical_counts_from_imported_workspace_rows` | Synthetic integration coverage proves row-derived strict zero/relaxed answers and rank labels come from the imported sheets rather than RESTORE's declared answer. This does not establish full canonical parity. |
| High | The requested BM25 + dense retrieval + rank fusion for textual evidence was not verified in the workspace parity path. | Search in replica/chat route and `docs/guide/03-code-map.md`; no matching hybrid pipeline evidence reviewed | Text retrieval/citations need an explicit map and acceptance test. |
| High | Legacy output columns, heading tree, Parts A–I, section order, writing rules, and original RESTORE build sequence are not fully reproduced by the generic repair package contract. | `docs/parity/reference_spec.md`, `docs/repair/workspace_repair_spec.md`, `src/exports/repair/core.py`; BD/GSK inventory differences | The two output contracts differ materially; exact legacy compatibility remains incomplete/unproven. |
| Medium | A schema-validated partial import config includes RESTORE facts, recognized simple query predicates, JSON build controls and selected literal platform/lane constants from allowlisted Python ASTs; notes-only rules, dynamic expressions, complete job/people rules and query windows remain un-derived. | `src/parity/schema/workspace_config.schema.json`, `src/parity/schema/workspace_import.schema.json`, `src/exports/repair/ingest.py::_build_config_facts`, `src/exports/repair/canonical.py::compile_restore_queries` | Import responses say `incomplete`; the full candidate schema is not yet populated or validated against every canonical answer. |
| Medium | The audit inventories every unique archive found in Downloads, but only BD's original restore scripts were run in an isolated no-network/no-secrets sandbox; other golden output comparisons remain incomplete. | `inventory.md`; per-archive inventory files | Existing workbook replay is not equivalent to the original build sequence; no exact reproduction claim is made. |
| Resolved for import API slice | Owner and tenant isolation is implemented with forced RLS and account object prefixes; the account owner's upload, colleague refusal and cross-tenant behavior passed in the fresh-DB integration suite. | `migrations/0098_workspace_imports.sql`; `src/tenancy/storage.py::account_path`; `tests/replica/test_workspace_import_api.py` | This closes the import API isolation gap. Broader archive-view and full parity tests remain outstanding. |

## Backend and frontend status against requested feature set

| Feature | Status |
|---|---|
| Safe intake of a completed deliverable package | Exists for library uploads with member/count/size checks and client-ready scans. |
| Raw workspace zip ingestion, config extraction, versioning, source views and validation report | Partial: bounded non-executing inspection, account-scoped storage/versioning, parsed deliverable views and download exist; extracted config is a schema-validated subset and every import is explicitly incomplete. |
| Generic deterministic repair tables and checks | Exists for stored normalized records and offline export repair. |
| Normalized store keyed by workspace ID for every requested legacy entity | Current model uses tenant/account/run and parity bundle; no evidence of all proposed tables under one workspace ID. |
| Deliverable parity against arbitrary original workspaces | Partial; parity bundle compares/serves product outputs, while old reference replays and tests exist but do not prove all archive variants. |
| Frontend file-shaped output views | Exists for delivered parity bundle tabs and table views; imported workspaces also show source DOCX/XLSX views and a client-only download. |
| Backend-owned counts with no UI calculation | Delivered parity screen counts now come from the backend and are compared there with manifest values. Legacy workspace canonical-query coverage remains missing. |
| Deterministic canonical chat numbers and strict-zero then relaxed answer | Partial: supported queries use imported typed tables and cite the workbook; unsupported query shapes and universal RESTORE coverage remain unverified. |
| Deep-mode output through same legacy workspace ingestion pipeline | Missing/unverified. |
| Acceptance gate over all local raw workspace zips and previously unseen zip | Missing for the requested contract. |
