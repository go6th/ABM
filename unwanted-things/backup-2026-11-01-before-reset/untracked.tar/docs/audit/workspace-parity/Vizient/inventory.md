# Inventory: Vizient

Files: 41; total 587 KB

Top level: `(root)` (2), `build` (7), `data` (24), `deliverables` (5), `notes` (3)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 2217 | 25 lines |
| `build/build_jobs.py` | 10078 | 94 lines |
| `build/build_people.py` | 16561 | 160 lines |
| `build/build_stack.py` | 4983 | 57 lines |
| `build/evidence.js` | 18154 | 105 lines |
| `build/summary.js` | 39177 | 204 lines |
| `build/tracker.py` | 7675 | 42 lines |
| `build/urls.js` | 15543 | 106 lines |
| `data/jobs_12mo_lanes.json` | 23210 | dict[5 keys]: source,queries,total_all_primary_lanes,jobs,dedupe_note |
| `data/jobs_hidden_titles.json` | 16831 | dict[3 keys]: source,jobs,counts |
| `data/live_board.json` | 11342 | dict[4 keys]: careers_site,keywords,search_note,read_queue |
| `data/news_events.json` | 9089 | dict[4 keys]: query,reported_count,feed_note,events |
| `data/newsroom.json` | 12506 | dict[5 keys]: source,note,release_urls,other_urls_of_interest,newsroom_page1 |
| `data/org_signals.json` | 79 | dict[3 keys]: lane_filtered,unfiltered,note |
| `data/people_grid.json` | 54252 | dict[4 keys]: grid,pass1_matched,pass2_matched,rows |
| `data/people_grid_raw.psv` | 19562 |  |
| `data/postings/446720262784.md` | 2257 | 12 lines |
| `data/postings/446720262784_full.md` | 3741 | 17 lines |
| `data/postings_read.psv` | 8557 |  |
| `data/posts_extract.json` | 27220 | dict[4 keys]: source,rule,rows_with_posts,items |
| `data/posts_raw.psv` | 7334 |  |
| `data/profiles_compact.psv` | 5882 |  |
| `data/profiles_extract.md` | 23319 | 145 lines |
| `data/releases/r01_invest_1b_2026-09-23.md` | 1297 | 11 lines |
| `data/releases/r02_empierus_2026-06-11.md` | 848 | 8 lines |
| `data/releases/r03_arun_ramasubramanian_2025-06-23.md` | 757 | 6 lines |
| `data/releases/r04_sxanpro_2026-09-17.md` | 496 | 5 lines |
| `data/releases/r05_governance_board.md` | 1063 | 5 lines |
| `data/stack_org_metrics.json` | 1648 | dict[3 keys]: org,lane_metrics_all_time,note |
| `data/teams.json` | 5832 | dict[5 keys]: query,total_teams_matching,returned,teams,note |
| `data/techstack_confirmed.json` | 2992 | dict[4 keys]: org_id,measure,stack,note |
| `data/web_searches.json` | 15010 | list[16] |
| `deliverables/Vizient_Account_Summary.docx` | 53143 | ERR AttributeError |
| `deliverables/Vizient_Job_Postings.xlsx` | 31813 | Summary=21x9; Jobs=207x11 |
| `deliverables/Vizient_People_List.xlsx` | 35311 | Summary=33x6; People=221x12 |
| `deliverables/Vizient_Sources_and_Evidence.docx` | 65785 | ERR AttributeError |
| `deliverables/Vizient_Tech_Stack_and_Teams.xlsx` | 12623 | Summary=17x6; Confirmed stack=123x4; Platform teams=26x5 |
| `notes/handoff.md` | 1834 | 15 lines |
| `notes/pass1.md` | 1423 | 16 lines |
| `notes/sense_check.md` | 12608 | 102 lines |
| `pull_log.md` | 18027 | 141 lines |
