# Inventory: athenahealth_workspace.zip

Archive: `/home/sakib/Downloads/athenahealth_workspace.zip`
SHA-256: `a671936bb6fa088c54957f478fd9e7b7ed5029bce8b67a1b3273e8b36ca412a4`
Archive bytes: 6822838

Members: 69; uncompressed bytes: 38081602

| Path | Bytes | Type / counts |
|---|---:|---|
| `athenahealth/` | 0 | file |
| `athenahealth/sf_platform_sentences.json` | 114895 | JSON; JSON array, 162 records |
| `athenahealth/tech_named.json` | 75050 | JSON; JSON array, 602 records |
| `athenahealth/deliverables/` | 0 | file |
| `athenahealth/deliverables/athenahealth_POC_Call_Briefing.docx` | 18900 | DOCX; DOCX 8 headings, 2 tables; headings: Heading 1: Where the pursuit stands / Heading 1: What you can state as confirmed / Heading 1: What to ask, not state / Heading 1: The Data 360 angle / Heading 1: Who to ask the Salesforce account executive about / Heading 1: Guardrails for the call / Heading 1: What we still need from the Client / Heading 1: Source links |
| `athenahealth/deliverables/athenahealth_Sources_and_Evidence.docx` | 57802 | DOCX; DOCX 29 headings, 11 tables; headings: Heading 1: Part A: source register / Heading 1: Part B: extracts from postings read in depth / Heading 2: J1: Project Manager, Salesforce Portfolio (first seen 2026-08-14, open) / Heading 2: J2: Salesforce Technical Architect (first seen 2026-02-09, closed) / Heading 2: J3: Senior Product Manager , Customer Success AI & Automation (first seen 2026-06-25, closed) / Heading 2: J4: AI Business Systems Analyst , Finance Domain (Salesforce CPQ/Revenue Systems) (first seen 2026-06-08, closed) / Heading 2: J5: Senior Marketing Automation Engineer- Salesforce Marketing Cloud (first seen 2025-12-29, closed) / Heading 2: J7: Technical Administrator- CLM Systems (first seen 2026-08-13, closed) / Heading 2: J8: Manager, Product Management, AI Concierge, Service Experience (first seen 2026-09-22, open) / Heading 2: J9: Director, Product Management, Service Experience (first seen 2026-09-22, open) / Heading 1: Part C: Salesforce postings read one by one, with classification / Heading 1: Part D: article and internal note extracts / Heading 2: S14: destinationCRM, 2018 CRM Service Elite / Heading 2: N1: internal account team notes, August 13, 2026 / Heading 2: N1 continued: account planning notes, September 22, 2026 / Heading 2: S18: Cloud Coach customer story / Heading 1: Part E: job board capture, all Salesforce mentions / Heading 1: Part F: leads that are not verified / Heading 1: Part G: keeping copies / Heading 1: Part H: data pulls / Heading 2: Postings by platform (of the 1,136 first seen in the last 12 months) / Heading 2: Detection highlights (603 rows pulled) / Heading 2: News feed, all 63 events / Heading 1: Part J: follow up pass, September 24, 2026 / Heading 2: Rows closed / Heading 2: Full profiles of the 178 senior people (D2) / Heading 2: Recent posts of the 21 Priority A people (D4) / Heading 2: Builder level search (D2), September 24, 2026 / Heading 1: Part I: full URLs |
| `athenahealth/deliverables/athenahealth_Account_Summary.docx` | 40526 | DOCX; DOCX 23 headings, 11 tables; headings: Heading 1: How to read this file / Heading 1: The narrative, in plain words / Heading 2: The account picture / Heading 2: What stands out / Heading 2: What it likely means for each lane (interpretation) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: Recent news / Heading 1: Company and transformation baseline / Heading 1: Signals / Heading 2: Tier 1: hire ready signals / Heading 2: Tier 2: platform and direction signals / Heading 2: Tier 3: context and history / Heading 1: Platform picture by lane / Heading 1: People / Heading 2: Key people (Priority A) / Heading 2: Findings from the work histories and full profiles / Heading 1: Hypotheses to test / Heading 1: Questions for a first conversation / Heading 1: Research coverage tracker / Heading 2: Pass 1: relationship / Heading 2: Pass 2: research / Heading 1: Source links |
| `athenahealth/deliverables/athenahealth_Job_Postings.xlsx` | 334843 | XLSX; Summary=30 rows, Jobs=260 rows |
| `athenahealth/deliverables/athenahealth_People_List.xlsx` | 35472 | XLSX; Summary=20 rows, People=179 rows, Builders and marketing data=42 rows |
| `athenahealth/deliverables/athenahealth_Tech_Stack_and_Teams.xlsx` | 13062 | XLSX; Read me=6 rows, Tech stack=114 rows, Teams=19 rows |
| `athenahealth/notes/` | 0 | file |
| `athenahealth/notes/pass1.md` | 2106 | MD |
| `athenahealth/notes/HANDOFF.md` | 5237 | MD |
| `athenahealth/RESTORE.md` | 4659 | MD |
| `athenahealth/run_state.json` | 7990 | JSON; JSON object, 11 keys; arrays: leadership_page[12], key_signals.tier1_postings[8], open_rows[11] |
| `athenahealth/jobs_12mo.json` | 8780186 | JSON; JSON array, 1187 records |
| `athenahealth/news_18mo.json` | 16374 | JSON; JSON array, 63 records |
| `athenahealth/data/` | 0 | file |
| `athenahealth/data/bitscale_rows_raw.json` | 965335 | JSON; JSON array, 1 records |
| `athenahealth/data/sumble_teams.json` | 13438 | JSON; JSON object, 5 keys; arrays: teams[18] |
| `athenahealth/data/jobs_p1_raw.json` | 8598526 | JSON; JSON array, 1 records |
| `athenahealth/data/jobs_platform_hits.json` | 17658 | JSON; JSON object, 20 keys; arrays: Salesforce[155], Workday[18], CPQ[13], Tableau[64], Power BI[68], Snowflake[55], Sales Cloud[8], ServiceNow[10], Databricks[3], Agentforce[7], Service Cloud[6], Gainsight[9] |
| `athenahealth/data/jobs_sf_class.json` | 12155 | JSON; JSON object, 155 keys |
| `athenahealth/data/bitscale_rows_full.json` | 1340449 | JSON; JSON array, 1 records |
| `athenahealth/data/people_final.json` | 339086 | JSON; JSON array, 178 records |
| `athenahealth/data/pass4/` | 0 | file |
| `athenahealth/data/pass4/sumble_pass4.json` | 520 | JSON; JSON object, 3 keys |
| `athenahealth/data/pass4/builders.json` | 13727 | JSON; JSON array, 40 records |
| `athenahealth/data/people_ruled.json` | 667563 | JSON; JSON object, 3 keys; arrays: kept[178], excluded[1], below[241] |
| `athenahealth/data/news_raw.json` | 375730 | JSON; JSON array, 1 records |
| `athenahealth/data/people_raw_dedup.json` | 98397 | JSON; JSON array, 300 records |
| `athenahealth/data/people_all.json` | 637340 | JSON; JSON array, 420 records |
| `athenahealth/data/jobs_p2_raw.json` | 1115046 | JSON; JSON array, 1 records |
| `athenahealth/data/tech_detections_raw.json` | 1414681 | JSON; JSON array, 1 records |
| `athenahealth/data/jobs_12mo.json` | 8364191 | JSON; JSON array, 1136 records |
| `athenahealth/data/tech_detections_compact.json` | 118481 | JSON; JSON array, 603 records |
| `athenahealth/data/sumble_tech_stack.json` | 12955 | JSON; JSON object, 4 keys; arrays: functions[12] |
| `athenahealth/data/news_compact.json` | 14864 | JSON; JSON array, 63 records |
| `athenahealth/data/pass3/` | 0 | file |
| `athenahealth/data/pass3/profile_analysis.json` | 98230 | JSON; JSON array, 178 records |
| `athenahealth/data/pass3/posts_analysis.json` | 10202 | JSON; JSON array, 21 records |
| `athenahealth/data/pass3/rows/` | 0 | file |
| `athenahealth/data/pass3/rows/page1.json` | 611442 | JSON; JSON array, 1 records |
| `athenahealth/data/pass3/rows/page2.json` | 637435 | JSON; JSON array, 1 records |
| `athenahealth/data/pass3/rows/page3.json` | 521283 | JSON; JSON array, 1 records |
| `athenahealth/data/pass3/rows/page4.json` | 246501 | JSON; JSON array, 1 records |
| `athenahealth/data/pass3/profiles_raw.json` | 1788703 | JSON; JSON object, 178 keys |
| `athenahealth/data/pass3/row_ids.json` | 1727 | JSON; JSON object, 3 keys; arrays: senior_row_ids[178], a_row_ids[21], missing_senior[0] |
| `athenahealth/data/pass3/youtube_bassolino_2025-04-09.md` | 676 | MD |
| `athenahealth/data/pass3/findings.jsonl` | 12699 | JSONL |
| `athenahealth/{data,notes,build}/` | 0 | file |
| `athenahealth/build/` | 0 | file |
| `athenahealth/build/build_summary.js` | 41342 | JS |
| `athenahealth/build/build_evidence.js` | 24553 | JS |
| `athenahealth/build/docx_lib.js` | 4575 | JS |
| `athenahealth/build/strip_tool_names.py` | 1115 | PY |
| `athenahealth/build/people_workbook_example.py` | 11918 | PY |
| `athenahealth/build/build_pete_briefing.js` | 12703 | JS |
| `athenahealth/build/rowcheck.py` | 1680 | PY |
| `athenahealth/build/make_workbooks.v1.py.bak` | 11318 | BAK |
| `athenahealth/build/make_workbooks.py` | 14191 | PY |
| `athenahealth/build/doc_checks.py` | 2140 | PY |
| `athenahealth/build/build_summary.v1.js.bak` | 29960 | BAK |
| `athenahealth/build/urlmap.json` | 8539 | JSON; JSON object, 46 keys; arrays: S1[2], S2[2], S3[2], S4[2], S5[2], S6[2], S7[2], S8[2], S9[2], S10[2], S11[2], S12[2] |
| `athenahealth/build/build_evidence.v1.js.bak` | 11522 | BAK |
| `athenahealth/build/doc_data.json` | 9587 | JSON; JSON object, 17 keys; arrays: A[21] |
| `athenahealth/build/urls.js` | 5861 | JS |
| `athenahealth/build/jobs_workbook_example.py` | 5782 | PY |
| `athenahealth/tech_detections.json` | 328674 | JSON; JSON array, 602 records |
