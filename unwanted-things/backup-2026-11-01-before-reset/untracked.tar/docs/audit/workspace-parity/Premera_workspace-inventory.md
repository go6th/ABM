# Inventory: Premera_workspace.zip

Archive: `/home/sakib/Downloads/Premera_workspace.zip`
SHA-256: `9930f3f20ca9aec3b26ee4b995abf228c3bc43cc851a2740094f47ce85252a07`
Archive bytes: 1343282

Members: 57; uncompressed bytes: 6530691

| Path | Bytes | Type / counts |
|---|---:|---|
| `Premera_workspace/` | 0 | file |
| `Premera_workspace/deliverables/` | 0 | file |
| `Premera_workspace/deliverables/Premera_Sources_and_Evidence.docx` | 45587 | DOCX; DOCX 21 headings, 8 tables; headings: Heading 1: Part A. Source register / Heading 1: Part B. Job posting extracts, read in depth / Heading 1: Part C. Lane postings, read one by one, with classification / Heading 1: Part D. Video and article extracts / Heading 2: S13: Microsoft story on the Facets move (vendor claims) / Heading 2: S12: Microsoft story on Copilot (vendor claims) / Heading 2: S10: Company release on the AI award / Heading 2: S11: Company news on AI adoption / Heading 2: S19: Provider news on the individual market / Heading 2: S18: EVP Healthcare Services podcast notice / Heading 2: S56: COO post, May 2026 / Heading 2: S33: CFO profile / Heading 2: S35: Director of Software Engineering profile / Heading 2: S36: Product manager profile / Heading 1: Part E. Job board captures / Heading 1: Part F. Leads not verified / Heading 1: Part G. How to keep copies of the original pages / Heading 1: Part H. Data pulls / Heading 2: Technology detections, lane relevant (S28) / Heading 2: News feed events kept (18 months) / Heading 1: Part I. Full URLs |
| `Premera_workspace/deliverables/Premera_Tech_Stack_and_Teams.xlsx` | 22439 | XLSX; Summary=5 rows, Confirmed stack=29 rows, Platform teams=26 rows, Detections=56 rows, Named in profiles=11 rows |
| `Premera_workspace/deliverables/Premera_Account_Summary.docx` | 42239 | DOCX; DOCX 28 headings, 15 tables; headings: Heading 1: How to read this file / Heading 1: Narrative, in plain words / Heading 2: The account picture / Heading 2: What stands out / Heading 2: What it likely means for each lane (interpretation) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: Recent news / Heading 1: Company and transformation baseline / Heading 1: Signals / Heading 2: Tier 1: close to budget / Heading 2: Tier 2: one step removed / Heading 2: Tier 3: context and openers / Heading 2: Context and history / Heading 1: Platform picture by lane / Heading 1: People / Heading 2: Key people, priority A / Heading 2: Findings from profiles / Heading 2: People whose status changed / Heading 2: Posts and activity / Heading 1: Hypotheses to test / Heading 2: Cautions / Heading 1: Questions for a first conversation / Heading 1: Research coverage tracker / Heading 2: Decisions waiting on the account owner / Heading 2: Pass 1: summary homework / Heading 2: Pass 2: detailed homework / Heading 1: Source links |
| `Premera_workspace/deliverables/Premera_Job_Postings.xlsx` | 110101 | XLSX; Summary=26 rows, Jobs=68 rows |
| `Premera_workspace/deliverables/Premera_People_List.xlsx` | 30651 | XLSX; Summary=34 rows, People=166 rows |
| `Premera_workspace/notes/` | 0 | file |
| `Premera_workspace/notes/pass1.md` | 1266 | MD |
| `Premera_workspace/notes/sense_check.md` | 16818 | MD |
| `Premera_workspace/notes/pull_log.md` | 12164 | MD |
| `Premera_workspace/RESTORE.md` | 1097 | MD |
| `Premera_workspace/data/` | 0 | file |
| `Premera_workspace/data/teams.json` | 5631 | JSON; JSON object, 3 keys; arrays: teams[25] |
| `Premera_workspace/data/live_board.json` | 5509 | JSON; JSON object, 6 keys; arrays: searches.Salesforce.postings[0], searches.ServiceNow.postings[0], searches.SAP.postings[0], searches.Veeva.postings[0], searches.Databricks.postings[0], searches.Tableau.postings[1], searches.Workday.postings[1], searches.Dynamics.postings[2], searches.Genesys.postings[2], searches.Facets.postings[6], unique_live_postings[8] |
| `Premera_workspace/data/techstack_confirmed.json` | 5125 | JSON; JSON object, 2 keys; arrays: tech_stack[28] |
| `Premera_workspace/data/people_techassoc.json` | 27276 | JSON; JSON object, 4 keys; arrays: people[86] |
| `Premera_workspace/data/techstack_detections.json` | 72431 | JSON; JSON object, 6 keys; arrays: detections[275] |
| `Premera_workspace/data/web_searches_phase2.json` | 2993 | JSON; JSON object, 1 keys; arrays: phase2_searches[8] |
| `Premera_workspace/data/releases/` | 0 | file |
| `Premera_workspace/data/releases/2025-10-06_board_two_directors.md` | 976 | MD |
| `Premera_workspace/data/releases/2026-04-16_multicare_negotiations.md` | 591 | MD |
| `Premera_workspace/data/releases/2026-05-14_ai_mainstream_microsoft.md` | 721 | MD |
| `Premera_workspace/data/releases/affiliates_page.md` | 840 | MD |
| `Premera_workspace/data/releases/2026-03-11_podcast_evp_healthcare_services.md` | 809 | MD |
| `Premera_workspace/data/releases/2026-01-06_cancer_support_thyme_care.md` | 766 | MD |
| `Premera_workspace/data/releases/2025-10-23_conduent_incident.md` | 899 | MD |
| `Premera_workspace/data/releases/2025-08-19_health_hub.md` | 1041 | MD |
| `Premera_workspace/data/releases/2026-09-08_vendor_story_microsoft_azure_facets.md` | 1699 | MD |
| `Premera_workspace/data/releases/2024-08-12_cfo_talha_ashraf.md` | 800 | MD |
| `Premera_workspace/data/releases/2026-06-30_north_star_alice_clara.md` | 1121 | MD |
| `Premera_workspace/data/releases/2026-04-17_vendor_story_microsoft_copilot.md` | 1696 | MD |
| `Premera_workspace/data/people_grid.txt` | 14695 | TXT |
| `Premera_workspace/data/web_searches.json` | 12226 | JSON; JSON object, 1 keys; arrays: searches[4] |
| `Premera_workspace/data/profiles_full_grid2.json` | 274683 | JSON; JSON array, 56 records |
| `Premera_workspace/data/jobs_12mo.json` | 2150194 | JSON; JSON object, 5 keys; arrays: jobs[244] |
| `Premera_workspace/data/newsroom.json` | 8243 | JSON; JSON object, 3 keys; arrays: release_wire_list.items[20], healthsource_news.items[6], site_map_search_news.notable_urls[10], site_map_search_news.subdomains_seen[10] |
| `Premera_workspace/data/jobs_techassoc_2yr.json` | 10678 | JSON; JSON object, 3 keys; arrays: jobs[50] |
| `Premera_workspace/data/people_grid.json` | 215931 | JSON; JSON object, 4 keys; arrays: people[109] |
| `Premera_workspace/data/comments_priority.md` | 693 | MD |
| `Premera_workspace/data/profiles_full_grid1.json` | 356404 | JSON; JSON array, 54 records |
| `Premera_workspace/data/posts_priority_grid1.json` | 99752 | JSON; JSON array, 13 records |
| `Premera_workspace/data/posts_priority_grid2.json` | 32491 | JSON; JSON array, 4 records |
| `Premera_workspace/data/news_events.json` | 2960 | JSON; JSON object, 7 keys; arrays: events[5] |
| `Premera_workspace/build/` | 0 | file |
| `Premera_workspace/build/jobs.json` | 583427 | JSON; JSON array, 67 records |
| `Premera_workspace/build/build_xlsx.py` | 11123 | PY |
| `Premera_workspace/build/sources.json` | 22148 | JSON; JSON object, 2 keys; arrays: S.S1[6], S.S2[6], S.S3[6], S.S4[6], S.S5[6], S.S6[6], S.S7[6], S.S8[6], S.S9[6], S.S10[6], S.S11[6], S.S12[6] |
| `Premera_workspace/build/docx_lib.js` | 4575 | JS |
| `Premera_workspace/build/jobs_hits.json` | 2164205 | JSON; JSON array, 244 records |
| `Premera_workspace/build/ids.json` | 463 | JSON; JSON array, 80 records |
| `Premera_workspace/build/evidence.js` | 9833 | JS |
| `Premera_workspace/build/build_stack.py` | 7073 | PY |
| `Premera_workspace/build/people_model.py` | 9888 | PY |
| `Premera_workspace/build/people.json` | 86438 | JSON; JSON object, 2 keys; arrays: rows[165], excluded[4] |
| `Premera_workspace/build/jobs_model.py` | 6437 | PY |
| `Premera_workspace/build/summary.js` | 32845 | JS |
