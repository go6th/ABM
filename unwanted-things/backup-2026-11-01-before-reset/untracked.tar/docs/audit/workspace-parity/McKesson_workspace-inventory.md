# Inventory: McKesson_workspace.zip

Archive: `/home/sakib/Downloads/McKesson_workspace.zip`
SHA-256: `b980cc88f4e18a6c7367f348a7ece110b79bf780347d51de9a8f3edc3a2cdd0d`
Archive bytes: 22795406

Members: 336; uncompressed bytes: 93457759

| Path | Bytes | Type / counts |
|---|---:|---|
| `McKesson_workspace/` | 0 | file |
| `McKesson_workspace/deliverables/` | 0 | file |
| `McKesson_workspace/deliverables/McKesson_People_List.xlsx` | 245516 | XLSX; Summary=22 rows, People=1980 rows |
| `McKesson_workspace/deliverables/McKesson_Account_Summary.docx` | 69444 | DOCX; DOCX 36 headings, 22 tables; headings: Heading 1: How to read this file / Heading 1: The account in plain words / Heading 2: The account picture / Heading 2: What stands out / Heading 2: What it likely means for each tower (interpretation) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: Recent news, last 18 months / Heading 1: Company and transformation baseline / Heading 2: Executive voice (last two earnings calls) / Heading 1: Signals / Heading 2: Tier 1: budget proximate (about 90 day shelf life) / Heading 2: Tier 2: one step removed / Heading 2: Tier 3: context and openers / Heading 2: Context and history (older than 18 months; direction, not a reason to reach out) / Heading 1: Platform picture by lane / Heading 1: Service map view (the client deck rows against public evidence) / Heading 2: Salesforce tower / Heading 2: SAP tower / Heading 2: Supply Chain tower / Heading 2: Data, AI & Analytics tower / Heading 2: Interoperability tower / Heading 2: Cloud tower / Heading 2: Cyber Security tower / Heading 2: Managed Services tower / Heading 1: People / Heading 2: Key people (priority A, senior, with links) / Heading 2: Findings from profiles / Heading 1: Hypotheses to test / Heading 1: Questions for a first conversation / Heading 1: Caveats on interpretation / Heading 1: Research coverage tracker / Heading 2: Decisions waiting on the account owner / Heading 2: Pass 1: summary homework / Heading 2: Pass 2: detailed homework / Heading 1: Source links |
| `McKesson_workspace/deliverables/McKesson_Sources_and_Evidence.docx` | 107190 | DOCX; DOCX 50 headings, 14 tables; headings: Heading 1: Part A: source register / Heading 1: Part B: job posting extracts (postings read in full) / Heading 2: J1: Senior Director, SAP Transformation Delivery / Heading 2: J2: Sr. Architect, BTP-WZ, Automation, Visualization, Workflows and AI (JR0153725) / Heading 2: J3: Lead S/4 Transformation Specialist / Heading 2: J4: Sr. Contact Center Specialist -Five9 / Heading 2: J5: Salesforce CRM Developer / Heading 2: J6: Salesforce Delivery Lead (JR0147161) / Heading 2: J7: Lead Salesforce Solution Architect (JR0154441) / Heading 2: J8: Salesforce CRM Business Systems Analyst / Heading 2: J9: Senior Director, Agentic Service Experience / Heading 2: J10: Lead Architect, Maestro Kinaxis Solutions, Supply Chain Planning (JR0149727) / Heading 2: J11: Salesforce Product Owner (JR0145363) / Heading 2: J12: Salesforce Functional Consultant (JR0145450) / Heading 2: J13: Lead SAP OTC Architect (JR0150001) / Heading 2: J14: Oracle EPM/EDM IT Architect / Heading 2: J15: Software Developer , Oracle JD Edwards Developer / Heading 2: J16: Senior Manager, Data Hub Engineering & Data Products (JR0149101) / Heading 2: J17: Senior Manager, AI Products & Copilot Solutions / Heading 2: J18: Lead Salesforce Architect / Heading 2: J19: Sr. AI First Full Stack Engineer (JR0152404) / Heading 2: J20: Lead, Technology Integration (JR0155012) / Heading 2: J21: Senior Salesforce and Integration Developer (JR0155236) / Heading 2: J22: Sr Product Security Engineer, AI & DevSecOps (JR0152750) / Heading 2: J23: Service Now AI Architect / Heading 2: J24: Principal Salesforce Enterprise Architect & Delivery Leader / Heading 2: J25: SAP Program Lead , Healthcare Provider/MSO / Heading 2: J26: Salesforce Service & Product Enablement Lead / Heading 2: J27: Veeva Global Directory Governance Administrator / Heading 2: J28: Lead Salesforce Platform Architect / Heading 2: J29: Sr. Salesforce CRM Development Lead / Heading 2: J30: Service Now AI DevOps Engineer / Heading 1: Part C: postings by primary lane, each classified / Heading 2: Salesforce: 469 postings in 12 months, 53 open / Heading 2: SAP: 511 postings in 12 months, 68 open / Heading 2: MuleSoft: 40 postings in 12 months, 8 open / Heading 2: ServiceNow: 113 postings in 12 months, 30 open / Heading 2: Tableau: 268 postings in 12 months, 25 open / Heading 2: Veeva: 12 postings in 12 months, 1 open / Heading 2: Kinaxis: 29 postings in 12 months, 5 open / Heading 1: Part D: video, podcast and article extracts / Heading 1: Part E: job board captures / Heading 2: Live board keyword sweep (October 13, 2026, main Workday board) / Heading 1: Part F: leads that are not verified / Heading 1: Part G: keeping copies / Heading 1: Part H: data pulls / Heading 2: Lane keyword counts in 12 month postings (main domain pull) / Heading 2: Technology detections matching tower keywords (24 months) / Heading 2: News feed categories (98 rows, 18 months) / Heading 1: Part I: full URLs, written out |
| `McKesson_workspace/deliverables/McKesson_Job_Postings.xlsx` | 3286091 | XLSX; Summary=32 rows, Jobs=1990 rows |
| `McKesson_workspace/deliverables/McKesson_Next_Steps.docx` | 14473 | DOCX; DOCX 4 headings, 1 tables; headings: Heading 1: Overview / Heading 1: Asks / Heading 1: Themes / Heading 1: Cross cutting |
| `McKesson_workspace/deliverables/McKesson_Tech_Stack_and_Teams.xlsx` | 25323 | XLSX; Platform Ranking=50 rows, Confirmed stack=175 rows, Platform teams=28 rows |
| `McKesson_workspace/notes/` | 0 | file |
| `McKesson_workspace/notes/pass1.md` | 3352 | MD |
| `McKesson_workspace/notes/title_lists.md` | 2324 | MD |
| `McKesson_workspace/notes/posts_row_ids.json` | 4302 | JSON; JSON array, 611 records |
| `McKesson_workspace/notes/person_search_targets.json` | 20579 | JSON; JSON array, 119 records |
| `McKesson_workspace/notes/sense_check.md` | 6220 | MD |
| `McKesson_workspace/notes/s1_page2_targets.json` | 2833 | JSON; JSON object, 2 keys; arrays: profiles[215], posts[136] |
| `McKesson_workspace/notes/profile_row_ids.json` | 6016 | JSON; JSON array, 826 records |
| `McKesson_workspace/notes/run_spec.md` | 1501 | MD |
| `McKesson_workspace/RESTORE.md` | 3515 | MD |
| `McKesson_workspace/data/` | 0 | file |
| `McKesson_workspace/data/web_searches_step2.json` | 30165 | JSON; JSON array, 72 records |
| `McKesson_workspace/data/teams.json` | 135064 | JSON; JSON object, 3 keys; arrays: teams[25] |
| `McKesson_workspace/data/live_board.json` | 216491 | JSON; JSON object, 3 keys; arrays: boards[6], searches[64], missing_from_jobs_12mo.missing[34] |
| `McKesson_workspace/data/site_map_news.txt` | 23575 | TXT |
| `McKesson_workspace/data/connections.json` | 902888 | JSON; JSON object, 3 keys; arrays: rows[2987] |
| `McKesson_workspace/data/redactions.txt` | 4312 | TXT |
| `McKesson_workspace/data/former_execs.json` | 5953 | JSON; JSON object, 5 keys; arrays: records[9] |
| `McKesson_workspace/data/techstack_confirmed.json` | 5147 | JSON; JSON object, 5 keys |
| `McKesson_workspace/data/leadership.json` | 6461 | JSON; JSON array, 24 records |
| `McKesson_workspace/data/drive_contacts_workbook.xlsx` | 54591 | XLSX; McKesson key platform contacts =423 rows |
| `McKesson_workspace/data/web_searches_step10.json` | 88744 | JSON; invalid JSON (JSONDecodeError) |
| `McKesson_workspace/data/org_signals.json` | 11117 | JSON; JSON object, 4 keys; arrays: signals[43] |
| `McKesson_workspace/data/techstack_detections.json` | 212982 | JSON; JSON object, 3 keys; arrays: rows[1233] |
| `McKesson_workspace/data/jobs_keyword_counts.json` | 3880 | JSON; JSON object, 6 keys |
| `McKesson_workspace/data/releases/` | 0 | file |
| `McKesson_workspace/data/releases/2025-09-23_investor_day_2025_presentation.md` | 84484 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0152404_sr-ai-first-full-stack-engineer.md` | 6904 | MD |
| `McKesson_workspace/data/releases/2026-06-02_mckesson-closes-strategic-investment-with-apollo-funds-for-minority-interest-in.md` | 6699 | MD |
| `McKesson_workspace/data/releases/2025-09-16_person_wetzel_fierce-pharma-webinar-brand-lifecycles.md` | 3742 | MD |
| `McKesson_workspace/data/releases/2025-06-26_mckesson-corporation-announces-first-quarter-fiscal-2026-earnings-release-date.md` | 2600 | MD |
| `McKesson_workspace/data/releases/2026-01-20_mckesson-s-practice-insights-designated-as-a-2026-qualified-clinical-data-regist.md` | 5795 | MD |
| `McKesson_workspace/data/releases/2025-09-23_investor_day_2025_transcript.md` | 186388 | MD |
| `McKesson_workspace/data/releases/2026-03-01_vendor_sap_customer-document_mckesson-advanced-track-and-trace-s4hana.md` | 2076 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_helton_mckesson-intelligent-medical-record-community-oncology.md` | 1755 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_five9_trade-press_emerj_ai-at-mckesson-three-use-cases.md` | 26089 | MD |
| `McKesson_workspace/data/releases/2025-05-01_person_hand_covermymeds-barrier-breaker-podcast-balancing-ai.md` | 1641 | MD |
| `McKesson_workspace/data/releases/2025-08-26_person_attivilli_hba-dfw-leaders-leading-health-innovation-panel.md` | 3004 | MD |
| `McKesson_workspace/data/releases/2025-06-04_person_lau_acc-inconversation-webcast.md` | 1448 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_blue-yonder_customer-story_mckesson-canada.md` | 14132 | MD |
| `McKesson_workspace/data/releases/2026-10-13_fetched_mckesson-story_ideashare-2026-ai-advocacy-community-care.md` | 693 | MD |
| `McKesson_workspace/data/releases/2026-05-21_ontada_release_integrates-florida-cancer-specialists-data.md` | 17219 | MD |
| `McKesson_workspace/data/releases/2026-08-28_trade-press_bleepingcomputer_mckesson-discloses-breach.md` | 13546 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_informatica_video_mckesson-where-healthcare-data-comes-to-life.md` | 3364 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_delatore_mckesson-from-start-to-scale-specialty-access.md` | 2636 | MD |
| `McKesson_workspace/data/releases/2026-10-13_fetched_review-site_g2_mckesson-seller-page.md` | 535 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_tech_covermymeds_latent-health-intelligent-automation-fhir.md` | 7534 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_bashiti_future-forums-decision-velocity-talk.md` | 706 | MD |
| `McKesson_workspace/data/releases/2026-09-23_mckesson-corporation-announces-second-quarter-fiscal-2027-earnings-release-date.md` | 2612 | MD |
| `McKesson_workspace/data/releases/2026-05-07_earnings_call_FY26Q4.md` | 81899 | MD |
| `McKesson_workspace/data/releases/2026-10-13_leadership_mckesson-bio_jason-hammonds-president-oncology-multispecialty.md` | 1746 | MD |
| `McKesson_workspace/data/releases/2025-07-15_mckesson-ideashare-empowers-independent-pharmacies-to-innovate-and-thrive.md` | 6557 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0155012_lead-technology-integration-mississauga.md` | 4373 | MD |
| `McKesson_workspace/data/releases/2026-10-06_cd-r-and-mckesson-corporation-sign-agreement-to-acquire-option-care-health.md` | 20211 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_genesys_mckesson-job-posting_sr-contact-center-specialist-genesys.md` | 12835 | MD |
| `McKesson_workspace/data/releases/2025-12-03_person_kettler_unc-deans-speaker-keynote-youtube.md` | 62888 | MD |
| `McKesson_workspace/data/releases/2025-09-18_mckesson-announces-new-organizational-structure.md` | 5057 | MD |
| `McKesson_workspace/data/releases/2025-09-23_investor-day-8-k-and-news-release-guidance-update.md` | 18332 | MD |
| `McKesson_workspace/data/releases/2025-05-13_person_eliasek_mckesson-canada-national-leadership-conference-agenda.md` | 3326 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0152750_sr-product-security-engineer-ai-devsecops.md` | 5251 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_sap_partner-case-study_lemongrass_mckesson.md` | 6733 | MD |
| `McKesson_workspace/data/releases/2025-06-11_mckesson-to-host-investor-day-on-september-23-2025.md` | 2510 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_openai_mckesson-job-posting_sr-ai-first-full-stack-engineer.md` | 13370 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_workday_customer-story_mckesson-contract-review-ai.md` | 14182 | MD |
| `McKesson_workspace/data/releases/2026-08-05_sec_10-Q_Q1_FY2027_excerpts.md` | 46087 | MD |
| `McKesson_workspace/data/releases/2020-08-18_vendor_google-cloud_blog_mckesson-database-architecture.md` | 6178 | MD |
| `McKesson_workspace/data/releases/2025-10-06_fetched_mckesson-story_logipharma-usa-2025-supply-chain.md` | 930 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0148633_senior-manager-ai-products-copilot-solutions.md` | 4908 | MD |
| `McKesson_workspace/data/releases/2026-01-09_vendor_insightsoftware-simba_customer-story_mckesson-salesforce-odbc-businessobjects.md` | 5440 | MD |
| `McKesson_workspace/data/releases/2026-10-01_mckesson-corporation-extends-pharmaceutical-distribution-agreement-with-cvs-heal.md` | 4847 | MD |
| `McKesson_workspace/data/releases/2025-12-22_mckesson-corporation-announces-third-quarter-fiscal-2026-earnings-release-date.md` | 1633 | MD |
| `McKesson_workspace/data/releases/2025-05-05_person_palani_heartbeat-podcast-salesforce-ai-readiness-youtube.md` | 21237 | MD |
| `McKesson_workspace/data/releases/2026-09-28_person_wetzel_covermymeds-insight-faster-therapy-starts.md` | 3284 | MD |
| `McKesson_workspace/data/releases/2026-03-09_covermymeds_release_expands-specialty-access-and-affordability-solutions.md` | 7033 | MD |
| `McKesson_workspace/data/releases/2026-07-14_person_helton_targeted-oncology-intelligent-medical-record-article.md` | 4968 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_bashiti_world-finance-forum-philadelphia-2027-speaker.md` | 958 | MD |
| `McKesson_workspace/data/releases/2019-06-05_vendor_snowflake_trade-press_snowflake-google-cloud-mckesson-first-customer.md` | 12635 | MD |
| `McKesson_workspace/data/releases/2026-10-13_leadership_mckesson-bio_joan-eliasek-president-na-pharmaceutical-distribution.md` | 2335 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_rehman_patient-support-summit-2025-speakers.md` | 1241 | MD |
| `McKesson_workspace/data/releases/2025-11-04_person_kettler_covermymeds-insight-hlth-2025-patients-know-first.md` | 4221 | MD |
| `McKesson_workspace/data/releases/2026-09-21_mckesson-statement_customer-cybersecurity-information-center-updates-aug28-aug29-sep21.md` | 5321 | MD |
| `McKesson_workspace/data/releases/2026-07-15_tech_trade-press_distribution-strategy_mckesson-bets-on-ai.md` | 10336 | MD |
| `McKesson_workspace/data/releases/2025-09-23_mckesson-highlights-strategic-growth-strategies-and-updated-long-term-targets-at-investor-day.md` | 12704 | MD |
| `McKesson_workspace/data/releases/2025-06-01_us-oncology-network_release_asco-2025-pharmacist-driven-cost-savings.md` | 11035 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_bhanawat_leaders-in-ai-summit-2024-speaker.md` | 1519 | MD |
| `McKesson_workspace/data/releases/2026-07-01_sec_8-K_chief_strategy_officer_transition.md` | 3976 | MD |
| `McKesson_workspace/data/releases/2025-11-06_person_gerberding_milken-future-of-health-2025-speaker.md` | 1760 | MD |
| `McKesson_workspace/data/releases/2025-10-28_vendor_impetus_page_mckesson-data-driven-healthcare-enterprise.md` | 11712 | MD |
| `McKesson_workspace/data/releases/2024-08-09_vendor_servicenow_community-webinar_transforming-itsm-with-training-mckesson.md` | 2114 | MD |
| `McKesson_workspace/data/releases/2026-05-07_person_delatore_pharmaceutical-commerce-asembia-axs26-next-phase-specialty.md` | 2135 | MD |
| `McKesson_workspace/data/releases/2025-08-08_vendor_sap_supplier-notice_fresenius-kabi_mckesson-distribution-partners-s4hana.md` | 2020 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0155354_senior-full-stack-ai-software-engineer-java.md` | 5287 | MD |
| `McKesson_workspace/data/releases/2025-11-05_mckesson-corporation-reports-fiscal-2026-second-quarter-results-and-raises-full.md` | 16102 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_tech_mckesson-story_reducing-administrative-burden-with-ai-tools.md` | 9526 | MD |
| `McKesson_workspace/data/releases/2024-12-05_person_dunsire_biotech-ceo-sisterhood-interview.md` | 2021 | MD |
| `McKesson_workspace/data/releases/2026-10-13_fetched_pharmacytimes_ideashare-2026-van-norman-supply-chain-ai.md` | 1048 | MD |
| `McKesson_workspace/data/releases/2026-09-08_mckesson-statement_notice-of-data-breach.md` | 5261 | MD |
| `McKesson_workspace/data/releases/2019-11-15_vendor_salesforce-mulesoft_blog_google-partnership_mckesson-cto-quote.md` | 20644 | MD |
| `McKesson_workspace/data/releases/2026-07-22_mckesson-corporation-raises-quarterly-dividend-by-15-to-0-94-per-share.md` | 2934 | MD |
| `McKesson_workspace/data/releases/2026-08-21_person_jhaveri_drug-store-news-video-barriers-to-care.md` | 1040 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0153913_principal-ai-transformation-strategist-ftc.md` | 6425 | MD |
| `McKesson_workspace/data/releases/2025-04-29_person_srinivasan_covermymeds-barrier-breaker-podcast-ira.md` | 1831 | MD |
| `McKesson_workspace/data/releases/2026-02-04_mckesson-corporation-reports-fiscal-2026-third-quarter-results-and-raises-full-y.md` | 15241 | MD |
| `McKesson_workspace/data/releases/2026-04-20_mckesson-signs-agreement-with-apollo-funds-for-strategic-minority-interest-in-me.md` | 7739 | MD |
| `McKesson_workspace/data/releases/2026-10-13_mckesson-statement_cybersecurity-page-as-captured.md` | 2550 | MD |
| `McKesson_workspace/data/releases/2024-07-20_person_dunbar_nacd-speaker-bio.md` | 1749 | MD |
| `McKesson_workspace/data/releases/2026-03-10_person_branick_hda-distribution-management-conference-2026-sessions.md` | 3761 | MD |
| `McKesson_workspace/data/releases/2026-05-14_ontada_release_12-real-world-studies-at-ispor-2026-on-journey.md` | 16336 | MD |
| `McKesson_workspace/data/releases/2026-03-19_mckesson-ideashare-2026-invites-independent-pharmacists-to-learn-connect-and-gro.md` | 6617 | MD |
| `McKesson_workspace/data/releases/2022-12-09_fetched_vendor_github_customer-story_mckesson-labs-devops.md` | 864 | MD |
| `McKesson_workspace/data/releases/2026-08-05_mckesson-reports-fiscal-2027-first-quarter-results-and-raises-full-year-adjusted.md` | 16391 | MD |
| `McKesson_workspace/data/releases/2025-10-23_person_hand_covermymeds-patient-direct-fireside-chat.md` | 2913 | MD |
| `McKesson_workspace/data/releases/2026-10-13_leadership_mckesson-bio_kenny-cheung-evp-cfo.md` | 2564 | MD |
| `McKesson_workspace/data/releases/2026-01-30_mckesson-corporation-completes-divestiture-of-norwegian-operations.md` | 4112 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_rowe_hida-streamlining-healthcare-distributor-qa.md` | 983 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_hammonds_endpoints-asco-2026-panel-community-oncology.md` | 3706 | MD |
| `McKesson_workspace/data/releases/2026-08-05_earnings_call_FY27Q1.md` | 55722 | MD |
| `McKesson_workspace/data/releases/2026-10-13_event_dreamforce-2025_mckesson-agentforce-customer-onboarding-session.md` | 1225 | MD |
| `McKesson_workspace/data/releases/2026-05-07_sec_10-K_FY2026_excerpts.md` | 116016 | MD |
| `McKesson_workspace/data/releases/2024-10-09_vendor_gearset-salesforce_customer-story_mckesson-medical-surgical-devops.md` | 5831 | MD |
| `McKesson_workspace/data/releases/2021-07-12_vendor_mulesoft_blog_mckesson-business-agility.md` | 8947 | MD |
| `McKesson_workspace/data/releases/2025-11-05_earnings_call_FY26Q2.md` | 60137 | MD |
| `McKesson_workspace/data/releases/2025-11-29_person_hoxha_grizzhacks-tech-talk-announcement.md` | 903 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_microsoft-azure-openai_customer-story_ontada-150-million-documents.md` | 13441 | MD |
| `McKesson_workspace/data/releases/2024-10-23_person_fraga_hitec-fireside-chat-capital-one.md` | 1439 | MD |
| `McKesson_workspace/data/releases/2019-04-09_vendor_google-cloud_blog_mckesson-chooses-google-cloud.md` | 5455 | MD |
| `McKesson_workspace/data/releases/2026-02-28_person_modgil_convergence-ai-dallas-2026-speaker.md` | 1294 | MD |
| `McKesson_workspace/data/releases/2025-10-06_cell-and-gene-therapies-on-the-rise-new-report-reveals-growing-adoption-and-pers.md` | 5354 | MD |
| `McKesson_workspace/data/releases/2021-09-29_vendor_mulesoft_trade-press_diginomica_mckesson-uk.md` | 13255 | MD |
| `McKesson_workspace/data/releases/2025-12-04_person_hammonds_oncology-data-advisor-interview-youtube.md` | 17334 | MD |
| `McKesson_workspace/data/releases/2026-10-13_leadership_mckesson-bio_ramesh-srinivasan-evp-chief-strategy-officer.md` | 2398 | MD |
| `McKesson_workspace/data/releases/2026-08-31_trade-press_fierce-healthcare_mckesson-confirms-cybersecurity-incident.md` | 11903 | MD |
| `McKesson_workspace/data/releases/2025-10-30_mckesson-corporation-declares-quarterly-dividend.md` | 1441 | MD |
| `McKesson_workspace/data/releases/2025-07-31_vendor_sap_trade-press_sapinsider_mckesson-case-study.md` | 20080 | MD |
| `McKesson_workspace/data/releases/2025-05-12_ontada_partner-news_atropos-health-collaborates-with-ontada.md` | 6802 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0154550_principle-employee-enablement-architect.md` | 6836 | MD |
| `McKesson_workspace/data/releases/2026-10-13_event_mckesson-health-systems_conferences-and-events-page.md` | 6296 | MD |
| `McKesson_workspace/data/releases/2025-05-05_ontada_release_ispor-2025-real-world-evidence.md` | 26967 | MD |
| `McKesson_workspace/data/releases/2024-05-29_person_krishnaraj_cdo-magazine-good-ai-needs-right-data-youtube.md` | 12338 | MD |
| `McKesson_workspace/data/releases/2025-05-08_mckesson-reports-fiscal-2025-fourth-quarter-and-full-year-results-and-provides-f.md` | 20046 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0140831_senior-lead-data-scientist.md` | 4853 | MD |
| `McKesson_workspace/data/releases/2026-09-18_trade-press_hipaa-journal_mckesson-cyberattack-stolen-data.md` | 25587 | MD |
| `McKesson_workspace/data/releases/2026-09-22_leadership_trade-press_cara-mcdonough-joins-medical-surgical-chief-product-strategy.md` | 1993 | MD |
| `McKesson_workspace/data/releases/2025-05-19_vendor_microsoft-azure_customer-story_mckesson-sap-to-azure.md` | 9338 | MD |
| `McKesson_workspace/data/releases/2026-10-13_leadership_mckesson-bio_francisco-fraga-evp-cio-cto.md` | 1945 | MD |
| `McKesson_workspace/data/releases/2025-07-30_mckesson-corporation-raises-quarterly-dividend-by-15-to-0-82-per-share.md` | 1838 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_mckesson-story_digitally-transforming-specialty-medication-workflows.md` | 6177 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0147160_salesforce-crm-developer.md` | 3788 | MD |
| `McKesson_workspace/data/releases/2026-01-13_investor_conference_JPM_2026_presentation.md` | 31579 | MD |
| `McKesson_workspace/data/releases/2025-04-16_mckesson_release_unveils-precision-care-companion.md` | 7530 | MD |
| `McKesson_workspace/data/releases/2026-04-22_event_asembia-axs26_biologics-by-mckesson-sessions-and-team.md` | 4880 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_workday-evisort_success-story_mckesson-contracting-at-scale.md` | 4904 | MD |
| `McKesson_workspace/data/releases/2026-10-13_vendor_tableau-okta_mckesson-analytics-portal-sign-in-page.md` | 329 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0155013_lead-technology-integration-irving.md` | 4390 | MD |
| `McKesson_workspace/data/releases/2026-08-25_mckesson-signs-agreement-to-acquire-precision-medicine-group-llc.md` | 5383 | MD |
| `McKesson_workspace/data/releases/2026-04-30_person_delatore_pharmaceutical-commerce-ai-and-the-access-gap.md` | 2566 | MD |
| `McKesson_workspace/data/releases/2024-07-01_vendor_snowflake_blog_mckesson-cross-cloud-data-journey.md` | 7100 | MD |
| `McKesson_workspace/data/releases/2016-06-27_vendor_five9_release_mckesson-executive-at-iqpc-call-center-week.md` | 3540 | MD |
| `McKesson_workspace/data/releases/2026-10-13_fetched_investor_wells-fargo-2026-healthcare-conference.md` | 379 | MD |
| `McKesson_workspace/data/releases/2026-03-18_vendor_sap-microsoft_conference-session_mckesson-sap-migration-to-azure.md` | 2380 | MD |
| `McKesson_workspace/data/releases/2026-05-21_person_palani_crm-coe-roundtable-april-2026-youtube.md` | 28099 | MD |
| `McKesson_workspace/data/releases/2026-04-29_person_wetzel_covermymeds-webinar-whats-new-access-affordability.md` | 2878 | MD |
| `McKesson_workspace/data/releases/2022-01-24_fetched_vendor_mulesoft_blog_three-customers-healthcare-integration.md` | 761 | MD |
| `McKesson_workspace/data/releases/2026-06-12_sec_DEF14A_2026_proxy_excerpts.md` | 76262 | MD |
| `McKesson_workspace/data/releases/2026-06-23_mckesson-ideashare-2026-fuels-momentum-for-independent-pharmacies.md` | 7842 | MD |
| `McKesson_workspace/data/releases/2026-10-13_mckesson-canada_view-all-press-releases-page.md` | 89508 | MD |
| `McKesson_workspace/data/releases/2026-10-13_leadership_aggregator_org-chart-under-cio-cto-francisco-fraga.md` | 3072 | MD |
| `McKesson_workspace/data/releases/2026-10-07_person_helton_oncology-news-central-intelligent-medical-record-interview.md` | 4509 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_tech_mckesson-story_ai-in-community-oncology.md` | 9469 | MD |
| `McKesson_workspace/data/releases/2025-10-17_person_fisher_ai-explained-podcast-17-day-process-to-3-minutes.md` | 1794 | MD |
| `McKesson_workspace/data/releases/2026-10-13_event_mckesson-compile_events-page.md` | 2995 | MD |
| `McKesson_workspace/data/releases/2026-07-08_person_tyler_dceo-dallas-500-interview.md` | 4606 | MD |
| `McKesson_workspace/data/releases/2025-12-10_person_emami_leaders-in-ai-summit-speaker.md` | 782 | MD |
| `McKesson_workspace/data/releases/2016-09-19_vendor_five9_release_cloud-connect-user-group-mckesson-quote.md` | 3985 | MD |
| `McKesson_workspace/data/releases/2026-10-05_new-2026-cell-and-gene-therapy-report-charts-the-path-from-scientific-progress.md` | 13382 | MD |
| `McKesson_workspace/data/releases/2026-10-13_event_ideashare-2026_general-sessions-keynote-agenda.md` | 4601 | MD |
| `McKesson_workspace/data/releases/2024-11-23_vendor_mongodb-azure-openai_video_mckesson-supply-chain-modernization.md` | 17947 | MD |
| `McKesson_workspace/data/releases/2026-01-28_mckesson-corporation-declares-quarterly-dividend.md` | 2347 | MD |
| `McKesson_workspace/data/releases/2026-08-28_trade-press_start-with-identity_mckesson-breach-okta-sso-salesforce-snowflake.md` | 1829 | MD |
| `McKesson_workspace/data/releases/2025-05-01_mckesson-corporation-declares-quarterly-dividend.md` | 1844 | MD |
| `McKesson_workspace/data/releases/2026-09-01_substack_rod-trent_security-check-in-mckesson-extortion-breach.md` | 1713 | MD |
| `McKesson_workspace/data/releases/2025-10-20_person_kettler_hlth-usa-2025-patients-know-first-panel.md` | 2803 | MD |
| `McKesson_workspace/data/releases/2025-08-06_mckesson-corporation-reports-fiscal-2026-first-quarter-results-and-raises-full-y.md` | 15895 | MD |
| `McKesson_workspace/data/releases/2026-03-05_mckesson-announces-planned-cfo-transition.md` | 8058 | MD |
| `McKesson_workspace/data/releases/2026-04-22_mckesson-corporation-declares-quarterly-dividend.md` | 2362 | MD |
| `McKesson_workspace/data/releases/2019-04-08_vendor_google-cloud_wire-copy_mckesson-announces-move-to-google-cloud.md` | 16576 | MD |
| `McKesson_workspace/data/releases/2026-10-13_person_kaminsky_milken-future-of-health-summit-2024-speaker.md` | 2001 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_five9_webinar_five9-x-mckesson-town-hall.md` | 1961 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_tableau_account-page_mckesson.md` | 4424 | MD |
| `McKesson_workspace/data/releases/2026-10-05_person_modgil_avant-south-2026-speakers.md` | 356 | MD |
| `McKesson_workspace/data/releases/2025-10-01_dimitris-polygenis-named-new-president-of-mckesson-canada.md` | 3203 | MD |
| `McKesson_workspace/data/releases/2026-06-24_mckesson-corporation-announces-first-quarter-fiscal-2027-earnings-release-date.md` | 2600 | MD |
| `McKesson_workspace/data/releases/2026-06-23_tech_wire_mckesson-selects-moore-oklahoma-automated-regional-distribution-center.md` | 15104 | MD |
| `McKesson_workspace/data/releases/2026-10-13_leadership_mckesson-bio_kevin-kettler-president-prescription-technology-solutions.md` | 2017 | MD |
| `McKesson_workspace/data/releases/2026-05-05_mckesson-canada-health-care-at-a-turning-point-patient-innovation-summit.md` | 5438 | MD |
| `McKesson_workspace/data/releases/2026-07-13_mckesson-releases-fiscal-year-2026-impact-report.md` | 4843 | MD |
| `McKesson_workspace/data/releases/2026-05-29_us-oncology-network_release_asco-2026-app-led-models.md` | 9552 | MD |
| `McKesson_workspace/data/releases/2026-08-28_sec_8-K_cybersecurity_incident_item_7-01.md` | 4136 | MD |
| `McKesson_workspace/data/releases/2026-10-08_substack_buy-build-exit_mckesson-option-care-play.md` | 2951 | MD |
| `McKesson_workspace/data/releases/2026-08-05_vendor_kinaxis_mckesson-job-posting_sr-architect-maestro-kinaxis.md` | 28770 | MD |
| `McKesson_workspace/data/releases/2026-02-09_person_kaminsky_top-line-podcast-community-oncology.md` | 1840 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0151827_service-now-ai-devops-specialist.md` | 4028 | MD |
| `McKesson_workspace/data/releases/2026-03-06_mckesson-corporation-announces-fourth-quarter-fiscal-2026-earnings-release-date.md` | 3111 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_servicenow_customer-story_mckesson-itsm-rollout.md` | 19665 | MD |
| `McKesson_workspace/data/releases/2025-06-03_mckesson-corporation-completes-acquisition-of-core-ventures.md` | 7429 | MD |
| `McKesson_workspace/data/releases/2026-05-28_ontada_release_asco-2026-glp1-study.md` | 17124 | MD |
| `McKesson_workspace/data/releases/2026-05-07_mckesson-reports-fiscal-2026-fourth-quarter-and-full-year-results-provides-fisca.md` | 19426 | MD |
| `McKesson_workspace/data/releases/2024-10-17_vendor_microsoft-azure-openai_mckesson-release_ontada-collaborates-with-microsoft.md` | 6867 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0153271_senior-specialist-ai-transformation.md` | 5534 | MD |
| `McKesson_workspace/data/releases/2026-02-04_earnings_call_FY26Q3.md` | 62231 | MD |
| `McKesson_workspace/data/releases/2025-12-01_mckesson-s-advancing-community-oncology-report-charts-a-new-era-of-innovation-fo.md` | 7193 | MD |
| `McKesson_workspace/data/releases/2026-10-13_live_JR0149101_senior-manager-data-hub-engineering-data-products.md` | 6218 | MD |
| `McKesson_workspace/data/releases/2017-05-17_vendor_informatica_release_2017-innovation-awards-mckesson-salesforce-customer-360.md` | 12010 | MD |
| `McKesson_workspace/data/releases/2024-12-30_person_wunderlich_what-i-wish-i-knew-podcast.md` | 1721 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_snowflake_marketplace_mckesson-compile-provider-listing.md` | 6857 | MD |
| `McKesson_workspace/data/releases/2025-03-11_vendor_sap_partner-case-study-pdf_lemongrass_mckesson-fraga-quote.md` | 4583 | MD |
| `McKesson_workspace/data/releases/2026-10-13_undated-captured_vendor_okta_integration-network_mckesson-supply-manager.md` | 16569 | MD |
| `McKesson_workspace/data/releases/2026-05-27_inspirogene-by-mckesson-expands-us-patient-access-to-kite-car-t-cell-therapies.md` | 3662 | MD |
| `McKesson_workspace/data/releases/2024-10-18_fetched_trade-press_precisionmedicineonline_ontada-microsoft-azure-ai.md` | 820 | MD |
| `McKesson_workspace/data/releases/2025-10-10_person_jhaveri_chain-drug-review-video-forum.md` | 893 | MD |
| `McKesson_workspace/data/releases/2026-02-08_person_hammonds_targeted-oncology-community-oncology-report-interview.md` | 7090 | MD |
| `McKesson_workspace/data/releases/2025-06-09_covermymeds_release_acquires-rxlightning-and-fastauth.md` | 6944 | MD |
| `McKesson_workspace/data/posts_comments.json` | 12753858 | JSON; JSON object, 4 keys; arrays: rows[747] |
| `McKesson_workspace/data/org_resolve.json` | 1078 | JSON; JSON object, 4 keys; arrays: results[5] |
| `McKesson_workspace/data/web_searches.json` | 131241 | JSON; JSON array, 626 records |
| `McKesson_workspace/data/subsidiary_domains_banner.json` | 5748 | JSON; JSON object, 3 keys; arrays: domains.uniprix.com.jobs.lane_keyword_postings[0], domains.uniprix.com.tech.lane_relevant[3], domains.groupeproxim.ca.jobs.lane_keyword_postings[0], domains.groupeproxim.ca.tech.lane_relevant[1], domains.guardian-ida-remedysrx.ca.tech.lane_relevant[2], domains.medicineshoppe.ca.tech.lane_relevant[3] |
| `McKesson_workspace/data/jobs_12mo.json` | 38145647 | JSON; JSON object, 3 keys; arrays: rows[5105] |
| `McKesson_workspace/data/subsidiary_domains.json` | 2457704 | JSON; JSON object, 10 keys; arrays: usoncology.com.jobs[348], usoncology.com.tech[200], mckessoncompile.com.jobs[21], mckessoncompile.com.tech[148], covermymeds.health.tech[258], mckesson.ca.tech[63], healthmart.com.jobs[0], mckesson.eu.jobs[0], mckessonaccelerate.com.jobs[0], mckessonideashare.com.jobs[0], mckessonretaildesign.com.jobs[0], covermymeds.com.jobs[0] |
| `McKesson_workspace/data/lane_map.json` | 3584 | JSON; JSON object, 7 keys; arrays: towers.Salesforce[4], towers.SAP[4], towers.Supply Chain[6], towers.Data, AI & Analytics[6], towers.Interoperability[3], towers.Cloud[4], towers.Cyber Security[5], towers.Managed Services[5], added_lanes[2], never_query[3], tower_keywords.Salesforce[10], tower_keywords.SAP[12] |
| `McKesson_workspace/data/raw_step4/` | 0 | file |
| `McKesson_workspace/data/raw_step4/A_Five9.tsv` | 16 | TSV |
| `McKesson_workspace/data/raw_step4/A_Salesforce.tsv` | 2595 | TSV |
| `McKesson_workspace/data/raw_step4/A_Oracle.tsv` | 567 | TSV |
| `McKesson_workspace/data/raw_step4/A_Kubernetes.tsv` | 429 | TSV |
| `McKesson_workspace/data/raw_step4/A_CyberArk.tsv` | 38 | TSV |
| `McKesson_workspace/data/raw_step4/missing_ids.json` | 10069 | JSON; JSON object, 3 keys; arrays: missing[34] |
| `McKesson_workspace/data/raw_step4/A_FinOps.tsv` | 38 | TSV |
| `McKesson_workspace/data/raw_step4/posting_scrape_targets.json` | 3319 | JSON; JSON array, 13 records |
| `McKesson_workspace/data/raw_step4/A_Informatica.tsv` | 1093 | TSV |
| `McKesson_workspace/data/raw_step4/A_SQLServer.tsv` | 438 | TSV |
| `McKesson_workspace/data/raw_step4/A_Dynatrace.tsv` | 202 | TSV |
| `McKesson_workspace/data/raw_step4/A_Alation.tsv` | 208 | TSV |
| `McKesson_workspace/data/raw_step4/A_Okta.tsv` | 585 | TSV |
| `McKesson_workspace/data/raw_step4/A_Kinaxis.tsv` | 791 | TSV |
| `McKesson_workspace/data/raw_step4/A_ServiceNow.tsv` | 2284 | TSV |
| `McKesson_workspace/data/raw_step4/A_S4HANA.tsv` | 526 | TSV |
| `McKesson_workspace/data/raw_step4/A_Veeva.tsv` | 159 | TSV |
| `McKesson_workspace/data/raw_step4/A_Datadog.tsv` | 27 | TSV |
| `McKesson_workspace/data/raw_step4/A_Kafka.tsv` | 794 | TSV |
| `McKesson_workspace/data/raw_step4/A_GCP.tsv` | 480 | TSV |
| `McKesson_workspace/data/raw_step4/A_BlueYonder.tsv` | 813 | TSV |
| `McKesson_workspace/data/raw_step4/A_FHIR.tsv` | 2926 | TSV |
| `McKesson_workspace/data/raw_step4/A_PowerBI.tsv` | 1346 | TSV |
| `McKesson_workspace/data/raw_step4/A_SailPoint.tsv` | 198 | TSV |
| `McKesson_workspace/data/raw_step4/A_Boomi.tsv` | 16 | TSV |
| `McKesson_workspace/data/raw_step4/A_Splunk.tsv` | 286 | TSV |
| `McKesson_workspace/data/raw_step4/A_HealthCloud.tsv` | 1931 | TSV |
| `McKesson_workspace/data/raw_step4/A_SOX.tsv` | 1490 | TSV |
| `McKesson_workspace/data/raw_step4/A_Manhattan.tsv` | 16 | TSV |
| `McKesson_workspace/data/raw_step4/A_datagovernance.tsv` | 358 | TSV |
| `McKesson_workspace/data/raw_step4/A_Collibra.tsv` | 38 | TSV |
| `McKesson_workspace/data/raw_step4/A_generativeAI.tsv` | 1960 | TSV |
| `McKesson_workspace/data/raw_step4/A_Workday.tsv` | 1953 | TSV |
| `McKesson_workspace/data/raw_step4/A_Snowflake.tsv` | 1768 | TSV |
| `McKesson_workspace/data/raw_step4/A_machinelearning.tsv` | 1114 | TSV |
| `McKesson_workspace/data/raw_step4/A_contactcenter.tsv` | 2754 | TSV |
| `McKesson_workspace/data/raw_step4/A_MuleSoft.tsv` | 478 | TSV |
| `McKesson_workspace/data/raw_step4/A_identityaccess.tsv` | 391 | TSV |
| `McKesson_workspace/data/raw_step4/A_EDI.tsv` | 1907 | TSV |
| `McKesson_workspace/data/raw_step4/A_Tableau.tsv` | 2619 | TSV |
| `McKesson_workspace/data/raw_step4/A_SAP.tsv` | 2320 | TSV |
| `McKesson_workspace/data/raw_step4/A_decisionintelligence.tsv` | 1029 | TSV |
| `McKesson_workspace/data/raw_step4/A_MarketingCloud.tsv` | 833 | TSV |
| `McKesson_workspace/data/raw_step4/A_Azure.tsv` | 737 | TSV |
| `McKesson_workspace/data/raw_step4/careers_mckesson_technology_jobs.md` | 5061 | MD |
| `McKesson_workspace/data/raw_step4/A_CMDB.tsv` | 71 | TSV |
| `McKesson_workspace/data/raw_step4/A_Genesys.tsv` | 16 | TSV |
| `McKesson_workspace/data/raw_step4/A_Agentforce.tsv` | 38 | TSV |
| `McKesson_workspace/data/raw_step4/A_AWS.tsv` | 863 | TSV |
| `McKesson_workspace/data/raw_step4/A_Ariba.tsv` | 635 | TSV |
| `McKesson_workspace/data/company_record.json` | 672 | JSON; JSON object, 9 keys; arrays: subsidiary_domains[9], mckesson.ca_subsidiaries_reported[4], similar_companies[5] |
| `McKesson_workspace/data/web_searches_step4.json` | 11695 | JSON; invalid JSON (JSONDecodeError) |
| `McKesson_workspace/data/press_release_index_2026.txt` | 5867 | TXT |
| `McKesson_workspace/data/people_grid.json` | 2581857 | JSON; JSON array, 1714 records |
| `McKesson_workspace/data/profiles_full.json` | 8420369 | JSON; JSON object, 3 keys; arrays: profiles[1041] |
| `McKesson_workspace/data/news_events.json` | 93391 | JSON; JSON object, 3 keys; arrays: rows[98] |
| `McKesson_workspace/build/` | 0 | file |
| `McKesson_workspace/build/build_stack_workbook.py` | 5039 | PY |
| `McKesson_workspace/build/build_jobs_workbook.py` | 6950 | PY |
| `McKesson_workspace/build/survey3.py` | 785 | PY |
| `McKesson_workspace/build/build_summary_doc.js` | 20010 | JS |
| `McKesson_workspace/build/people_final.json` | 2937240 | JSON; JSON array, 1978 records |
| `McKesson_workspace/build/sources.json` | 41068 | JSON; JSON object, 114 keys |
| `McKesson_workspace/build/docx_lib.js` | 4575 | JS |
| `McKesson_workspace/build/survey4.py` | 1023 | PY |
| `McKesson_workspace/build/evidence_extracts.json` | 172693 | JSON; JSON object, 8 keys; arrays: part_b[30], part_c.Salesforce.rows[95], part_c.SAP.rows[141], part_c.MuleSoft.rows[40], part_c.ServiceNow.rows[33], part_c.Tableau.rows[38], part_c.Veeva.rows[12], part_c.Kinaxis.rows[29], part_e_keywords[47], part_e_boards[6], part_h_detections[68] |
| `McKesson_workspace/build/classify_jobs.py` | 4337 | PY |
| `McKesson_workspace/build/survey5.py` | 353 | PY |
| `McKesson_workspace/build/survey2.py` | 3137 | PY |
| `McKesson_workspace/build/survey1.py` | 1985 | PY |
| `McKesson_workspace/build/build_next_steps_doc.js` | 7978 | JS |
| `McKesson_workspace/build/build_evidence_doc.js` | 12578 | JS |
| `McKesson_workspace/build/news_signals.md` | 59070 | MD |
| `McKesson_workspace/build/process_pulls.py` | 5588 | PY |
| `McKesson_workspace/build/financial_voice.md` | 17220 | MD |
| `McKesson_workspace/build/key_people.json` | 8865 | JSON; JSON array, 29 records |
| `McKesson_workspace/build/jobs_enriched.json` | 16268624 | JSON; JSON array, 1988 records |
| `McKesson_workspace/build/make_sources.py` | 20792 | PY |
| `McKesson_workspace/build/rank_checked.json` | 272 | JSON; JSON array, 19 records |
| `McKesson_workspace/build/platform_ranking_mck.py` | 11827 | PY |
| `McKesson_workspace/build/package.json` | 50 | JSON; JSON object, 1 keys |
| `McKesson_workspace/build/content_news_tracker.json` | 13255 | JSON; JSON object, 5 keys; arrays: news[28], tracker_waiting[2], tracker_p1[5], tracker_p2[28] |
| `McKesson_workspace/build/content_service_map.json` | 21145 | JSON; JSON object, 2 keys; arrays: rows[37] |
| `McKesson_workspace/build/content_summary.json` | 27258 | JSON; JSON object, 9 keys; arrays: narrative.account_picture[3], narrative.what_stands_out[6], narrative.tower_meaning[8], narrative.how_wrong[6], narrative.sharpen[3], signals_t1[16], signals_t2[12], signals_t3[10], signals_history[6], hypotheses[10], first_call_questions[10], caveats[6] |
| `McKesson_workspace/build/people_findings.json` | 29029 | JSON; JSON object, 5 keys; arrays: excluded[8], joiners_2026_senior[124], program_mentions[57] |
| `McKesson_workspace/build/survey9.py` | 4850 | PY |
| `McKesson_workspace/build/rank_stack.json` | 2097 | JSON; JSON array, 166 records |
| `McKesson_workspace/build/jobs_all_min.json` | 1241359 | JSON; JSON array, 5105 records |
| `McKesson_workspace/build/save_fetches.py` | 6663 | PY |
| `McKesson_workspace/build/build_people_workbook.py` | 7954 | PY |
| `McKesson_workspace/build/survey7.py` | 3331 | PY |
| `McKesson_workspace/build/survey8.py` | 1884 | PY |
| `McKesson_workspace/build/survey6.py` | 1176 | PY |
| `McKesson_workspace/build/prep_evidence.py` | 6382 | PY |
| `McKesson_workspace/build/review_title_roles.json` | 70512 | JSON; JSON array, 91 records |
| `McKesson_workspace/build/jobs_pipeline.py` | 11558 | PY |
| `McKesson_workspace/build/people_pipeline.py` | 14001 | PY |
| `McKesson_workspace/pull_log.md` | 17750 | MD |
