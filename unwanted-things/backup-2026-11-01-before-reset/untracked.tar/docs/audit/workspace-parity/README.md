# Workspace parity audit, Phase 1

Phase 1 audit deliverable for the task in the pasted prompt. Phase 1 itself changed no product code;
the owner approved Phase 2 on 2026-10-31. Product changes and their current limits are recorded in
[`workspace_parity.md`](../../workspace_parity.md), [`gap_report.md`](gap_report.md) and `BUILD_LOG.md`.

## Deliverables

- [`inventory.md`](inventory.md): available archives, safety metadata, schema differences and golden-run status. The adjacent `*-workspace-inventory.md` files contain a fresh member-by-member inventory for every unique archive found in Downloads.
- [`logic_map.md`](logic_map.md): code and data path from inputs to output, with module/function citations and generic versus account-specific rules.
- [`workspace_contract.md`](workspace_contract.md): current repository contract, candidate schema status and known limitations deriving a full BD configuration.
- [`gap_report.md`](gap_report.md): parity gaps ranked by impact.
- [`BD/inventory.md`](BD/inventory.md) and other account subdirectories: earlier inventories kept for comparison; the new `*-workspace-inventory.md` files are the current archive-specific inventories.

## BD source facts extracted from the archive

Source: `/home/sakib/Downloads/BD_workspace.zip`, member `ws/RESTORE.md` (372 members; the archive was never extracted and its scripts were not executed). The archive's exact restore order is at lines 11–13; canonical query definitions at lines 15–22; entity/out-of-scope rules at lines 24–28. The notes were read in full: pull counts and collection choices are in `ws/notes/pull_log_phase1.md`; do-not-read/internal history in `ws/notes/pass1.md`; entity boundaries, manual corrections, stale facts and intended phase 2 choices in `ws/notes/sense_check.md`.

Derived BD config facts:

```json
{
  "account": {"name": "Becton, Dickinson and Company", "short_name": "BD", "domains": ["bd.com"]},
  "pursuing_client_display": "Client",
  "dates": {
    "pull_date": "2026-10-19",
    "run_date": "2026-10-20",
    "posting_window": {"from": "2025-10-19", "to": "2026-10-19"},
    "news_window": {"from": "2025-04-19", "to": "2026-10-19"},
    "live_capture_date": "2026-10-19"
  },
  "lanes": ["Salesforce", "MuleSoft", "ServiceNow", "SAP", "Tableau", "Veeva", "Workday"],
  "out_of_scope_platforms": ["Databricks", "Siebel", "ServiceMax"],
  "entities_from_notes": [
    {"label": "Waters (divested business)", "counts_as_account": false, "rule": "Waters applying-for-position wording, Waters Biosciences or WBD"},
    {"label": "Biosciences and Diagnostic Solutions (divested Feb 2026)", "counts_as_account": false, "rule": "pre-close postings naming Biosciences, Diagnostic Solutions, Integrated Diagnostic Solutions or FlowJo; first seen 2025-10-19 through 2026-02-08"},
    {"label": "Liberator Medical Supply", "counts_as_account": true},
    {"label": "CR Bard / Safety Syringes", "counts_as_account": true}
  ],
  "canonical_answer_checks": {
    "Salesforce": {"total": 551, "open": 92},
    "SAP": {"total": 1068, "open": 150},
    "Waters": {"divested": 569, "pre_close": 116},
    "senior_people": {"senior": 424, "total": 736, "priority_a_senior": 80},
    "ranking": {"base": 1904, "A": ["SAP", "Salesforce", "Power BI"], "B": ["Microsoft Azure"]}
  }
}
```

This is a source-derived excerpt, not a fully schema-validated `workspace_config` instance. Phase 2 now statically extracts the platform dictionary, stack-lane map, people-lane names, checked list, stack names and drop pairs from the selected build inputs. A full instance still needs job-lane patterns, all job and people rules, notes-only boundaries, canonical query predicates/windows, and provenance for analyst-specific decisions. The candidate schema is at [`src/parity/schema/workspace_config.schema.json`](../../../src/parity/schema/workspace_config.schema.json).

## Golden run result

The exact archived `RESTORE.md` sequence ran successfully for the BD reference inside Bubblewrap with no network, no host home/secrets, and temporary writable storage. The content-free diff found four deliverables exact and two differing cells in the Jobs workbook (`Jobs!M81`, `Jobs!M98`, `Full description`). See [`inventory.md`](inventory.md). This does not establish parity for the other workspaces.

## Open questions and assumptions

1. **Target repo:** the task calls the target “Madrid,” while this checkout is an account-intelligence platform with a finished-deliverable library and workspace repair. Assume this repository is the intended target until corrected.
2. **Phase gate:** work stopped after Phase 1 for approval. The owner later approved Phase 2; implementation is now in progress.
3. **BD workspace variant:** `/home/sakib/Downloads/BD_workspace.zip` is used as the reference; the older BD inventory in the repo describes a different archive copy. The selected file is the 372-entry ZIP whose `RESTORE.md` and notes were read.
4. **Other workspaces:** inventories exist for all unique archives found in Downloads, but each still needs config validation and golden replay before acceptance.
5. **Golden restore:** the BD scripts ran only in Bubblewrap with no network, no host home/secrets and isolated writable storage. No other workspace scripts were executed.
6. **Privacy:** no workspace contents were sent to an external service. The BD configuration excerpt intentionally omits people names and private Client identity.

## Approved Phase 2 plan and current progress

1. Resolve the Madrid-versus-checkout product scope and decide whether Phase 2 is a legacy-workspace compatibility layer inside this product.
2. Safely inventory every unique archive, complete the `workspace_config` schema/instances with source paths and validated rules, and specify the config extraction/validation contract.
3. Build a non-executing importer for RESTORE/data/deliverables, isolate tenant storage, version config and expose a validation report; add malformed/oversized/traversal/symlink tests.
4. Reuse or extend deterministic repair/output code only where the logic map shows exact compatible rules; port legacy Jobs, People, ranking and doc sections behind config instead of running uploaded scripts.
5. Make backend table/count APIs authoritative and remove frontend count derivation; connect canonical query execution to structured queries and preserve strict-zero/relaxed labeling.
6. Add all-workspace golden comparisons, UI and chat parity checks, text-rule scans and tenant isolation coverage; document remaining unproven narrative and golden-run differences.

Phase 2 now provides bounded ZIP inspection and partial config derivation, owner-private versioned
upload, structural reports, parsed source views for all five deliverables, paged workbook APIs, an
audited client-deliverables-only download, backend-owned delivered summary counts and a reusable
content-free five-deliverable comparer. The normalized workspace pipeline, canonical chat routing
and all-workspace acceptance gate have not been completed.

The owner approved Phase 2 after reviewing the audit, as required by the pasted task's Phase 1 gate.
