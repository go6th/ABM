# Inventory: gsk

Files: 15; total 1892 KB

Top level: `(root)` (1), `build` (2), `data` (3), `deliverables` (8), `notes` (1)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 3847 | 37 lines |
| `build/patch_docs_sumble.py` | 11484 | 214 lines |
| `build/third_party_scan.py` | 2031 | 47 lines |
| `data/sumble/gsk_teams_platform_12mo.json` | 20038 | list[40] |
| `data/sumble/gsk_teams_raw_tool_result.json` | 175895 | list[1] |
| `data/sumble/gsk_tech_stack_confirmed_used.json` | 17750 | dict[1 keys]: business_functions |
| `deliverables/GSK_Account_Summary.docx` | 31987 | ERR AttributeError |
| `deliverables/GSK_Executive_Brief_Sep23_not_wanted.pptx` | 370299 |  |
| `deliverables/GSK_Job_Postings.xlsx` | 1053750 | Summary=15x8; Jobs=645x13 |
| `deliverables/GSK_People_List.xlsx` | 47448 | Summary=28x7; People=266x12 |
| `deliverables/GSK_Sources_and_Evidence.docx` | 78324 | ERR AttributeError |
| `deliverables/GSK_Tech_Stack_and_Teams.xlsx` | 21711 | Summary=17x3; Tech stack=183x6; Teams=41x6 |
| `deliverables/prior_sep23/GSK_Account_Summary.docx` | 31364 | ERR AttributeError |
| `deliverables/prior_sep23/GSK_Sources_and_Evidence.docx` | 70319 | ERR AttributeError |
| `notes/handoff_sep23.md` | 1524 | 13 lines |
