# Inventory: Premera_workspace

Files: 51; total 6377 KB

Top level: `(root)` (1), `build` (12), `data` (30), `deliverables` (5), `notes` (3)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 1097 | 11 lines |
| `build/build_stack.py` | 7073 | 44 lines |
| `build/build_xlsx.py` | 11123 | 117 lines |
| `build/docx_lib.js` | 4575 | 44 lines |
| `build/evidence.js` | 9833 | 56 lines |
| `build/ids.json` | 463 | list[80] |
| `build/jobs.json` | 583427 | list[67] |
| `build/jobs_hits.json` | 2164205 | list[244] |
| `build/jobs_model.py` | 6437 | 62 lines |
| `build/people.json` | 86438 | dict[2 keys]: rows,excluded |
| `build/people_model.py` | 9888 | 103 lines |
| `build/sources.json` | 22148 | dict[2 keys]: S,J |
| `build/summary.js` | 32845 | 207 lines |
| `data/comments_priority.md` | 693 | 5 lines |
| `data/jobs_12mo.json` | 2150194 | dict[5 keys]: domain,filter,count_reported,records,jobs |
| `data/jobs_techassoc_2yr.json` | 10678 | dict[3 keys]: meta,note,jobs |
| `data/live_board.json` | 5509 | dict[6 keys]: careers_page,verified_board,verified_how,searches,not_searched_on_live_board,unique_live_postings |
| `data/news_events.json` | 2960 | dict[7 keys]: domain,window,count_reported,kept,dropped,feed_message |
| `data/newsroom.json` | 8243 | dict[3 keys]: release_wire_list,healthsource_news,site_map_search_news |
| `data/people_grid.json` | 215931 | dict[4 keys]: grid,rows,sources,people |
| `data/people_grid.txt` | 14695 | 109 lines |
| `data/people_techassoc.json` | 27276 | dict[4 keys]: meta,pulls,counts,people |
| `data/posts_priority_grid1.json` | 99752 | list[13] |
| `data/posts_priority_grid2.json` | 32491 | list[4] |
| `data/profiles_full_grid1.json` | 356404 | list[54] |
| `data/profiles_full_grid2.json` | 274683 | list[56] |
| `data/releases/2024-08-12_cfo_talha_ashraf.md` | 800 | 4 lines |
| `data/releases/2025-08-19_health_hub.md` | 1041 | 5 lines |
| `data/releases/2025-10-06_board_two_directors.md` | 976 | 4 lines |
| `data/releases/2025-10-23_conduent_incident.md` | 899 | 3 lines |
| `data/releases/2026-01-06_cancer_support_thyme_care.md` | 766 | 4 lines |
| `data/releases/2026-03-11_podcast_evp_healthcare_services.md` | 809 | 4 lines |
| `data/releases/2026-04-16_multicare_negotiations.md` | 591 | 3 lines |
| `data/releases/2026-04-17_vendor_story_microsoft_copilot.md` | 1696 | 13 lines |
| `data/releases/2026-05-14_ai_mainstream_microsoft.md` | 721 | 6 lines |
| `data/releases/2026-06-30_north_star_alice_clara.md` | 1121 | 9 lines |
| `data/releases/2026-09-08_vendor_story_microsoft_azure_facets.md` | 1699 | 17 lines |
| `data/releases/affiliates_page.md` | 840 | 4 lines |
| `data/teams.json` | 5631 | dict[3 keys]: meta,note,teams |
| `data/techstack_confirmed.json` | 5125 | dict[2 keys]: meta,tech_stack |
| `data/techstack_detections.json` | 72431 | dict[6 keys]: domain,filter,count_reported,meta_message,parent_company_domain,detections |
| `data/web_searches.json` | 12226 | dict[1 keys]: searches |
| `data/web_searches_phase2.json` | 2993 | dict[1 keys]: phase2_searches |
| `deliverables/Premera_Account_Summary.docx` | 42239 | ERR AttributeError |
| `deliverables/Premera_Job_Postings.xlsx` | 110101 | Summary=29x9; Jobs=68x13 |
| `deliverables/Premera_People_List.xlsx` | 30651 | Summary=39x8; People=166x15 |
| `deliverables/Premera_Sources_and_Evidence.docx` | 45587 | ERR AttributeError |
| `deliverables/Premera_Tech_Stack_and_Teams.xlsx` | 22439 | Summary=6x6; Confirmed stack=29x5; Platform teams=26x4; Detections=56x7; Named in profiles=11x4 |
| `notes/pass1.md` | 1266 | 11 lines |
| `notes/pull_log.md` | 12164 | 82 lines |
| `notes/sense_check.md` | 16818 | 106 lines |
