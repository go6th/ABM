# Inventory: QuidelOrtho_workspace.zip

Archive: `/home/sakib/Downloads/QuidelOrtho_workspace.zip`
SHA-256: `55eadaf0f3ab31b2bbba0fd13db58c29b2ed472b46fcc628083109892c46e0e1`
Archive bytes: 4073958

Members: 189; uncompressed bytes: 18940716

| Path | Bytes | Type / counts |
|---|---:|---|
| `QuidelOrtho/` | 0 | file |
| `QuidelOrtho/deliverables/` | 0 | file |
| `QuidelOrtho/deliverables/QuidelOrtho_People_List.xlsx` | 132779 | XLSX; Summary=53 rows, People=312 rows, Excluded=12 rows, Below rule, not kept=1099 rows |
| `QuidelOrtho/deliverables/QuidelOrtho_Tech_Stack_and_Teams.xlsx` | 26839 | XLSX; Platform Ranking=28 rows, Confirmed stack=87 rows, Platform teams=29 rows, Detections=63 rows |
| `QuidelOrtho/deliverables/QuidelOrtho_Sources_and_Evidence.docx` | 73404 | DOCX; DOCX 17 headings, 14 tables; headings: Heading 1: Part A: Source register / Heading 1: Part B: Postings read in full / Heading 1: Part C: Lane postings read one by one / Heading 2: Salesforce: 11 postings / Heading 2: ServiceNow: 2 postings / Heading 2: Tableau: 4 postings / Heading 2: Veeva: 1 postings / Heading 2: SAP: 125 postings / Heading 1: Part D: Video and article extracts / Heading 1: Part E: Live careers board capture (Oct 11 2026) / Heading 1: Part F: Leads not verified / Heading 1: Part G: Keeping copies of the original pages / Heading 1: Part H: Data pulls / Heading 2: Technology detections, lane relevant (S73) / Heading 2: News events feed, Apr 2025 to Oct 2026 (S77) / Heading 2: Posting counts by platform, last 12 months (S70, S71, S72) / Heading 1: Part I: Full URLs |
| `QuidelOrtho/deliverables/QuidelOrtho_Account_Summary.docx` | 51121 | DOCX; DOCX 25 headings, 14 tables; headings: Heading 1: How to read this file / Heading 1: The account in plain words / Heading 2: The account picture / Heading 2: What stands out for the Client / Heading 2: What it likely means for each lane (interpretation) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: Recent news / Heading 1: Company and transformation baseline / Heading 1: Signals / Heading 2: Tier 1: close to budget / Heading 2: Tier 2: one step removed / Heading 2: Tier 3: context and openers / Heading 2: Context and history / Heading 1: Platform picture by lane / Heading 1: People / Heading 2: Findings from profiles / Heading 2: People whose status changed / Heading 2: Findings from LinkedIn activity / Heading 1: Hypotheses to test / Heading 1: Questions for a first conversation / Heading 1: Research coverage tracker / Heading 2: Pass 1: summary homework / Heading 2: Pass 2: detailed homework / Heading 1: Source links |
| `QuidelOrtho/deliverables/QuidelOrtho_Job_Postings.xlsx` | 179758 | XLSX; Summary=20 rows, Jobs=157 rows |
| `QuidelOrtho/notes/` | 0 | file |
| `QuidelOrtho/notes/pass1.md` | 374 | MD |
| `QuidelOrtho/notes/sense_check.md` | 10354 | MD |
| `QuidelOrtho/RESTORE.md` | 2336 | MD |
| `QuidelOrtho/data/` | 0 | file |
| `QuidelOrtho/data/teams.json` | 66078 | JSON; JSON object, 5 keys; arrays: teams[25] |
| `QuidelOrtho/data/live_board.json` | 13582 | JSON; JSON object, 2 keys; arrays: meta.it_category_page.postings[2], postings[31] |
| `QuidelOrtho/data/leadership.md` | 6082 | MD |
| `QuidelOrtho/data/signals_contacts.json` | 3601 | JSON; JSON object, 10 keys; arrays: hits[9], no_signals[23] |
| `QuidelOrtho/data/baseline_pull_log.md` | 16499 | MD |
| `QuidelOrtho/data/news_events_legacy.json` | 1739 | JSON; JSON array, 4 records |
| `QuidelOrtho/data/company_search_log.md` | 13602 | MD |
| `QuidelOrtho/data/connections.json` | 71383 | JSON; JSON object, 2 keys; arrays: domains.quidelortho.com.rows[186], domains.quidel.com.rows[128] |
| `QuidelOrtho/data/techstack_detections_ortho_legacy.json` | 13201 | JSON; JSON object, 2 keys; arrays: rows[38] |
| `QuidelOrtho/data/techstack_detections_quidelortho.json` | 40447 | JSON; JSON object, 2 keys; arrays: rows[148] |
| `QuidelOrtho/data/techstack_confirmed.json` | 3121 | JSON; JSON object, 6 keys |
| `QuidelOrtho/data/leadership.json` | 1151 | JSON; JSON object, 3 keys; arrays: executives[12] |
| `QuidelOrtho/data/company_profile.json` | 1262 | JSON; JSON object, 9 keys; arrays: subsidiary_domains_feed[2], similar_companies_feed[5], selected_locations_feed[26] |
| `QuidelOrtho/data/transcripts/` | 0 | file |
| `QuidelOrtho/data/transcripts/Q3_2025.md` | 33862 | MD |
| `QuidelOrtho/data/transcripts/Q2_2026.md` | 24481 | MD |
| `QuidelOrtho/data/transcripts/Q1_2026.md` | 23434 | MD |
| `QuidelOrtho/data/transcripts/Q4_2025.md` | 51682 | MD |
| `QuidelOrtho/data/person_pages/` | 0 | file |
| `QuidelOrtho/data/person_pages/karen-taylor_repertoire-podcast.md` | 1745 | MD |
| `QuidelOrtho/data/person_pages/sarah-englert_adlm2026-booth-video.md` | 1590 | MD |
| `QuidelOrtho/data/person_pages/karen-taylor_award-quotes.md` | 3825 | MD |
| `QuidelOrtho/data/person_pages/laura-comilla_adlm2026-booth-video.md` | 1342 | MD |
| `QuidelOrtho/data/person_pages/award-entry_stevie-2026-gold-customer-service.md` | 5784 | MD |
| `QuidelOrtho/data/person_pages/laura-comilla_speaker-site.md` | 2271 | MD |
| `QuidelOrtho/data/person_pages/audra-jones_repertoire-podcast-youtube.md` | 8030 | MD |
| `QuidelOrtho/data/person_pages/jonathan-siegrist_science-bytes-ep54.md` | 3699 | MD |
| `QuidelOrtho/data/org_signals.json` | 319 | JSON; JSON array, 1 records |
| `QuidelOrtho/data/web_searches_phase2.json` | 5181 | JSON; JSON array, 8 records |
| `QuidelOrtho/data/jobs_erp_gapfill.json` | 611783 | JSON; JSON object, 7 keys; arrays: query_technologies[2], rows[102] |
| `QuidelOrtho/data/releases/` | 0 | file |
| `QuidelOrtho/data/releases/2026-06-23_cfo-micah-young.md` | 4124 | MD |
| `QuidelOrtho/data/releases/2026-02-03_stevie-awards-excellence-services-label.md` | 5728 | MD |
| `QuidelOrtho/data/releases/2025-05-07_q1-2025-results.md` | 8534 | MD |
| `QuidelOrtho/data/releases/2026-04-20_lex-diagnostics-acquisition-completed.md` | 6450 | MD |
| `QuidelOrtho/data/releases/2025-09-22_quickvue-influenza-sars-test-launch.md` | 3408 | MD |
| `QuidelOrtho/data/releases/2025-07-07_svp-global-quality-and-clinical-regulatory-appointments.md` | 3540 | MD |
| `QuidelOrtho/data/releases/2025-10-16_aabb-2025-transfusion-medicine-mts-dat-card.md` | 4113 | MD |
| `QuidelOrtho/data/releases/2026-05-05_q1-2026-results.md` | 11067 | MD |
| `QuidelOrtho/data/releases/2026-10-06_raritan-nj-facility-closure-2027_news.md` | 4058 | MD |
| `QuidelOrtho/data/releases/2026-02-11_q4-fy2025-results.md` | 20298 | MD |
| `QuidelOrtho/data/releases/2025-08-13_certified-analyzer-program-launch.md` | 2762 | MD |
| `QuidelOrtho/data/releases/2025-07-29_imv-servicetrak-customer-service-awards.md` | 3950 | MD |
| `QuidelOrtho/data/releases/2025-07-14_buhlmann-fcal-fpela-assays-on-vitros.md` | 5128 | MD |
| `QuidelOrtho/data/releases/2025-10-23_informatics-science-bytes-podcast.md` | 2249 | MD |
| `QuidelOrtho/data/releases/2025-06-03_molecular-strategy-lex-intent-savanna-discontinued.md` | 6985 | MD |
| `QuidelOrtho/data/releases/2025-11-03_vitros-hs-troponin-i-fda-clearance.md` | 3716 | MD |
| `QuidelOrtho/data/releases/2025-08-21_debt-refinancing.md` | 3029 | MD |
| `QuidelOrtho/data/releases/2026-04-15_q1-2026-preliminary-revenue-guidance-update.md` | 5420 | MD |
| `QuidelOrtho/data/releases/2025-08-05_q2-2025-results.md` | 10075 | MD |
| `QuidelOrtho/data/releases/2025-08-19_evp-strategy-erich-wolff.md` | 4058 | MD |
| `QuidelOrtho/data/releases/lex-diagnostics_profile.md` | 6824 | MD |
| `QuidelOrtho/data/releases/2026-06-02_allo-hope-foundation-collaboration.md` | 3935 | MD |
| `QuidelOrtho/data/releases/2025-11-05_q3-2025-results.md` | 17771 | MD |
| `QuidelOrtho/data/releases/2026-10-07_vp-investor-relations-sanjeev-sharma.md` | 3412 | MD |
| `QuidelOrtho/data/releases/2026-02-16_strategic-supply-agreement-immunoassay.md` | 5901 | MD |
| `QuidelOrtho/data/releases/2026-03-24_chief-legal-officer-nathaniel-sisitsky.md` | 4404 | MD |
| `QuidelOrtho/data/releases/2026-08-06_q2-2026-results.md` | 13934 | MD |
| `QuidelOrtho/data/posts_comments.json` | 1295326 | JSON; JSON object, 2 keys; arrays: rows[85] |
| `QuidelOrtho/data/techstack_detections_quidel_legacy.json` | 19442 | JSON; JSON object, 2 keys; arrays: rows[79] |
| `QuidelOrtho/data/filings/` | 0 | file |
| `QuidelOrtho/data/filings/8K_list.md` | 5630 | MD |
| `QuidelOrtho/data/filings/10K_FY2025_extracts.md` | 174117 | MD |
| `QuidelOrtho/data/filings/10Q_Q2_2026_MDA.md` | 20182 | MD |
| `QuidelOrtho/data/news_events_quidelortho.json` | 23349 | JSON; JSON object, 2 keys; arrays: rows[23] |
| `QuidelOrtho/data/contact_lookups.json` | 2024 | JSON; JSON object, 5 keys; arrays: records[3] |
| `QuidelOrtho/data/web_searches.json` | 44632 | JSON; JSON array, 76 records |
| `QuidelOrtho/data/web_pages/` | 0 | file |
| `QuidelOrtho/data/web_pages/uipath_forward_session_quidelortho_s4hana_2024.txt` | 1215 | TXT |
| `QuidelOrtho/data/web_pages/quidelortho_ciso_article_ai_analytics_2024.txt` | 6298 | TXT |
| `QuidelOrtho/data/web_pages/appexchange_swift_account_manager_listing.txt` | 1643 | TXT |
| `QuidelOrtho/data/web_pages/origentech_ortho_clinical_case_search_excerpt.txt` | 717 | TXT |
| `QuidelOrtho/data/web_pages/e360_cloud_business_office_quidelortho.txt` | 2189 | TXT |
| `QuidelOrtho/data/web_pages/stevie_2026_ai_digital_transformation_category_winners.txt` | 1295 | TXT |
| `QuidelOrtho/data/web_pages/vertex_customer_story_quidelortho_sap_2025.txt` | 5720 | TXT |
| `QuidelOrtho/data/web_pages/highspot_story_quidelortho_2025.txt` | 924 | TXT |
| `QuidelOrtho/data/web_pages/stevie_2026_gold_entry_quidelortho_customer_service.txt` | 5843 | TXT |
| `QuidelOrtho/data/web_pages/trailblazer_post_mulesoft_cloudhub_2020.txt` | 1153 | TXT |
| `QuidelOrtho/data/web_pages/trailhead_ortho_field_sales_trailmix.txt` | 1627 | TXT |
| `QuidelOrtho/data/web_pages/uipath_forward_2024_agenda_session_quidelortho.txt` | 1280 | TXT |
| `QuidelOrtho/data/web_pages/sap_community_life_sciences_sapphire_tag_page.txt` | 729 | TXT |
| `QuidelOrtho/data/web_pages/sap_enterprise_support_quidelortho_2026.txt` | 836 | TXT |
| `QuidelOrtho/data/web_pages/prnewswire_quidelortho_stevie_excellence_label_2026.txt` | 5053 | TXT |
| `QuidelOrtho/data/web_pages/quidelortho_cq_program_page.txt` | 3104 | TXT |
| `QuidelOrtho/data/web_pages/trailblazer_post_data_cloud_trailhead_2024.txt` | 1465 | TXT |
| `QuidelOrtho/data/web_pages/origentech_sap_tdf_ortho_clinical_case.txt` | 2784 | TXT |
| `QuidelOrtho/data/jobs_12mo.json` | 1367854 | JSON; JSON object, 4 keys; arrays: rows[206] |
| `QuidelOrtho/data/subsidiary_domains.json` | 863 | JSON; JSON object, 2 keys; arrays: domains.myquidel.com.tech_detections_24mo.technologies[17] |
| `QuidelOrtho/data/newsroom.json` | 28017 | JSON; JSON object, 7 keys; arrays: sources[4], releases[50], also_saved_not_a_company_release[2] |
| `QuidelOrtho/data/people_gapcheck.json` | 5632 | JSON; JSON object, 5 keys; arrays: results.salesforce[5], results.mulesoft[0], results.servicenow[0], results.sap[8], results.tableau[1], results.veeva[0], new_people[6] |
| `QuidelOrtho/data/youtube/` | 0 | file |
| `QuidelOrtho/data/youtube/quidelorthocq_customer_experience_2026.txt` | 5283 | TXT |
| `QuidelOrtho/data/youtube/quidelortho_our_integration_story_2023.txt` | 4228 | TXT |
| `QuidelOrtho/data/youtube/quidel_azure_iot_customer_tech_talks_2021.txt` | 17789 | TXT |
| `QuidelOrtho/data/signals_company.json` | 260804 | JSON; JSON object, 9 keys; arrays: calls[3], company.industries[1], signals[118] |
| `QuidelOrtho/data/FILE_INDEX.md` | 1535 | MD |
| `QuidelOrtho/data/live_postings/` | 0 | file |
| `QuidelOrtho/data/live_postings/R0016986.md` | 6479 | MD |
| `QuidelOrtho/data/live_postings/R0016926.md` | 10854 | MD |
| `QuidelOrtho/data/live_postings/R0016963_1.md` | 12047 | MD |
| `QuidelOrtho/data/live_postings/R0016970.md` | 12311 | MD |
| `QuidelOrtho/data/live_postings/R0017108.md` | 11187 | MD |
| `QuidelOrtho/data/live_postings/R0017082.md` | 9173 | MD |
| `QuidelOrtho/data/live_postings/R0017050.md` | 12772 | MD |
| `QuidelOrtho/data/live_postings/R0016797.md` | 9989 | MD |
| `QuidelOrtho/data/live_postings/R0016868.md` | 14497 | MD |
| `QuidelOrtho/data/live_postings/R0016855.md` | 12371 | MD |
| `QuidelOrtho/data/live_postings/R0016832.md` | 12062 | MD |
| `QuidelOrtho/data/live_postings/R0016755.md` | 11468 | MD |
| `QuidelOrtho/data/live_postings/R0017024.md` | 13107 | MD |
| `QuidelOrtho/data/live_postings/R0016830.md` | 15252 | MD |
| `QuidelOrtho/data/live_postings/R0017099.md` | 11108 | MD |
| `QuidelOrtho/data/live_postings/R0016976_1.md` | 12450 | MD |
| `QuidelOrtho/data/live_postings/R0016767.md` | 6479 | MD |
| `QuidelOrtho/data/live_postings/R0017071.md` | 13351 | MD |
| `QuidelOrtho/data/live_postings/R0016219.md` | 9571 | MD |
| `QuidelOrtho/data/live_postings/R0016822.md` | 11908 | MD |
| `QuidelOrtho/data/live_postings/R0016540.md` | 10151 | MD |
| `QuidelOrtho/data/live_postings/R0016215_4.md` | 12609 | MD |
| `QuidelOrtho/data/live_postings/R0016863.md` | 11168 | MD |
| `QuidelOrtho/data/live_postings/R0016189.md` | 13073 | MD |
| `QuidelOrtho/data/live_postings/R0016852.md` | 11993 | MD |
| `QuidelOrtho/data/live_postings/R0016991.md` | 12495 | MD |
| `QuidelOrtho/data/live_postings/R0016294.md` | 9070 | MD |
| `QuidelOrtho/data/live_postings/R0016279_1.md` | 13939 | MD |
| `QuidelOrtho/data/live_postings/R0016638.md` | 11869 | MD |
| `QuidelOrtho/data/live_postings/R0016770.md` | 13916 | MD |
| `QuidelOrtho/data/live_postings/R0016831.md` | 12806 | MD |
| `QuidelOrtho/data/people_grid.json` | 1928332 | JSON; JSON object, 3 keys; arrays: searches.platform A.titles[17], searches.platform A.domains[3], searches.platform B.titles[22], searches.platform B.domains[3], searches.leadership.domains[3], searches.LEX adjacent.domains[1], searches.v1.11 source 1.domains[3], searches.v1.11 source 2.domains[3], rows[1445] |
| `QuidelOrtho/data/company_basics.md` | 10954 | MD |
| `QuidelOrtho/data/jobs_lane_gapfill.json` | 196094 | JSON; JSON object, 5 keys; arrays: query_technologies[8], rows[34] |
| `QuidelOrtho/data/profiles_full.json` | 2835287 | JSON; JSON object, 2 keys; arrays: rows[458] |
| `QuidelOrtho/data/live_board_log.md` | 5706 | MD |
| `QuidelOrtho/data/investor_conferences.md` | 13889 | MD |
| `QuidelOrtho/data/live_board_sitemap.json` | 4176 | JSON; JSON object, 4 keys; arrays: urls[31], lastmod[0] |
| `QuidelOrtho/data/person_search_log.md` | 10199 | MD |
| `QuidelOrtho/data/former_executives.json` | 1262 | JSON; JSON array, 3 records |
| `QuidelOrtho/data/person_searches.json` | 33106 | JSON; JSON array, 50 records |
| `QuidelOrtho/build/` | 0 | file |
| `QuidelOrtho/build/profile_findings.py` | 3174 | PY |
| `QuidelOrtho/build/evidence_blocks.json` | 108903 | JSON; JSON array, 44 records |
| `QuidelOrtho/build/docx_lib.js` | 4575 | JS |
| `QuidelOrtho/build/new_profiles_raw.json` | 202437 | JSON; JSON object, 23 keys |
| `QuidelOrtho/build/stack_names.json` | 1124 | JSON; JSON array, 80 records |
| `QuidelOrtho/build/profile_pick_phase2b.json` | 385 | JSON; JSON array, 50 records |
| `QuidelOrtho/build/jobs_rows.json` | 1007573 | JSON; JSON array, 156 records |
| `QuidelOrtho/build/urls.json` | 22546 | JSON; JSON object, 2 keys; arrays: S.S1[6], S.S2[6], S.S3[6], S.S4[6], S.S5[6], S.S6[6], S.S7[6], S.S8[6], S.S9[6], S.S10[6], S.S11[6], S.S12[6] |
| `QuidelOrtho/build/ranking_notes.py` | 1636 | PY |
| `QuidelOrtho/build/ids.json` | 633 | JSON; JSON array, 93 records |
| `QuidelOrtho/build/new_manager_rows.json` | 1210267 | JSON; JSON array, 881 records |
| `QuidelOrtho/build/summary_blocks.json` | 64041 | JSON; JSON array, 64 records |
| `QuidelOrtho/build/render.js` | 3383 | JS |
| `QuidelOrtho/build/content_evidence.py` | 17301 | PY |
| `QuidelOrtho/build/build_stack.py` | 6734 | PY |
| `QuidelOrtho/build/lane_sent.py` | 1221 | PY |
| `QuidelOrtho/build/checked.json` | 52 | JSON; JSON array, 4 records |
| `QuidelOrtho/build/prof.py` | 1468 | PY |
| `QuidelOrtho/build/QuidelOrtho_Account_Summary.txt` | 72195 | TXT |
| `QuidelOrtho/build/jobs_combined.json` | 2219352 | JSON; JSON array, 320 records |
| `QuidelOrtho/build/new_manager_qualifiers.json` | 304188 | JSON; JSON array, 189 records |
| `QuidelOrtho/build/platform_ranking.py` | 10898 | PY |
| `QuidelOrtho/build/QuidelOrtho_Sources_and_Evidence.txt` | 141093 | TXT |
| `QuidelOrtho/build/content_summary.py` | 44526 | PY |
| `QuidelOrtho/build/build_jobs.py` | 12922 | PY |
| `QuidelOrtho/build/people.json` | 873214 | JSON; JSON object, 3 keys; arrays: kept[311], excluded[11], below[1098] |
| `QuidelOrtho/build/jobs_for_ranking.json` | 2104594 | JSON; JSON array, 320 records |
| `QuidelOrtho/build/make_ranking_input.py` | 800 | PY |
| `QuidelOrtho/build/status.py` | 1868 | PY |
| `QuidelOrtho/build/scan.py` | 1640 | PY |
| `QuidelOrtho/build/tracker_tally.json` | 89 | JSON; JSON object, 2 keys |
| `QuidelOrtho/build/combine_jobs.py` | 2692 | PY |
| `QuidelOrtho/build/status.json` | 14892 | JSON; JSON object, 564 keys; arrays: 1[2], 2[2], 3[2], 4[2], 5[2], 6[2], 7[2], 8[2], 9[2], 10[2], 11[2], 12[2] |
| `QuidelOrtho/build/status2.py` | 1874 | PY |
| `QuidelOrtho/build/urls.py` | 22968 | PY |
| `QuidelOrtho/build/build_people_xlsx.py` | 8082 | PY |
| `QuidelOrtho/build/build_people.py` | 18104 | PY |
| `QuidelOrtho/pull_log.md` | 23546 | MD |
