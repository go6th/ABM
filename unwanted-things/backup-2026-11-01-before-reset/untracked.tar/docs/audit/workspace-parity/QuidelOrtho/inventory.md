# Inventory: QuidelOrtho

Files: 177; total 18496 KB

Top level: `(root)` (2), `build` (37), `data` (131), `deliverables` (5), `notes` (2)

| Path | Bytes | Content |
|---|---:|---|
| `RESTORE.md` | 2336 | 26 lines |
| `build/QuidelOrtho_Account_Summary.txt` | 72195 | 994 lines |
| `build/QuidelOrtho_Sources_and_Evidence.txt` | 141093 | 1685 lines |
| `build/build_jobs.py` | 12922 | 148 lines |
| `build/build_people.py` | 18104 | 249 lines |
| `build/build_people_xlsx.py` | 8082 | 92 lines |
| `build/build_stack.py` | 6734 | 76 lines |
| `build/checked.json` | 52 | list[4] |
| `build/combine_jobs.py` | 2692 | 46 lines |
| `build/content_evidence.py` | 17301 | 149 lines |
| `build/content_summary.py` | 44526 | 325 lines |
| `build/docx_lib.js` | 4575 | 44 lines |
| `build/evidence_blocks.json` | 108903 | list[44] |
| `build/ids.json` | 633 | list[93] |
| `build/jobs_combined.json` | 2219352 | list[320] |
| `build/jobs_for_ranking.json` | 2104594 | list[320] |
| `build/jobs_rows.json` | 1007573 | list[156] |
| `build/lane_sent.py` | 1221 | 22 lines |
| `build/make_ranking_input.py` | 800 | 13 lines |
| `build/new_manager_qualifiers.json` | 304188 | list[189] |
| `build/new_manager_rows.json` | 1210267 | list[881] |
| `build/new_profiles_raw.json` | 202437 | dict[23 keys]: 452,453,460,465,467,473 |
| `build/people.json` | 873214 | dict[3 keys]: kept,excluded,below |
| `build/platform_ranking.py` | 10898 | 184 lines |
| `build/prof.py` | 1468 | 24 lines |
| `build/profile_findings.py` | 3174 | 52 lines |
| `build/profile_pick_phase2b.json` | 385 | list[50] |
| `build/ranking_notes.py` | 1636 | 13 lines |
| `build/render.js` | 3383 | 49 lines |
| `build/scan.py` | 1640 | 19 lines |
| `build/stack_names.json` | 1124 | list[80] |
| `build/status.json` | 14892 | dict[564 keys]: 1,2,3,4,5,6 |
| `build/status.py` | 1868 | 33 lines |
| `build/status2.py` | 1874 | 33 lines |
| `build/summary_blocks.json` | 64041 | list[64] |
| `build/tracker_tally.json` | 89 | dict[2 keys]: tally,rows |
| `build/urls.json` | 22546 | dict[2 keys]: S,J |
| `build/urls.py` | 22968 | 107 lines |
| `data/FILE_INDEX.md` | 1535 | 23 lines |
| `data/baseline_pull_log.md` | 16499 | 97 lines |
| `data/company_basics.md` | 10954 | 86 lines |
| `data/company_profile.json` | 1262 | dict[9 keys]: domain,company_name,ticker,headquarters_feed,description_feed,parent_company_domain_feed |
| `data/company_search_log.md` | 13602 | 114 lines |
| `data/connections.json` | 71383 | dict[2 keys]: source,domains |
| `data/contact_lookups.json` | 2024 | dict[5 keys]: pulled,tool,grade,note,records |
| `data/filings/10K_FY2025_extracts.md` | 174117 | 987 lines |
| `data/filings/10Q_Q2_2026_MDA.md` | 20182 | 166 lines |
| `data/filings/8K_list.md` | 5630 | 28 lines |
| `data/former_executives.json` | 1262 | list[3] |
| `data/investor_conferences.md` | 13889 | 114 lines |
| `data/jobs_12mo.json` | 1367854 | dict[4 keys]: count_reported,count_saved,by_domain,rows |
| `data/jobs_erp_gapfill.json` | 611783 | dict[7 keys]: source,pulled,query_technologies,total_matched,overlap_with_gapfill,total |
| `data/jobs_lane_gapfill.json` | 196094 | dict[5 keys]: source,pulled,query_technologies,total,rows |
| `data/leadership.json` | 1151 | dict[3 keys]: source,scraped,executives |
| `data/leadership.md` | 6082 | 68 lines |
| `data/live_board.json` | 13582 | dict[2 keys]: meta,postings |
| `data/live_board_log.md` | 5706 | 56 lines |
| `data/live_board_sitemap.json` | 4176 | dict[4 keys]: source,fetched,urls,lastmod |
| `data/live_postings/R0016189.md` | 13073 | 154 lines |
| `data/live_postings/R0016215_4.md` | 12609 | 153 lines |
| `data/live_postings/R0016219.md` | 9571 | 211 lines |
| `data/live_postings/R0016279_1.md` | 13939 | 195 lines |
| `data/live_postings/R0016294.md` | 9070 | 111 lines |
| `data/live_postings/R0016540.md` | 10151 | 164 lines |
| `data/live_postings/R0016638.md` | 11869 | 158 lines |
| `data/live_postings/R0016755.md` | 11468 | 168 lines |
| `data/live_postings/R0016767.md` | 6479 | 91 lines |
| `data/live_postings/R0016770.md` | 13916 | 181 lines |
| `data/live_postings/R0016797.md` | 9989 | 157 lines |
| `data/live_postings/R0016822.md` | 11908 | 170 lines |
| `data/live_postings/R0016830.md` | 15252 | 285 lines |
| `data/live_postings/R0016831.md` | 12806 | 235 lines |
| `data/live_postings/R0016832.md` | 12062 | 227 lines |
| `data/live_postings/R0016852.md` | 11993 | 183 lines |
| `data/live_postings/R0016855.md` | 12371 | 181 lines |
| `data/live_postings/R0016863.md` | 11168 | 157 lines |
| `data/live_postings/R0016868.md` | 14497 | 213 lines |
| `data/live_postings/R0016926.md` | 10854 | 199 lines |
| `data/live_postings/R0016963_1.md` | 12047 | 164 lines |
| `data/live_postings/R0016970.md` | 12311 | 174 lines |
| `data/live_postings/R0016976_1.md` | 12450 | 141 lines |
| `data/live_postings/R0016986.md` | 6479 | 91 lines |
| `data/live_postings/R0016991.md` | 12495 | 227 lines |
| `data/live_postings/R0017024.md` | 13107 | 194 lines |
| `data/live_postings/R0017050.md` | 12772 | 181 lines |
| `data/live_postings/R0017071.md` | 13351 | 192 lines |
| `data/live_postings/R0017082.md` | 9173 | 162 lines |
| `data/live_postings/R0017099.md` | 11108 | 157 lines |
| `data/live_postings/R0017108.md` | 11187 | 154 lines |
| `data/news_events_legacy.json` | 1739 | list[4] |
| `data/news_events_quidelortho.json` | 23349 | dict[2 keys]: meta,rows |
| `data/newsroom.json` | 28017 | dict[7 keys]: what_this_is,sources,coverage_note,count,releases,also_saved_not_a_company_release |
| `data/org_signals.json` | 319 | list[1] |
| `data/people_gapcheck.json` | 5632 | dict[5 keys]: pulled,rule,lane_coverage_check,results,new_people |
| `data/people_grid.json` | 1928332 | dict[3 keys]: source,searches,rows |
| `data/person_pages/audra-jones_repertoire-podcast-youtube.md` | 8030 | 32 lines |
| `data/person_pages/award-entry_stevie-2026-gold-customer-service.md` | 5784 | 26 lines |
| `data/person_pages/jonathan-siegrist_science-bytes-ep54.md` | 3699 | 29 lines |
| `data/person_pages/karen-taylor_award-quotes.md` | 3825 | 19 lines |
| `data/person_pages/karen-taylor_repertoire-podcast.md` | 1745 | 14 lines |
| `data/person_pages/laura-comilla_adlm2026-booth-video.md` | 1342 | 11 lines |
| `data/person_pages/laura-comilla_speaker-site.md` | 2271 | 33 lines |
| `data/person_pages/sarah-englert_adlm2026-booth-video.md` | 1590 | 15 lines |
| `data/person_search_log.md` | 10199 | 57 lines |
| `data/person_searches.json` | 33106 | list[50] |
| `data/posts_comments.json` | 1295326 | dict[2 keys]: source,rows |
| `data/profiles_full.json` | 2835287 | dict[2 keys]: source,rows |
| `data/releases/2025-05-07_q1-2025-results.md` | 8534 | 106 lines |
| `data/releases/2025-06-03_molecular-strategy-lex-intent-savanna-discontinued.md` | 6985 | 55 lines |
| `data/releases/2025-07-07_svp-global-quality-and-clinical-regulatory-appointments.md` | 3540 | 31 lines |
| `data/releases/2025-07-14_buhlmann-fcal-fpela-assays-on-vitros.md` | 5128 | 46 lines |
| `data/releases/2025-07-29_imv-servicetrak-customer-service-awards.md` | 3950 | 55 lines |
| `data/releases/2025-08-05_q2-2025-results.md` | 10075 | 110 lines |
| `data/releases/2025-08-13_certified-analyzer-program-launch.md` | 2762 | 29 lines |
| `data/releases/2025-08-19_evp-strategy-erich-wolff.md` | 4058 | 37 lines |
| `data/releases/2025-08-21_debt-refinancing.md` | 3029 | 33 lines |
| `data/releases/2025-09-22_quickvue-influenza-sars-test-launch.md` | 3408 | 33 lines |
| `data/releases/2025-10-16_aabb-2025-transfusion-medicine-mts-dat-card.md` | 4113 | 43 lines |
| `data/releases/2025-10-23_informatics-science-bytes-podcast.md` | 2249 | 33 lines |
| `data/releases/2025-11-03_vitros-hs-troponin-i-fda-clearance.md` | 3716 | 36 lines |
| `data/releases/2025-11-05_q3-2025-results.md` | 17771 | 244 lines |
| `data/releases/2026-02-03_stevie-awards-excellence-services-label.md` | 5728 | 47 lines |
| `data/releases/2026-02-11_q4-fy2025-results.md` | 20298 | 313 lines |
| `data/releases/2026-02-16_strategic-supply-agreement-immunoassay.md` | 5901 | 41 lines |
| `data/releases/2026-03-24_chief-legal-officer-nathaniel-sisitsky.md` | 4404 | 35 lines |
| `data/releases/2026-04-15_q1-2026-preliminary-revenue-guidance-update.md` | 5420 | 44 lines |
| `data/releases/2026-04-20_lex-diagnostics-acquisition-completed.md` | 6450 | 47 lines |
| `data/releases/2026-05-05_q1-2026-results.md` | 11067 | 166 lines |
| `data/releases/2026-06-02_allo-hope-foundation-collaboration.md` | 3935 | 35 lines |
| `data/releases/2026-06-23_cfo-micah-young.md` | 4124 | 33 lines |
| `data/releases/2026-08-06_q2-2026-results.md` | 13934 | 188 lines |
| `data/releases/2026-10-06_raritan-nj-facility-closure-2027_news.md` | 4058 | 60 lines |
| `data/releases/2026-10-07_vp-investor-relations-sanjeev-sharma.md` | 3412 | 27 lines |
| `data/releases/lex-diagnostics_profile.md` | 6824 | 34 lines |
| `data/signals_company.json` | 260804 | dict[9 keys]: pulled,tool,domain,detected_after,calls,company |
| `data/signals_contacts.json` | 3601 | dict[10 keys]: pulled,tool,grade,method,scope,looked_up |
| `data/subsidiary_domains.json` | 863 | dict[2 keys]: pulled,domains |
| `data/teams.json` | 66078 | dict[5 keys]: source,pulled,total_matching_teams,returned,teams |
| `data/techstack_confirmed.json` | 3121 | dict[6 keys]: source,pulled,organization,adjacent_entity,note,stack |
| `data/techstack_detections_ortho_legacy.json` | 13201 | dict[2 keys]: meta,rows |
| `data/techstack_detections_quidel_legacy.json` | 19442 | dict[2 keys]: meta,rows |
| `data/techstack_detections_quidelortho.json` | 40447 | dict[2 keys]: meta,rows |
| `data/transcripts/Q1_2026.md` | 23434 | 109 lines |
| `data/transcripts/Q2_2026.md` | 24481 | 102 lines |
| `data/transcripts/Q3_2025.md` | 33862 | 166 lines |
| `data/transcripts/Q4_2025.md` | 51682 | 244 lines |
| `data/web_pages/appexchange_swift_account_manager_listing.txt` | 1643 | 19 lines |
| `data/web_pages/e360_cloud_business_office_quidelortho.txt` | 2189 | 22 lines |
| `data/web_pages/highspot_story_quidelortho_2025.txt` | 924 | 6 lines |
| `data/web_pages/origentech_ortho_clinical_case_search_excerpt.txt` | 717 | 8 lines |
| `data/web_pages/origentech_sap_tdf_ortho_clinical_case.txt` | 2784 | 42 lines |
| `data/web_pages/prnewswire_quidelortho_stevie_excellence_label_2026.txt` | 5053 | 37 lines |
| `data/web_pages/quidelortho_ciso_article_ai_analytics_2024.txt` | 6298 | 29 lines |
| `data/web_pages/quidelortho_cq_program_page.txt` | 3104 | 31 lines |
| `data/web_pages/sap_community_life_sciences_sapphire_tag_page.txt` | 729 | 14 lines |
| `data/web_pages/sap_enterprise_support_quidelortho_2026.txt` | 836 | 20 lines |
| `data/web_pages/stevie_2026_ai_digital_transformation_category_winners.txt` | 1295 | 17 lines |
| `data/web_pages/stevie_2026_gold_entry_quidelortho_customer_service.txt` | 5843 | 29 lines |
| `data/web_pages/trailblazer_post_data_cloud_trailhead_2024.txt` | 1465 | 19 lines |
| `data/web_pages/trailblazer_post_mulesoft_cloudhub_2020.txt` | 1153 | 14 lines |
| `data/web_pages/trailhead_ortho_field_sales_trailmix.txt` | 1627 | 17 lines |
| `data/web_pages/uipath_forward_2024_agenda_session_quidelortho.txt` | 1280 | 15 lines |
| `data/web_pages/uipath_forward_session_quidelortho_s4hana_2024.txt` | 1215 | 21 lines |
| `data/web_pages/vertex_customer_story_quidelortho_sap_2025.txt` | 5720 | 57 lines |
| `data/web_searches.json` | 44632 | list[76] |
| `data/web_searches_phase2.json` | 5181 | list[8] |
| `data/youtube/quidel_azure_iot_customer_tech_talks_2021.txt` | 17789 | 41 lines |
| `data/youtube/quidelortho_our_integration_story_2023.txt` | 4228 | 47 lines |
| `data/youtube/quidelorthocq_customer_experience_2026.txt` | 5283 | 31 lines |
| `deliverables/QuidelOrtho_Account_Summary.docx` | 51121 | ERR AttributeError |
| `deliverables/QuidelOrtho_Job_Postings.xlsx` | 179758 | Summary=24x10; Jobs=157x14 |
| `deliverables/QuidelOrtho_People_List.xlsx` | 132779 | Summary=59x6; People=312x20; Excluded=12x4; Below rule, not kept=1099x6 |
| `deliverables/QuidelOrtho_Sources_and_Evidence.docx` | 73404 | ERR AttributeError |
| `deliverables/QuidelOrtho_Tech_Stack_and_Teams.xlsx` | 26839 | Platform Ranking=32x10; Confirmed stack=88x5; Platform teams=30x8; Detections=64x5 |
| `notes/pass1.md` | 374 | 5 lines |
| `notes/sense_check.md` | 10354 | 87 lines |
| `pull_log.md` | 23546 | 184 lines |
