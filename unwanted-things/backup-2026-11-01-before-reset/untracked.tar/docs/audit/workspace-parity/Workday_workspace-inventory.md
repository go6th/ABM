# Inventory: Workday_workspace.zip

Archive: `/home/sakib/Downloads/Workday_workspace.zip`
SHA-256: `223833f0af3ccc9362698905d90f8895b6cc73ce555892bd0708e4567d838aa6`
Archive bytes: 8937303

Members: 79; uncompressed bytes: 42597849

| Path | Bytes | Type / counts |
|---|---:|---|
| `workday/` | 0 | file |
| `workday/deliverables/` | 0 | file |
| `workday/deliverables/Workday_Account_Summary.docx` | 70046 | DOCX; DOCX 24 headings, 11 tables; headings: heading 1: How to read this file / heading 1: Narrative, in plain words / heading 2: The account picture / heading 2: What is new since 22 September (updated 11 Oct 2026) / heading 2: What stands out / heading 2: What it likely means for each lane (interpretation) / heading 2: How this could be wrong / heading 2: The simplest way to sharpen it / heading 1: Recent news / heading 1: Company and transformation baseline / heading 2: What the executives said (from the last four calls) / heading 1: Signals / heading 2: Tier 1: budget proximate / heading 2: Tier 2: one step removed / heading 2: Tier 3: context and openers / heading 2: Context and history / heading 1: Platform picture by lane / heading 1: People / heading 2: Interpretation / heading 2: Findings from profiles / heading 1: Hypotheses to test / heading 1: Questions for a first conversation / heading 1: Research coverage tracker (11 Oct 2026) / heading 1: Source links |
| `workday/deliverables/Workday_Sources_and_Evidence.docx` | 119000 | DOCX; DOCX 18 headings, 11 tables; headings: heading 1: A. Source register / heading 1: B. Job posting extracts (read in depth) / heading 1: C. Postings read one by one: internal IT and Business Technology / heading 1: D. Executive statements from calls and releases / heading 1: E. Live job board capture: Salesforce search, 22 Sep 2026 / heading 2: NetSuite and Databricks searches, and the 19 postings added / heading 2: Board searches on 23 Sep 2026: Snowflake, Agentforce, MuleSoft, Tableau / heading 2: Board searches on 11 Oct 2026, and the contractor job site / heading 2: People search by job function and level / heading 1: F. Leads not verified / heading 1: G. Keeping copies of source pages / heading 1: H. Data pulls / heading 2: Technology detections, lane relevant / heading 2: News events, selected categories / heading 1: J. Profiles and posts pulled on 12 Oct 2026 / heading 2: Profile results for the 32 people added on 11 Oct 2026 / heading 2: Recent posts of priority A people / heading 1: I. Full URLs |
| `workday/deliverables/Workday_Tech_Stack_and_Teams.xlsx` | 20169 | XLSX; Platform Ranking=48 rows, Confirmed Stack=164 rows, Platform Teams=30 rows |
| `workday/deliverables/Workday_Job_Postings.xlsx` | 1476676 | XLSX; Summary=44 rows, Jobs=1004 rows |
| `workday/deliverables/Workday_People_List.xlsx` | 58994 | XLSX; Summary=65 rows, People=357 rows |
| `workday/notes_open_leads.md` | 1530 | MD |
| `workday/RESTORE.md` | 5913 | MD |
| `workday/deck/` | 0 | file |
| `workday/deck/build_deck.js` | 23047 | JS |
| `workday/deck/source_slides.js` | 16597 | JS |
| `workday/notes_sources.md` | 28889 | MD |
| `workday/data/` | 0 | file |
| `workday/data/missing172.json` | 1369793 | JSON; JSON array, 172 records |
| `workday/data/board_raw_oct11.json` | 50735 | JSON; JSON object, 5 keys |
| `workday/data/talent_ppm_finance_atlanta.txt` | 2029 | TXT |
| `workday/data/profiles_full_oct12.json` | 289318 | JSON; JSON object, 32 keys; arrays: Charles Baker.certifications[1], Charles Baker.educations[2], Charles Baker.experiences[12], Jim Delia.educations[3], Jim Delia.experiences[12], Jim Delia.languages[2], Jim Delia.volunteer[1], Tim Stucka.certifications[2], Tim Stucka.educations[3], Tim Stucka.experiences[10], Tim Stucka.languages[5], Kurt Steward.educations[3] |
| `workday/data/profile_status_oct12.json` | 8551 | JSON; JSON object, 32 keys; arrays: Charles Baker.other_current[0], Jim Delia.other_current[3], Tim Stucka.other_current[0], Kurt Steward.other_current[1], John Kravitz.other_current[1], Cara Engelbrecht.other_current[0], Justin Joseph.other_current[1], Julie Robinson.other_current[1], Suzanne Permanna.other_current[1], Ravi Korlimarla.other_current[2], Krupa Natarajan.other_current[0], Edward R..other_current[3] |
| `workday/data/stack_names.json` | 2130 | JSON; JSON array, 155 records |
| `workday/data/posts_raw_oct11.txt` | 277101 | TXT |
| `workday/data/posts_priorityA_compact_oct12.json` | 211364 | JSON; JSON object, 27 keys; arrays: Charles Baker[20], Akash Kapoor[20], Andrea Simon[9], Christian Danish[18], Farhad Choudhury[0], Gaurav Kakar[0], Jessie McKay[0], Matthew Beltrano[8], Mohit Nadkarni[4], Nicholas Kouvaris[7], Nicole J.[20], Nishchal Rana[20] |
| `workday/data/jobs_oct11.json` | 1745144 | JSON; JSON object, 3 keys; arrays: data[208], included[1] |
| `workday/data/email_lookup_urls.json` | 4590 | JSON; JSON array, 105 records |
| `workday/data/platform_teams_compact.json` | 12073 | JSON; JSON array, 25 records |
| `workday/data/board_details_oct11.json` | 283967 | JSON; JSON object, 31 keys |
| `workday/data/record_check_oct11.json` | 5278 | JSON; JSON object, 3 keys; arrays: fields[7], rows[32] |
| `workday/data/jobs_new_rows_oct11.json` | 1468725 | JSON; JSON array, 186 records |
| `workday/data/board_oct11.json` | 56755 | JSON; JSON object, 11 keys; arrays: Salesforce.jobs[31], MuleSoft.jobs[3], Agentforce.jobs[2], Revenue Cloud.jobs[26], Databricks.jobs[12], Snowflake.jobs[3], NetSuite.jobs[7], Tableau.jobs[3], Business Technology.jobs[195], GTM Next.jobs[12], Conga.jobs[1] |
| `workday/data/news_oct11.json` | 168356 | JSON; JSON object, 3 keys; arrays: data[27], included[35] |
| `workday/data/platform_teams.json` | 151310 | JSON; JSON object, 6 keys; arrays: teams[25] |
| `workday/data/profiles_compact_oct12.json` | 45175 | JSON; JSON array, 32 records |
| `workday/data/rank_checked.json` | 79 | JSON; JSON array, 5 records |
| `workday/data/emails_oct11.json` | 5875 | JSON; JSON object, 83 keys; arrays: akashkapoor9[3], christian-danish-96b76[3], farhadchoudhury[3], jessiemckay[3], joe-dossantos[3], mohit-nadkarni-56b1a41[3], nicholaskouvaris[3], nvrana[3], ranijohnson[3], seherish-mughal-48440622[3], taylor-sewitt[3], umeshdeshpande[3] |
| `workday/data/verify_open.json` | 6085 | JSON; JSON array, 43 records |
| `workday/data/paths_to_read.json` | 2706 | JSON; JSON object, 31 keys |
| `workday/data/new_jobs_sentences.txt` | 25880 | TXT |
| `workday/data/missing172_sentences.txt` | 39973 | TXT |
| `workday/data/people_pull_oct11.py` | 18642 | PY |
| `workday/data/techdet_oct11.json` | 1541103 | JSON; JSON object, 3 keys; arrays: data[599], included[2785] |
| `workday/data/jobs12m_oct11.json` | 24763703 | JSON; JSON array, 3136 records |
| `workday/data/rank_drops.json` | 10344 | JSON; JSON array, 78 records |
| `workday/data/paths_verify.json` | 9856 | JSON; JSON object, 44 keys; arrays: https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USAVAReston/Software-Development-Engineer--SRE--US-Federal-_JR-0110178[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USA-CO-Boulder/Sr-Software-Development-Engineer_JR-0109804[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/Canada-BC-Vancouver/Principal-Software-Development-Engineer---AI-Platform_JR-0110056[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USAVAReston/Mid-Senior-Site-Reliability-Engineer--US-Federal-_JR-0110301[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USAVAReston/Cybersecurity-Engineer_JR-0109828[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/INDPune/Sr-Associate-Customer-Support-Analyst--AI-ML-Application-Support-_JR-0110060[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/VNMDa-Nang/Senior-DevOps-Engineer---Da-Nang_JR-0109934[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USAVAReston/Principal-Cyber-Security-Engineer-US-Federal_JR-0110057[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USA-CA-Pleasanton/Machine-Learning-Engineer-III_JR-0109848[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/Ireland-Dublin/Senior-Cloud-Engineer_JR-0109890[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/Ireland-Dublin/Principal-Machine-Learning-Engineer_JR-0109752[2], https://workday.wd5.myworkdayjobs.com/en-US/Workday/job/USA-GA-Atlanta/Senior-Cybersecurity-Engineer---Network-Security_JR-0109368[2] |
| `workday/data/posts_priorityA_full_oct12.json` | 515267 | JSON; JSON object, 27 keys; arrays: Charles Baker.posts[20], Akash Kapoor.posts[20], Andrea Simon.posts[9], Christian Danish.posts[18], Matthew Beltrano.posts[8], Mohit Nadkarni.posts[4], Nicholas Kouvaris.posts[7], Nicole J..posts[20], Nishchal Rana.posts[20], [redacted] Misquita.posts[7], Rani Johnson.posts[20], Riyaz Kasmani.posts[18] |
| `workday/data/tech_stack.json` | 8589 | JSON; JSON object, 3 keys; arrays: stack[37] |
| `workday/build/` | 0 | file |
| `workday/build/rebuild_docs.py` | 2905 | PY |
| `workday/build/people_wb.py` | 1128 | PY |
| `workday/build/docx_lib.js` | 4575 | JS |
| `workday/build/people_summary_grid.json` | 15044 | JSON; JSON object, 2 keys; arrays: cells[99] |
| `workday/build/summary_content.json` | 83631 | JSON; JSON array, 85 records |
| `workday/build/jobs_rows.json` | 6955945 | JSON; JSON array, 817 records |
| `workday/build/urls.json` | 37183 | JSON; JSON object, 121 keys |
| `workday/build/jobs.py` | 921 | PY |
| `workday/build/evidence_content.json` | 235590 | JSON; JSON array, 117 records |
| `workday/build/ids.json` | 10631 | JSON; JSON object, 121 keys |
| `workday/build/refresh_11oct/` | 0 | file |
| `workday/build/refresh_11oct/people_v2.py` | 8188 | PY |
| `workday/build/refresh_11oct/summary_v2.py` | 20478 | PY |
| `workday/build/refresh_11oct/sources_v2.py` | 9451 | PY |
| `workday/build/refresh_11oct/match.py` | 1179 | PY |
| `workday/build/refresh_11oct/tracker.json` | 7002 | JSON; JSON object, 2 keys; arrays: rows[26] |
| `workday/build/refresh_11oct/evidence_v3_addendum.py` | 7268 | PY |
| `workday/build/refresh_11oct/followup_lists.json` | 9387 | JSON; JSON object, 2 keys; arrays: new[32], A[28] |
| `workday/build/refresh_11oct/paths.json` | 9857 | JSON; JSON array, 44 records |
| `workday/build/refresh_11oct/platform_ranking_wd.py` | 11439 | PY |
| `workday/build/refresh_11oct/jobs_v2.py` | 11181 | PY |
| `workday/build/refresh_11oct/ids_v2.json` | 829 | JSON; JSON array, 121 records |
| `workday/build/refresh_11oct/people_v3_addendum.py` | 6599 | PY |
| `workday/build/refresh_11oct/docx_helpers.py` | 3117 | PY |
| `workday/build/refresh_11oct/summary_v3_addendum.py` | 8121 | PY |
| `workday/build/refresh_11oct/evidence_v2.py` | 14784 | PY |
| `workday/build/refresh_11oct/drop_orphan_links.py` | 350 | PY |
| `workday/build/refresh_11oct/techstack_wb.py` | 6698 | PY |
| `workday/build/rowcheck.py` | 1680 | PY |
| `workday/build/jobs_summary_grid.json` | 11722 | JSON; JSON object, 2 keys; arrays: cells[77] |
| `workday/build/doc_checks.py` | 2140 | PY |
| `workday/build/wb_common.py` | 1643 | PY |
| `workday/build/people_rows.json` | 175826 | JSON; JSON array, 324 records |
