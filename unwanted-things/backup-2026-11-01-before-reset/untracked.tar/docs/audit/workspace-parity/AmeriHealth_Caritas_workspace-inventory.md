# Inventory: AmeriHealth_Caritas_workspace.zip

Archive: `/home/sakib/Downloads/AmeriHealth_Caritas_workspace.zip`
SHA-256: `7b30084a050d042a8511ad138b002596486e357672dd685b2fd83f51eff689bb`
Archive bytes: 2240011

Members: 36; uncompressed bytes: 9290475

| Path | Bytes | Type / counts |
|---|---:|---|
| `AmeriHealth_Caritas_workspace/` | 0 | file |
| `AmeriHealth_Caritas_workspace/deliverables/` | 0 | file |
| `AmeriHealth_Caritas_workspace/deliverables/AmeriHealth_Caritas_Job_Postings.xlsx` | 209323 | XLSX; Summary=14 rows, Jobs=157 rows |
| `AmeriHealth_Caritas_workspace/deliverables/AmeriHealth_Caritas_Tech_Stack_and_Teams.xlsx` | 23801 | XLSX; Summary=4 rows, Stack=55 rows, Teams=41 rows, Detections=314 rows |
| `AmeriHealth_Caritas_workspace/deliverables/AmeriHealth_Caritas_Sources_and_Evidence.docx` | 60659 | DOCX; DOCX 38 headings, 8 tables; headings: Heading 1: Part A: Source register / Heading 1: Part B: Job posting extracts for postings read in depth / Heading 2: J1: Salesforce Development Manager (2026-09-18) / Heading 2: J3: Salesforce Developer Senior, Contact Center (2026-08-24) / Heading 2: J5: Salesforce Senior Applications Developer (2026-08-18) / Heading 2: J7: Salesforce Application Architect (2026-01-21) / Heading 2: J9: Salesforce Developer Programmer Senior (2026-01-21) / Heading 2: J10: Salesforce Applications Developer Senior (2026-01-21) / Heading 2: J11: Integration Manager, Enterprise Solutions Architect (2026-09-18) / Heading 2: J13: Marketing Lead Data Implementation (2026-04-17) / Heading 2: J16: Developer Programmer Lead (2026-06-11) / Heading 2: J18: Director AI Data Coordination (2026-08-14) / Heading 2: J20: Senior Analyst, Generative AI Specialist (2025-12-10) / Heading 2: J22: Senior Data Platform Engineer, Azure Databricks (2026-08-31) / Heading 2: J23: Senior Manager IT, Master Data Management (2026-07-10) / Heading 2: J24: Principle Architect, Workday ERP (2026-09-24) / Heading 2: J25: Senior Architect, Healthcare Payer Domain (2026-09-25) / Heading 2: J29: Vice President, Human Resources Technology & Operations (2025-12-04) / Heading 2: J31: Manager Content Management & Systems (2026-05-12) / Heading 1: Part C: Postings read one by one for the primary lanes / Heading 2: Salesforce / Heading 2: ServiceNow / Heading 2: SAP / Heading 1: Part D: Video and article extracts / Heading 2: S6: HealthSherpa release, Sep 23 2026 / Heading 2: S3: Interim president release, Oct 1 2025 / Heading 2: S5: Interim CFO release, Sep 24 2026 / Heading 2: S21: MedCity News, AHIP 2024 / Heading 2: S25: Becker's Spring 2026 Payer Roundtable / Heading 2: S26: MHPA26 agenda / Heading 1: Part E: Job board captures / Heading 1: Part F: Leads not verified / Heading 1: Part G: Keeping copies of the original pages / Heading 1: Part H: Data pulls / Heading 2: Technology detections by lane (last seen since Sep 2024) / Heading 2: News feed events (13, since Mar 2025) / Heading 2: People pull / Heading 1: Part I: Full URLs |
| `AmeriHealth_Caritas_workspace/deliverables/AmeriHealth_Caritas_Account_Summary.docx` | 51318 | DOCX; DOCX 27 headings, 15 tables; headings: Heading 1: How to read this file / Heading 1: The account in plain words / Heading 2: The account picture / Heading 2: What stands out / Heading 2: What it likely means for each lane (interpretation labeled) / Heading 2: How this could be wrong / Heading 2: The simplest way to sharpen it / Heading 1: Recent news / Heading 1: Company and transformation baseline / Heading 1: Signals / Heading 2: Tier 1: budget proximate (about 90 day shelf life) / Heading 2: Tier 2: one step removed / Heading 2: Tier 3: context and openers / Heading 2: Context and history (older than 18 months or superseded) / Heading 1: Platform picture / Heading 1: People / Heading 2: Key people (priority A, senior) / Heading 2: Findings from profiles / Heading 2: People whose status changed / Heading 2: Posts and comments of the priority people / Heading 1: Hypotheses to test / Heading 1: Questions for a first conversation / Heading 1: Research coverage tracker / Heading 2: Decisions waiting on the account owner / Heading 2: Pass 1: summary homework / Heading 2: Pass 2: detailed homework / Heading 1: Source links |
| `AmeriHealth_Caritas_workspace/deliverables/AmeriHealth_Caritas_People_List.xlsx` | 31831 | XLSX; Summary=27 rows, People=162 rows |
| `AmeriHealth_Caritas_workspace/notes/` | 0 | file |
| `AmeriHealth_Caritas_workspace/notes/run_notes.md` | 1268 | MD |
| `AmeriHealth_Caritas_workspace/RESTORE.md` | 1654 | MD |
| `AmeriHealth_Caritas_workspace/data/` | 0 | file |
| `AmeriHealth_Caritas_workspace/data/people_classified.json` | 45172 | JSON; JSON object, 2 keys; arrays: rows[161], removed[5] |
| `AmeriHealth_Caritas_workspace/data/techstack_detections.json` | 39142 | JSON; JSON array, 313 records |
| `AmeriHealth_Caritas_workspace/data/posts_comments.json` | 281943 | JSON; JSON object, 38 keys; arrays: 1.posts[2], 1.comments[20], 4.posts[14], 4.comments[1], 5.posts[5], 5.comments[18], 7.posts[5], 7.comments[17], 9.posts[1], 9.comments[4], 10.posts[1], 10.comments[15] |
| `AmeriHealth_Caritas_workspace/data/people_grid.txt` | 12964 | TXT |
| `AmeriHealth_Caritas_workspace/data/teams_1002.json` | 9064 | JSON; JSON array, 40 records |
| `AmeriHealth_Caritas_workspace/data/jobs_12mo.json` | 7052665 | JSON; JSON array, 1318 records |
| `AmeriHealth_Caritas_workspace/data/profiles_analysis.json` | 140714 | JSON; JSON array, 160 records |
| `AmeriHealth_Caritas_workspace/data/techstack_1002.json` | 6598 | JSON; JSON array, 54 records |
| `AmeriHealth_Caritas_workspace/data/profiles_full.json` | 1169505 | JSON; JSON object, 165 keys; arrays: 1.certifications[1], 1.educations[2], 1.experiences[9], 2.certifications[2], 2.educations[1], 2.experiences[10], 2.languages[2], 3.certifications[2], 3.educations[4], 3.experiences[9], 3.languages[2], 4.certifications[6] |
| `AmeriHealth_Caritas_workspace/data/people_rows.json` | 49464 | JSON; JSON array, 161 records |
| `AmeriHealth_Caritas_workspace/data/live_board_postings.json` | 3862 | JSON; JSON array, 3 records |
| `AmeriHealth_Caritas_workspace/data/news_events.json` | 2176 | JSON; JSON array, 13 records |
| `AmeriHealth_Caritas_workspace/build/` | 0 | file |
| `AmeriHealth_Caritas_workspace/build/tracker.js` | 6400 | JS |
| `AmeriHealth_Caritas_workspace/build/classify.py` | 4058 | PY |
| `AmeriHealth_Caritas_workspace/build/docx_lib.js` | 4575 | JS |
| `AmeriHealth_Caritas_workspace/build/urls.json` | 14297 | JSON; JSON object, 81 keys; arrays: S1[2], S2[2], S3[2], S4[2], S5[2], S6[2], S7[2], S8[2], S9[2], S10[2], S11[2], S12[2] |
| `AmeriHealth_Caritas_workspace/build/ids.json` | 549 | JSON; JSON array, 81 records |
| `AmeriHealth_Caritas_workspace/build/content.js` | 22467 | JS |
| `AmeriHealth_Caritas_workspace/build/evidence.js` | 9860 | JS |
| `AmeriHealth_Caritas_workspace/build/tech_workbook.py` | 3150 | PY |
| `AmeriHealth_Caritas_workspace/build/profiles.py` | 4244 | PY |
| `AmeriHealth_Caritas_workspace/build/people_workbook.py` | 7793 | PY |
| `AmeriHealth_Caritas_workspace/build/jobs_workbook.py` | 7321 | PY |
| `AmeriHealth_Caritas_workspace/build/summary.js` | 12638 | JS |
