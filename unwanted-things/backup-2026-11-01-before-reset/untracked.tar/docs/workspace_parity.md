# Workspace parity

**Implementation status: safe import, source views, and a conservative canonical Ask subset are
ready; full deterministic parity remains in progress.** Raw workspace archives can be inspected and
stored for an account, the five client-facing deliverables can be browsed or downloaded, delivered
parity counts are calculated by the backend, and unambiguous supported RESTORE queries can be
computed from the imported typed workbook rows in Ask. An import remains `incomplete` until the
remaining workspace configuration and transformation rules are derived. The importer does not
regenerate all five legacy deliverables or establish end-to-end parity.

## Current import boundary

`POST /v1/accounts/{domain}/workspace-imports?filename=...` accepts the ZIP as an
`application/zip` request body. The caller's verified tenant is taken from the authenticated
identity. The account domain must resolve inside that tenant. If the archive has a recognized
`company_record.json` domain, it must match the selected account.

The importer reads at most 100 MB from the request and inspects the ZIP in memory. It does not
extract files to disk and never executes scripts. It rejects traversal paths, duplicate paths,
non-regular entries, encryption, corrupt members, excessive expansion, oversized members and
excessive compression ratios. Nested Office packages have the same path/type/compression checks
and full CRC validation. JSON object keys must be unique and JSON nesting is bounded.

The inspection report contains member paths and sizes, JSON array counts, workbook sheet names,
row counts and conservative text-header candidates, Word heading/table counts,
required-deliverable presence and validation issues. The
deterministically extracted config subset is defined by
[`workspace_import.schema.json`](../src/parity/schema/workspace_import.schema.json). It includes
recognized identity, run date, canonical query text, entity-rule text, out-of-scope platforms,
and validated `checked.json`, `stack_names.json`, and `drop_*.json` values with source paths. It
also parses only literal top-level `PLATFORMS`, `LANE`, and people-lane assignments from named
build scripts with Python's AST literal parser; dynamic expressions are not evaluated. Duplicate
static inputs are reported as ambiguous and are not silently selected.
Rules that are not yet derived are listed in `not_derived`. The complete candidate schema is
[`workspace_config.schema.json`](../src/parity/schema/workspace_config.schema.json); it is not yet
the import API contract.

Raw bytes are stored under
`tenants/{tenant_id}/accounts/{account_id}/workspaces/{import_id}/source.zip`. Postgres stores
tenant/account IDs, uploader provenance, monotonically allocated account version, SHA-256, object
key, partial config and a content-free structural report. The table has forced tenant-and-owner
RLS: only the account owner who uploaded the archive can read its import history. A colleague in
the same tenant and users in other tenants cannot read it. Account deletion removes the rows
and its object prefix.

`GET /v1/accounts/{domain}/workspace-imports` returns the account owner's newest 100 versions.
Derived JSON views of recognized deliverables and a ZIP containing only those deliverables are
stored below the same erasable account prefix. The import view endpoint serves summary, news,
evidence, and paged workbook sheets. The audited download endpoint returns a ZIP containing only
the recognized client deliverables. Missing or unparseable views return a labeled unavailable
response. Both endpoints check the selected account, import row and owner RLS before reading private
objects. The account page can browse source views and download the client deliverables. Imported
data stays separate from live research and the delivered parity bundle.

## Existing deterministic parity code

The repository's generic repair transforms remain under `src/exports/repair/`. Their current
ordered table pipeline is `exports.repair.pipeline`; jobs, entity classification, technology
ranking, people, news, sources and coverage are implemented in their respective modules. The
existing bundle-backed parity API and renderers are under `src/parity/`.

`GET /v1/accounts/{domain}/parity/screen` now returns the backend's `computed_summary`,
`summary_mismatches`, and people-lane order. The browser renders those values; it no longer receives
row projections for calculating delivered Summary totals. The manifest's workbook values remain
available for comparison, and the backend reports mismatches.

## Canonical Ask subset

Ask reads the latest owner-visible import config for the selected account, matches a single
unambiguous compiled RESTORE query, and runs its supported predicates against the corresponding
versioned workbook tables through `documents.tables`. The result is computed from stored rows;
the count written in RESTORE is never used as an answer. A strict zero is stated first, then the
result after removing the last predicate is labeled as a relaxed set. Counts that require
unsupported operations, ambiguous question matches, truncated table results, or additional metrics
such as Waters pre-close totals fall back to the existing Ask route. Query matching and operators
are conservative and do not cover every form of RESTORE prose. Supported canonical answers cite
the imported workbook table as an Internal source. The archive remains incomplete and this subset
does not establish parity for all queries or for Deep mode.

## Adding a reference workspace

1. Create or select the account in the tenant workspace.
2. Open the account page and upload the source ZIP with **Inspect workspace**.
3. Review the import version, required deliverables, structural counts and issues; browse available
   source views and download the client-only ZIP when needed.
4. Treat imported files as source references while status is `incomplete`; only the supported
   canonical Ask subset is connected to these imported rows. Normalized repair outputs and Deep
   mode are not connected to these imports.

For an offline golden comparison after a sandboxed rebuild, run
`.venv/bin/python scripts/compare_workspace.py <golden-deliverables-dir> <rebuilt-deliverables-dir>`.
The command exits non-zero on mismatch and reports only deliverable roles, counts and cell
coordinates; it never echoes worksheet values or document text.

Do not mark a package complete based only on the five deliverables being present. The remaining
config must be derived from `RESTORE.md`, notes and build inputs, validated against the full schema,
and bound to its canonical answers before normalized tables or parity views can use it.

## Remaining acceptance work

* Extract and validate the full per-workspace config, including notes and build inputs, without
  running uploaded code.
* Port and connect all applicable generic jobs, ranking, people, stack, teams, sources, narrative
  and deliverable rules to the raw-import path.
* The current views are faithful source views. Extend deterministic canonical-query routing beyond
  the supported subset and connect Deep chat to the same computed results.
* Verify writing rules, internal-file withholding, frontend/download/chat parity and tenant
  isolation against every archive and a previously unseen archive.
* Run the migration catalog RLS check, full backend gates, full frontend suite, and the isolated
  golden replay for every available archive. The BD `RESTORE.md` sequence has run in a no-network,
  no-secrets Bubblewrap sandbox; four deliverables compare exactly and the Jobs `Full description`
  cells `M81` and `M98` differ because the shipped workbook was built from an earlier capture of
  two postings that the archive's own intermediates no longer contain (see the gap report). The focused import/Ask/parity regression suite passes against a
  disposable local Postgres database (903 tests), the tenant isolation matrix passes (564 tests),
  and the wider parity suite passes with six skips, including the ignored reference-workspace
  fixture. A complete backend run before the final fixes had 14 failures; a 201-test recovery set for
  those failed gates passed, but the full run has not been repeated. The frontend suite and generated
  client checks pass. This is not the full acceptance suite.

See [`docs/audit/workspace-parity/`](audit/workspace-parity/README.md) for the Phase 1 inventory,
logic map, contract and gap report.
